--
-- PostgreSQL database dump
--

\restrict xhgTuNBnV8pvwT6blBagkeJQra7BQSe06zOLkxm5M8RbaYmHwGRCjjdnY5EBChe

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: analytics_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_events (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    event_type text NOT NULL,
    event_data jsonb,
    page_url text,
    session_id text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.analytics_events OWNER TO postgres;

--
-- Name: book_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.book_versions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    book_id character varying NOT NULL,
    version_type character varying DEFAULT 'draft'::character varying NOT NULL,
    content jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    created_by character varying,
    published_at timestamp without time zone
);


ALTER TABLE public.book_versions OWNER TO postgres;

--
-- Name: books; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.books (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    author text NOT NULL,
    cover_image text,
    description text NOT NULL,
    category_id character varying,
    read_time integer NOT NULL,
    listen_time integer NOT NULL,
    audio_url text,
    featured boolean DEFAULT false,
    core_thesis text,
    status text DEFAULT 'draft'::text,
    updated_at timestamp without time zone DEFAULT now(),
    primary_chakra text,
    secondary_chakra text,
    audio_duration integer,
    tags text
);


ALTER TABLE public.books OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    icon text NOT NULL,
    color text NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: chakra_progress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chakra_progress (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    chakra text NOT NULL,
    points integer DEFAULT 0,
    exercises_completed integer DEFAULT 0,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.chakra_progress OWNER TO postgres;

--
-- Name: chapter_summaries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chapter_summaries (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    book_id character varying NOT NULL,
    chapter_number integer NOT NULL,
    chapter_title text NOT NULL,
    cards jsonb NOT NULL,
    content text,
    audio_url text,
    audio_duration integer,
    subtitle text,
    estimated_read_time integer
);


ALTER TABLE public.chapter_summaries OWNER TO postgres;

--
-- Name: comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    book_id character varying NOT NULL,
    block_type text NOT NULL,
    block_id text NOT NULL,
    user_id character varying NOT NULL,
    content text NOT NULL,
    resolved boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.comments OWNER TO postgres;

--
-- Name: daily_sparks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.daily_sparks (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    quote text NOT NULL,
    author text NOT NULL,
    book_id character varying,
    category text
);


ALTER TABLE public.daily_sparks OWNER TO postgres;

--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.journal_entries (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    exercise_id character varying,
    content text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.journal_entries OWNER TO postgres;

--
-- Name: mental_models; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mental_models (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    book_id character varying NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    steps jsonb NOT NULL,
    order_index integer NOT NULL
);


ALTER TABLE public.mental_models OWNER TO postgres;

--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_preferences (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    daily_reminder boolean DEFAULT true,
    streak_alerts boolean DEFAULT true,
    new_content boolean DEFAULT true,
    weekly_summary boolean DEFAULT true,
    reminder_time text DEFAULT '09:00'::text,
    push_subscription jsonb,
    permission_status text DEFAULT 'default'::text,
    last_prompt_dismissed timestamp without time zone,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.notification_preferences OWNER TO postgres;

--
-- Name: quiz_results; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quiz_results (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    book_id character varying NOT NULL,
    chapter_id character varying NOT NULL,
    score integer NOT NULL,
    total_questions integer NOT NULL,
    answers jsonb DEFAULT '[]'::jsonb,
    completed_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.quiz_results OWNER TO postgres;

--
-- Name: saved_highlights; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.saved_highlights (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    book_id character varying NOT NULL,
    principle_id character varying,
    content text NOT NULL,
    type text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.saved_highlights OWNER TO postgres;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    sid character varying NOT NULL,
    sess jsonb NOT NULL,
    expire timestamp without time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: short_views; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.short_views (
    id character varying(255) DEFAULT gen_random_uuid() NOT NULL,
    short_id character varying(255) NOT NULL,
    user_id text,
    viewed_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.short_views OWNER TO postgres;

--
-- Name: shorts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shorts (
    id character varying(255) DEFAULT gen_random_uuid() NOT NULL,
    book_id character varying(255) NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    media_type text NOT NULL,
    media_url text,
    thumbnail_url text,
    background_gradient text,
    duration integer,
    order_index integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.shorts OWNER TO postgres;

--
-- Name: user_activity_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_activity_log (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    event_type text NOT NULL,
    event_data jsonb DEFAULT '{}'::jsonb,
    book_id character varying,
    session_duration integer,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_activity_log OWNER TO postgres;

--
-- Name: user_interests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_interests (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    interests text[] DEFAULT '{}'::text[],
    onboarding_completed boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_interests OWNER TO postgres;

--
-- Name: user_progress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_progress (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    book_id character varying NOT NULL,
    bookmarked boolean DEFAULT false,
    last_accessed_at timestamp without time zone DEFAULT now(),
    current_card_index integer DEFAULT 0,
    total_cards integer DEFAULT 0,
    current_section text
);


ALTER TABLE public.user_progress OWNER TO postgres;

--
-- Name: user_streaks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_streaks (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    current_streak integer DEFAULT 0,
    longest_streak integer DEFAULT 0,
    last_active_date date,
    total_minutes_listened integer DEFAULT 0,
    total_books_started integer DEFAULT 0,
    streak_freeze_available boolean DEFAULT true,
    last_freeze_used_at timestamp without time zone
);


ALTER TABLE public.user_streaks OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    email character varying,
    first_name character varying,
    last_name character varying,
    profile_image_url character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    role character varying DEFAULT 'user'::character varying,
    is_premium boolean DEFAULT false,
    stripe_customer_id character varying,
    stripe_subscription_id character varying,
    current_period_end timestamp without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: analytics_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_events (id, user_id, event_type, event_data, page_url, session_id, created_at) FROM stdin;
70f9f7d7-ca77-4a8a-85c5-44d08c3d78b9	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:41:06.392327
06752810-4977-4c7b-80e0-f5dba9f6a858	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:42:22.579967
b404f3dc-d669-4c02-aa8c-dd0c0cb4397b	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 07:42:41.810171
560f4079-6cc8-44c7-811b-4df5560f9947	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:43:12.317289
8de07567-7d68-4207-945d-57ddccb7a607	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 07:43:12.521827
ec18ae74-21f9-46c2-8bd0-90f97fa65f75	35323958	book_open	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:43:41.159681
aabbd13e-2577-46ea-a807-0a5ae450887b	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:44:20.99742
94f58e26-c6cd-4351-8d0b-c0326511cfe7	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 07:44:24.541261
c4371ed6-a3d5-4c8f-ac7b-15d2954a6b11	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:44:39.106635
0d3d65ee-fbdd-45e7-8b98-af2c2e4c701b	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 07:44:41.538173
cfb4fae5-98e4-4393-bdcc-07e8e6d7cb54	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:45:30.643355
af6f9714-f6d3-4ed6-9a0c-05c39b361537	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 07:45:33.083122
ce8be361-156b-43d7-bfc6-06507adb06d9	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:46:03.620007
90828a60-7fad-4199-9f7d-9c1af4ef4eb0	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 07:46:06.035016
a088e670-13da-4a57-8dc6-4822f4589d4f	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:56:57.149494
ee409fef-f031-4229-8e60-75bf8e7b2df8	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 07:56:59.583336
e75713b6-cc3f-4cdf-8b5e-e445644af7fa	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:58:43.08821
54194324-bc86-453b-85d8-20d60a2afb89	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 07:58:43.252223
5dc5db6f-ad31-4bf8-ac9e-be6e24d0c23c	35323958	chapter_start	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "section": "chapter-summaries", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439/journey	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:58:43.994548
c49d0b99-42e7-40d7-bcf4-b9560b4fee87	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:59:10.925702
f761441d-4d06-4158-bf20-fa6a0e9e6bee	35323958	chapter_start	{"bookId": "23f2345b-6336-4573-a63f-8ee2cd34f56b", "section": "chapter-summaries", "bookTitle": "Man's Search for Meaning"}	/book/23f2345b-6336-4573-a63f-8ee2cd34f56b/journey	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:59:29.58264
9dcb0a21-4031-4d55-b18f-48478a1420e3	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:59:52.795156
d0282230-b26b-42eb-b21d-c3f67f9c4d85	35323958	chapter_start	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "section": "chapter-summaries", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439/journey	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:00:18.246023
4a5e49ae-2a0d-46f5-b66c-621aee2eede4	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:00:44.10917
ed57e832-cb28-4e87-9147-95ca1000ca7d	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:03:13.670581
a444781b-8368-4656-875b-15e302404fd1	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:03:15.883739
0342fdff-b6cb-4703-a0ec-aa8d2cd74b1d	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:04:13.449423
49f68fc3-0fd4-439e-8689-4b6aa9eb0c9e	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:04:14.38075
3796d484-dd2e-4a1e-bd72-b6df96a85415	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:04:35.080833
bd5e5e85-2ebb-48e2-adb4-887a7d33bd4a	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:04:37.368236
8b543e7a-54ec-453b-8e97-a5cf88475660	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:07:11.660188
ce3ff47b-e605-40bd-bc39-b5f63e011830	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:07:11.761284
ea245a79-faec-4ce7-a706-7a9a9dbac7ed	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:07:42.834289
8205157a-27bd-4aad-9c42-840774d40d2f	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:07:45.055886
031b6967-29c0-480b-808e-a41d5e2db159	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:08:47.164221
044f7ef0-af73-413f-9e47-6edf36c8879a	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:08:47.239844
78d64685-62c8-4f14-97eb-af56e0ee2e50	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:09:11.312069
79c97e45-184e-4170-b084-f162e00eaf7d	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:09:11.416175
35e0f7ad-c6b1-4376-bac7-56b233d77d31	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:10:23.791962
de8feb20-d70c-41c8-a17d-9adaae87b8c1	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:10:23.87505
6aeabf05-d956-4d88-af12-309c655db2ce	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:11:02.125329
a614a61b-77f0-4936-92e9-6e6de398f4cb	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:11:02.211704
adaa8431-2c32-47d7-b194-0e708f68c641	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:11:26.625762
2e7c38a1-345d-4b13-887e-cffe7ea997f7	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:11:29.301005
921d0938-2220-4586-8e1b-576c029cb9c8	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:11:43.46326
96417508-3067-46a8-b526-2bc41b7c72a7	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:11:45.974021
6d2e45d0-f3c5-4a46-b402-65dfe4decfb7	tcBg5V	page_view	{"page": "dashboard"}	/	1ed47247-73db-4d06-a81e-e45739589517	2026-02-27 08:12:46.088754
d3733772-06c5-4db2-990a-cc80ca905dae	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:13:22.403964
a47bd6bc-4d32-47bb-8ce2-6578315ab37b	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:13:24.586208
775657f8-b6dc-41af-bcc3-dfbbd1116273	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:16:53.068798
dd8d928e-61a0-4106-80c3-dc11da8775a8	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:16:53.256698
fa24730d-de59-4c24-93fc-f505db742af3	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:18:54.094285
a4791fdd-9942-4bcc-be12-b0f31d01294d	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:18:54.181647
5a56a6fe-7829-4ca8-af83-f1f533c78afa	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:19:01.404561
d39eb9ff-cdf8-4b19-b857-e0f5cbb41a14	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:19:01.418594
9a43c539-3808-4955-8175-a079227f79bc	X5bqd-	page_view	{"page": "dashboard"}	/	8b4284d6-d73b-48b5-9622-83b741149e34	2026-02-27 08:21:33.364368
65360e24-7dc8-45a2-9e17-23f5d415cd4a	b5yZvL	page_view	{"page": "dashboard"}	/	e5060fe9-ca1e-4e67-8152-aa2d55db40ca	2026-02-27 08:27:29.530946
ae95a38c-c110-4fc9-93ca-7483957720f5	35323958	page_view	{"page": "dashboard"}	/	c82e46fb-4539-418a-b143-145d8d48d526	2026-02-27 08:31:36.612882
15afe06d-56e2-481a-a3de-131041583758	35323958	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	c82e46fb-4539-418a-b143-145d8d48d526	2026-02-27 08:33:06.705566
c217529c-dda4-43f8-9630-f9cfdbd0e5af	35323958	chapter_start	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "section": "chapter-summaries", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5/journey	c82e46fb-4539-418a-b143-145d8d48d526	2026-02-27 08:33:10.343056
0bc6ec5c-806f-498b-89d3-10b40155c9ac	35323958	chapter_complete	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "section": "chapter-summaries", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5/journey	c82e46fb-4539-418a-b143-145d8d48d526	2026-02-27 08:33:18.28538
5f387fe9-ee0a-42f6-bf31-39987d9dd438	35323958	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	c82e46fb-4539-418a-b143-145d8d48d526	2026-02-27 08:33:18.514551
37c56526-0a03-4262-8a58-51be26634a78	35323958	page_view	{"page": "dashboard"}	/	c82e46fb-4539-418a-b143-145d8d48d526	2026-02-27 08:33:28.590301
43c857f1-3aad-4860-a2cd-d635a8d6829d	yuVB4U	page_view	{"page": "dashboard"}	/	3799f0cd-d6b4-4aa5-b126-63148af5d4a9	2026-02-27 08:39:19.706785
dfb7316b-8bdd-4807-a0f6-be45b0cd4273	yuVB4U	page_view	{"page": "dashboard"}	/	3799f0cd-d6b4-4aa5-b126-63148af5d4a9	2026-02-27 08:40:52.153356
834bd4d9-daaa-4ae0-a71d-02b8cd7fff8a	35323958	page_view	{"page": "dashboard"}	/	c82e46fb-4539-418a-b143-145d8d48d526	2026-02-27 08:43:24.5094
6ea9a2ab-08ae-4a68-b789-fb71b58d0614	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:48:42.225824
6a0b7e3d-9bf5-4b95-bee1-6ad4ae7dc960	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:48:42.4225
e3591433-f4ae-470c-bb9e-3429adaad496	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:50:08.45621
51a5b45c-fc78-4d6c-8d83-5aa70ad48e8c	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:50:08.744723
320db071-fee4-43aa-9d9d-8f8125c02e63	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:57:36.985523
0ff57d52-f32e-46ae-bebb-613b2a1c368c	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:57:37.183674
69251f47-e268-4197-977b-3c260516d9ce	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:59:02.141492
3c15d9a6-30b9-4571-9b17-6648bc1d79cb	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:59:02.379983
53bdfa61-de2f-4c82-810e-7699ef2081e1	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:01:40.122245
29208e5b-0929-435d-b0cb-01200b110072	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:01:40.218321
bc201e55-d685-4b87-a59b-a8eda80920ff	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:02:03.210422
617a5a45-3e5b-4323-879f-d79f388a387f	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:02:04.196016
8bb27461-1bc8-412b-b4ec-9389d444e8d5	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:02:38.757079
fe713763-137b-4551-8292-eb4646ea2ca6	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:02:39.039292
02042c5c-ec53-4200-a705-bcaa7ab91840	a8S2dP	page_view	{"page": "dashboard"}	/	0cce12a1-ccb1-4d24-8098-6bb258f10208	2026-02-27 09:03:06.550302
df64eb78-6017-45a2-a080-8f9067890f39	a8S2dP	page_view	{"page": "dashboard"}	/	0cce12a1-ccb1-4d24-8098-6bb258f10208	2026-02-27 09:04:19.792029
6ef67d72-7765-4005-8a56-4c5d9086ea29	a8S2dP	page_view	{"page": "dashboard"}	/	0cce12a1-ccb1-4d24-8098-6bb258f10208	2026-02-27 09:05:49.648883
3f1cb9a7-5c50-43c8-971b-7c037201d37c	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:07:42.436446
6d80cfbe-fa6c-4c8f-8149-6e5a7cd4b812	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:07:42.7336
860b3b5b-89c5-4376-a276-a0dbfae1a172	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:08:10.707669
5d9dc02b-ff1d-4f0e-a8f5-7e09441e36a4	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:08:10.925574
bf9a6588-ced0-4611-aef8-bfced50954d6	j69UEF	page_view	{"page": "dashboard"}	/	5ace6759-258c-4027-b010-f348785edc0d	2026-02-27 09:08:43.33804
6a75e0c4-e8fc-4d59-a6c9-e1433f0dbcf6	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:09:48.527465
ea150809-1513-4baa-9a19-91b17fff2828	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:09:48.697854
cbc5e47e-a12e-4660-accb-b0f6beed7d11	35323958	page_view	{"page": "dashboard"}	/	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 09:11:47.066709
3412b2a4-bff9-46c4-af69-3df43fd39827	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:12:14.664032
b02692c4-abb1-4609-8ba4-d404754c83b1	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:12:14.832978
03d46727-c9ef-4e3c-b4d0-549c5d01ad93	35323958	page_view	{"page": "dashboard"}	/	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 09:12:15.983272
bbf4116b-c03c-4e24-93e2-faa5ab849237	pIDdI2	page_view	{"page": "dashboard"}	/	c4fd2665-7e28-4db0-981f-a94564b04fc3	2026-02-27 09:12:33.761176
47f880d7-b2d1-4347-bcc8-6b89390f7e2d	pIDdI2	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	c4fd2665-7e28-4db0-981f-a94564b04fc3	2026-02-27 09:14:22.676592
e1df3f1a-c395-4ee3-926d-14dda606dfb6	pIDdI2	chapter_start	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "section": "chapter-summaries", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439/journey	c4fd2665-7e28-4db0-981f-a94564b04fc3	2026-02-27 09:14:29.250923
0177bebd-ec9b-4d4d-b7e2-c53d48a20d92	pIDdI2	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	c4fd2665-7e28-4db0-981f-a94564b04fc3	2026-02-27 09:14:51.708783
ef250a57-2cd8-4bfd-b3f5-0799399d4559	pIDdI2	audio_play	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/audio	c4fd2665-7e28-4db0-981f-a94564b04fc3	2026-02-27 09:15:04.106997
be7399cf-aef4-4f1f-b4c2-fe903a6c60f1	pIDdI2	page_view	{"page": "dashboard"}	/	c4fd2665-7e28-4db0-981f-a94564b04fc3	2026-02-27 09:15:49.322834
45c509bb-a7e1-4366-b96d-2c8d79cf617f	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:16:03.81774
b17d621a-5f73-4525-a33b-97e6b3df1f42	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:16:03.920655
4e14e09b-e3fe-4b08-aab8-2e14133e2f3d	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:17:32.500522
f39dd130-d817-4cb6-b5eb-9bbe56669d3e	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:17:32.616623
07d24cd8-1be8-4b60-bc05-70a4ee6688c9	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:18:19.078281
279903f2-2443-43e7-94cf-c6c278b3cd69	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:18:19.293781
257c584d-b869-43f2-a91d-a7e2b85370b7	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:19:19.70072
463dc7b2-1548-4a56-a917-766c8e4a0f6e	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:19:19.976475
40d80efd-4f97-4010-96b0-bed10e83e8b5	Jkp87u	page_view	{"page": "dashboard"}	/	3a2f9692-4dc2-4f86-9f1b-d6580d9c9470	2026-02-27 09:19:40.059173
06adfc67-e4e2-48d1-b369-75a6d3518f0b	Jkp87u	book_open	{"bookId": "23f2345b-6336-4573-a63f-8ee2cd34f56b", "bookTitle": "Man's Search for Meaning"}	/book/23f2345b-6336-4573-a63f-8ee2cd34f56b	3a2f9692-4dc2-4f86-9f1b-d6580d9c9470	2026-02-27 09:20:28.370659
65635799-19e8-424d-bb61-f0bf4ced11c2	Jkp87u	page_view	{"page": "dashboard"}	/	3a2f9692-4dc2-4f86-9f1b-d6580d9c9470	2026-02-27 09:20:37.252691
5bbcf4b2-6d2b-4f2e-b27d-18a8c885bebf	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:20:52.270909
18dedc89-d22c-454b-a97c-d8a6fa067831	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:20:52.443101
084ead4f-2e0f-450f-b910-ec78f7f1b74b	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:27:20.935851
9c3bcc9d-d7ea-49b6-a201-374c94f47a65	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:27:21.133081
eb316769-6b9b-4f13-b810-48c2df21b38a	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:29:04.786607
86eb6eca-eee4-453c-a9e6-9d07c63c4354	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:29:04.853771
5d43a16e-fa2c-45ce-ad5b-ee33e05d56b8	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:29:19.169858
bc61e39f-dddf-4fde-9079-6bc7bd9cf60c	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:29:19.265842
d404673d-901b-4ca9-9a8a-7c0d6899ebcc	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:30:02.17785
e091c118-12ae-4fc0-bcc8-f74bf21a7f31	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:30:02.294906
ab32d4d1-f797-4981-8af5-5c624bd84a98	tImpmS	page_view	{"page": "dashboard"}	/	6ba12c03-67ac-44d5-a2f6-92bf6a64ddb0	2026-02-27 09:30:25.063723
881686aa-c9bc-452f-8147-765469811999	tImpmS	page_view	{"page": "dashboard"}	/	6ba12c03-67ac-44d5-a2f6-92bf6a64ddb0	2026-02-27 09:32:09.499295
267d6985-8c79-4e4a-966e-ceb9a1f4e17c	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:32:19.470531
2bc0a680-e763-47b7-9e9b-3b64df5cda2e	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:32:19.666075
a2e72204-9605-444f-a7d2-48622fae2505	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:36:02.653761
244719f0-8a28-4229-95b0-213ccb31b2b3	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:46:49.598806
e5d23797-85e6-4325-a4cf-6bf2af6a6cdb	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:47:13.505538
c91f7093-4d2a-4cd0-a893-9479e0eb3e60	35323958	page_view	{"page": "dashboard"}	/	24d5aa3b-037d-4262-a78b-cc7d5f5311e4	2026-02-27 09:47:27.235708
089cf483-6ccb-4bbb-806a-c18295b6afce	35323958	page_view	{"page": "dashboard"}	/	24d5aa3b-037d-4262-a78b-cc7d5f5311e4	2026-02-27 09:47:41.870039
59d8f122-24f9-4335-9fa1-c2d62cb80099	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:47:42.063175
d65981f1-2c69-4265-8480-28ca8c66284e	9BmmO0	page_view	{"page": "dashboard"}	/	b36d3d8d-4517-456b-be28-2e2a7ef6a249	2026-02-27 09:48:27.188281
616fc4b5-ff72-4229-9bfc-57acab89e1d4	9BmmO0	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	b36d3d8d-4517-456b-be28-2e2a7ef6a249	2026-02-27 09:49:22.562921
9118c130-86fd-4a1e-9456-7074f9d95d8b	9BmmO0	page_view	{"page": "dashboard"}	/	b36d3d8d-4517-456b-be28-2e2a7ef6a249	2026-02-27 09:49:53.830245
603730c9-66b2-4b95-960e-ec44c176c51c	9BmmO0	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	b36d3d8d-4517-456b-be28-2e2a7ef6a249	2026-02-27 09:50:01.459302
727a7fca-5d2c-469d-8368-83d4de1c2088	9BmmO0	page_view	{"page": "dashboard"}	/	b36d3d8d-4517-456b-be28-2e2a7ef6a249	2026-02-27 09:52:01.796128
4e49172e-de96-4b6b-b847-b857168ee58a	35323958	page_view	{"page": "dashboard"}	/	24d5aa3b-037d-4262-a78b-cc7d5f5311e4	2026-02-27 09:52:27.723876
f993605c-059e-48ef-8453-1f8dfda0273d	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:52:27.927294
4ce4b82f-f49c-47b1-8846-1aae3f5d45ad	35323958	page_view	{"page": "dashboard"}	/	24d5aa3b-037d-4262-a78b-cc7d5f5311e4	2026-02-27 09:53:02.060849
e32adfaf-ad6a-4bcb-9049-ea0c283b297b	35323958	page_view	{"page": "dashboard"}	/	24d5aa3b-037d-4262-a78b-cc7d5f5311e4	2026-02-27 09:53:36.915201
2f0a9950-53b4-46f8-83db-e2f28c05023e	35323958	page_view	{"page": "dashboard"}	/	24d5aa3b-037d-4262-a78b-cc7d5f5311e4	2026-02-27 09:53:44.965651
5a81da94-a667-442b-a718-3e04f04a959d	35323958	page_view	{"page": "dashboard"}	/	24d5aa3b-037d-4262-a78b-cc7d5f5311e4	2026-02-27 10:08:58.110449
77bbd2c5-40c4-4e81-8fdd-4f04ee8a2b07	W46Jai	page_view	{"page": "dashboard"}	/	22bfbcf7-4a90-4ad4-8c5c-b778c5a67b6a	2026-02-27 10:13:38.440773
6459b20a-7018-42eb-a47d-9b60293ebecd	W46Jai	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	22bfbcf7-4a90-4ad4-8c5c-b778c5a67b6a	2026-02-27 10:14:19.359637
ddb46f2b-17dd-4b3b-8dcc-eebd082ac380	W46Jai	page_view	{"page": "dashboard"}	/	22bfbcf7-4a90-4ad4-8c5c-b778c5a67b6a	2026-02-27 10:15:24.021848
9819338c-b730-4e94-9373-ab546b3de2d6	35323958	page_view	{"page": "dashboard"}	/	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:27:20.428189
25afa516-2000-4ca5-a615-3c13e4c52cfd	35323958	book_open	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:27:33.335848
b3129936-9e51-4f9f-8b19-a880313581e3	35323958	chapter_start	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "section": "chapter-summaries", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0/journey	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:27:40.59253
471883b1-173a-4411-a786-e652f3a35650	35323958	chapter_complete	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "section": "chapter-summaries", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0/journey	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:27:49.72481
40b31444-eec3-4469-ac05-8a19a18f15f5	35323958	book_open	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:27:50.484043
380bc5d7-c7fa-4269-9504-fd77658c3376	35323958	chapter_start	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "section": "infographics", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0/journey	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:27:56.913437
74c9b88b-9c28-447c-b077-b01772256975	35323958	book_open	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:28:19.105866
8838699b-3e69-4204-b3f8-3b02aced1ea2	35323958	page_view	{"page": "dashboard"}	/	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:30:39.533024
2aaff772-e28b-4018-9c70-75823f7cf33d	35323958	page_view	{"page": "dashboard"}	/	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:31:16.400712
8b960a9c-481a-439c-bf16-2c9520251639	35323958	chapter_start	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "section": "chapter-summaries", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0/journey	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:31:56.725914
7da31d93-91fa-450b-8400-80101bb54ad6	35323958	page_view	{"page": "dashboard"}	/	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:32:00.569114
e5ad72d4-c482-470d-808f-60e069db8b72	35323958	chapter_start	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "section": "chapter-summaries", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0/journey	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:32:04.764683
60c5d0c8-3b74-411c-940f-b6bef7cb7d95	35323958	book_open	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:32:07.602898
ed2808b1-0e97-44a8-aab6-c245aa270c03	35323958	page_view	{"page": "dashboard"}	/	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:52:48.187589
8f848d1d-4544-4706-8e40-20f5ea0503ba	35323958	book_open	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:53:15.737829
450223f6-fd73-4341-a96b-dd107b0ec31e	oU-UWK	page_view	{"page": "dashboard"}	/	53dd4dc9-c27b-459f-acb2-70024b5ba79f	2026-02-27 14:59:41.238481
e32e7481-4899-4474-b90a-a7b1f187ea94	oU-UWK	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	53dd4dc9-c27b-459f-acb2-70024b5ba79f	2026-02-27 15:00:02.105701
2344957c-59b1-4389-802a-6c8171b58664	oU-UWK	page_view	{"page": "dashboard"}	/	53dd4dc9-c27b-459f-acb2-70024b5ba79f	2026-02-27 15:01:48.721989
e6c505c8-2988-42e7-b21f-57590804d9bb	oU-UWK	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	53dd4dc9-c27b-459f-acb2-70024b5ba79f	2026-02-27 15:02:16.85091
860c10f1-ec4d-45f9-aabb-32a956e08ed5	a_rJjy	page_view	{"page": "dashboard"}	/	db62ae2f-ef96-4a07-979f-657d81da9fdb	2026-02-27 15:05:16.314494
7ac37005-8798-43c3-9794-397e384453cb	a_rJjy	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	db62ae2f-ef96-4a07-979f-657d81da9fdb	2026-02-27 15:06:00.290945
3e34cff9-b4b6-4164-a8c3-3c9b037894c0	a_rJjy	page_view	{"page": "dashboard"}	/	db62ae2f-ef96-4a07-979f-657d81da9fdb	2026-02-27 15:07:16.0597
d743fa94-92a5-4f01-abe9-9c3a83c75d14	35323958	page_view	{"page": "dashboard"}	/	d0faed7d-3869-4830-a368-640b16311f60	2026-02-27 16:02:27.323121
fef98f19-b351-4167-a422-979e6f46a5c1	35323958	page_view	{"page": "dashboard"}	/	d0faed7d-3869-4830-a368-640b16311f60	2026-02-27 16:04:26.021528
9c044cdb-3aeb-4d76-a549-5fc201ce1a26	35323958	page_view	{"page": "dashboard"}	/	d0faed7d-3869-4830-a368-640b16311f60	2026-02-27 16:05:49.497168
7942b742-7bd6-4bca-b2bf-23f743950964	35323958	page_view	{"page": "dashboard"}	/	3475f3ec-77dd-41bd-8552-a25d88f76a38	2026-02-28 03:45:48.030261
e0ac9efa-e267-45b1-9013-b75ceaf67b0e	Wc93iB	page_view	{"page": "dashboard"}	/	d772043f-c4bb-433e-84ee-febca09bba48	2026-02-28 05:35:23.763859
e10b070f-e819-471b-9b16-a717c2925c9d	Wc93iB	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	d772043f-c4bb-433e-84ee-febca09bba48	2026-02-28 05:36:20.342212
cb99c446-0191-4ff4-9f40-703f30be13b8	Wc93iB	chapter_start	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "section": "infographics", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5/journey	d772043f-c4bb-433e-84ee-febca09bba48	2026-02-28 05:36:27.371789
cd290902-ba70-4f07-9b0b-269eb90233e2	Wc93iB	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	d772043f-c4bb-433e-84ee-febca09bba48	2026-02-28 05:36:37.47301
a610a186-597c-447c-b271-f23d09de0c1c	Wc93iB	page_view	{"page": "dashboard"}	/	d772043f-c4bb-433e-84ee-febca09bba48	2026-02-28 05:37:08.212996
e64b1ff2-7528-4e22-b4bf-1a89c0c4ad6e	Wc93iB	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	d772043f-c4bb-433e-84ee-febca09bba48	2026-02-28 05:37:22.93197
95566eee-db8c-490c-9a09-f69f38589050	8wB_v6	page_view	{"page": "dashboard"}	/	91366a41-655a-4194-9260-05d68eb8112c	2026-02-28 05:53:05.935902
c0d34dc9-c12c-4fad-b100-b8391bdd7e23	8wB_v6	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	91366a41-655a-4194-9260-05d68eb8112c	2026-02-28 05:53:41.975425
0253b5c2-fb2a-4bf2-8446-0e5bd5809fbf	8wB_v6	page_view	{"page": "dashboard"}	/	91366a41-655a-4194-9260-05d68eb8112c	2026-02-28 05:54:18.896993
8add6820-b4ac-446e-9312-acc5ce5c8a0b	8wB_v6	chapter_start	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "section": "chapter-summaries", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5/journey	91366a41-655a-4194-9260-05d68eb8112c	2026-02-28 05:54:32.326528
ab7fbec8-9350-4f75-8bfb-cf3694a7e6a8	8wB_v6	page_view	{"page": "dashboard"}	/	91366a41-655a-4194-9260-05d68eb8112c	2026-02-28 05:55:06.127552
75dbea49-a624-45a5-b701-24ba842f623a	35323958	page_view	{"page": "dashboard"}	/	71da6049-e282-46af-950a-db24a4a19433	2026-02-28 06:50:57.65809
438a3947-811f-4268-9fef-1590e6178fde	35323958	page_view	{"page": "dashboard"}	/	71da6049-e282-46af-950a-db24a4a19433	2026-02-28 06:51:28.008117
9a3a6785-7061-4b13-8ca7-91870c47e57a	35323958	page_view	{"page": "dashboard"}	/	71da6049-e282-46af-950a-db24a4a19433	2026-02-28 06:53:03.467353
f65605ac-f6e4-40c7-a26a-12fd6a8996c1	35323958	chapter_start	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "section": "chapter-summaries", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5/journey	71da6049-e282-46af-950a-db24a4a19433	2026-02-28 06:53:09.469059
656d57a0-d856-49a5-bff1-c4841197e511	35323958	page_view	{"page": "dashboard"}	/	71da6049-e282-46af-950a-db24a4a19433	2026-02-28 06:53:49.753092
418b82a4-6aea-4755-a6af-5a9c64316826	35323958	page_view	{"page": "dashboard"}	/	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:07:24.850867
12967e7f-5af6-458b-b5a2-b20c2db6bd95	35323958	page_view	{"page": "dashboard"}	/	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:07:26.783765
0a4411d2-eb47-4334-9980-33dd44ea4e1e	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:07:46.205233
b9fa58d7-9697-4bef-8eaf-8859135076a2	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:08:10.488583
292984cf-713e-4a22-989d-ed3956ce7c1c	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:10:29.07327
8948d7b0-6e3c-4271-b0c6-820642282b2a	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:10:57.564688
42685506-2e79-4a7c-b1e7-5a19019f821e	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:11:02.12432
e7dda05e-0acc-43f1-a8e6-d938767ea0fd	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:11:13.436267
7c7243a8-e7e8-4620-8b09-27ba6ed93b6d	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:11:18.08191
7bde153d-5ae6-45c2-bd57-e389e4ab3233	35323958	page_view	{"page": "dashboard"}	/	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:11:40.423207
a604fbd4-6d13-42d5-8837-539e0f22867f	35323958	page_view	{"page": "dashboard"}	/	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:12:17.451612
632799bd-d74e-48f1-a449-c8dc7dde6dea	35323958	page_view	{"page": "dashboard"}	/	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:12:57.748259
ccb43b4e-5863-4207-822b-6b684d66ea87	35323958	page_view	{"page": "dashboard"}	/	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:13:09.958809
0fc09d30-3f32-47a7-8afa-2e36a4da5305	z5Axnh	page_view	{"page": "dashboard"}	/	d25dc01e-4b7d-41d5-a956-631c1e9b0e49	2026-02-28 07:13:30.415954
741c7c08-39e5-4f48-950b-bd14c5eda198	z5Axnh	page_view	{"page": "dashboard"}	/	d25dc01e-4b7d-41d5-a956-631c1e9b0e49	2026-02-28 07:14:23.954176
bf9ed1f9-24f9-40ce-a990-ae8814709a0a	z5Axnh	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	d25dc01e-4b7d-41d5-a956-631c1e9b0e49	2026-02-28 07:14:38.940195
8b8940d9-87db-4021-b795-db22f7968966	z5Axnh	page_view	{"page": "dashboard"}	/	d25dc01e-4b7d-41d5-a956-631c1e9b0e49	2026-02-28 07:15:22.032404
f380d06f-6cb0-4ee1-be02-1da35dca78ca	z5Axnh	page_view	{"page": "dashboard"}	/	d25dc01e-4b7d-41d5-a956-631c1e9b0e49	2026-02-28 07:16:04.80904
64f3a228-0ead-4c5c-a0fa-a7588131cea4	z5Axnh	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	d25dc01e-4b7d-41d5-a956-631c1e9b0e49	2026-02-28 07:16:18.833968
367b1337-262d-4eab-a7fd-3d7bc3d5daaf	35323958	page_view	{"page": "dashboard"}	/	a2e3000b-1a80-47d2-bccc-33649172593f	2026-02-28 07:22:31.045778
a10f5ffe-9372-4b86-a324-f67bbe45c004	35323958	chapter_start	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "section": "chapter-summaries", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5/journey	a2e3000b-1a80-47d2-bccc-33649172593f	2026-02-28 07:22:36.358475
278c4667-6424-4d65-b228-057d9c5a1d75	35323958	chapter_start	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "section": "chapter-summaries", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5/journey	a2e3000b-1a80-47d2-bccc-33649172593f	2026-02-28 07:22:53.539823
9da3b98f-c892-4505-9c38-76c37d50e72a	35323958	page_view	{"page": "dashboard"}	/	d886bdac-6b28-42dd-bf90-151270ac9d34	2026-02-28 16:46:00.301598
9d8166d9-8d5f-475e-8846-d64e7fed57fc	aZw-6w	page_view	{"page": "dashboard"}	/	f57aae04-727d-4c68-9600-b804bef6c133	2026-02-28 18:58:33.389856
4a0b066e-ed1b-46b5-95a4-2c253e57cf0f	aZw-6w	page_view	{"page": "dashboard"}	/	f57aae04-727d-4c68-9600-b804bef6c133	2026-02-28 19:00:21.778995
82abdce7-d3c6-4d21-9e77-5cea53a1722c	1udX-Q	page_view	{"page": "dashboard"}	/	ded7c059-92dd-4b3e-b923-f6f43403182a	2026-02-28 19:19:03.483843
60a28e07-9040-4035-842e-58b675f44f25	BQ7kP2	page_view	{"page": "dashboard"}	/	2682e715-609a-4099-96a6-8c331c9a240f	2026-02-28 20:48:03.116602
a32c572a-8f00-4fc5-b315-9da748d9fbe7	test-user-999	page_view	{"page": "dashboard"}	/	b0c40823-80b2-4c0d-b42b-6a6cb0f0d03e	2026-02-28 21:33:56.876478
c3e6a934-a1ab-4029-a370-6691f8b1523d	test-sweep-001	page_view	{"page": "dashboard"}	/	9e562b11-8c90-463c-898d-706975e1194b	2026-02-28 21:42:26.70886
c54f59a5-b6c8-4b6b-9fed-c06d59618a91	test-fix-007	page_view	{"page": "dashboard"}	/	2fe9f431-c29c-4ac0-b695-b1ee748995f1	2026-02-28 22:08:14.849024
d4283776-7585-4386-9822-a785fdde0804	test-fix-007	book_open	{"bookId": "23f2345b-6336-4573-a63f-8ee2cd34f56b", "bookTitle": "Man's Search for Meaning"}	/book/23f2345b-6336-4573-a63f-8ee2cd34f56b	2fe9f431-c29c-4ac0-b695-b1ee748995f1	2026-02-28 22:08:57.392225
8fbaf4d3-96c4-4191-b7ef-36f98591d4ea	admin-check-001	page_view	{"page": "dashboard"}	/	7147d41f-d3cc-41a6-82fd-c78d0011095b	2026-02-28 22:29:29.171134
08c0116b-8975-4879-b926-2d99ef2ca9f7	admin-check-001	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	7147d41f-d3cc-41a6-82fd-c78d0011095b	2026-02-28 22:29:38.511596
3a7d4019-72cf-4c85-af0b-a45c63799503	test-buttons-001	page_view	{"page": "dashboard"}	/	9bba290c-e953-4f88-8c28-16159325cc65	2026-02-28 22:31:24.850707
c572ca98-e632-4a27-8e68-3495877530b3	test-buttons-001	book_open	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	9bba290c-e953-4f88-8c28-16159325cc65	2026-02-28 22:32:28.312905
dc8df7b8-9b06-4c25-b545-c85696301877	35323958	page_view	{"page": "dashboard"}	/	bab99c7c-70bf-4a79-ba64-ebaa310543ed	2026-02-28 23:16:01.58857
12c6ea47-d7fd-4584-9b62-b49ddf419574	35323958	page_view	{"page": "dashboard"}	/	bab99c7c-70bf-4a79-ba64-ebaa310543ed	2026-02-28 23:18:34.785646
1ef1b540-d3d3-41ee-9e2f-30a02f30178e	35323958	page_view	{"page": "dashboard"}	/	bab99c7c-70bf-4a79-ba64-ebaa310543ed	2026-02-28 23:18:50.108116
0dc5feb2-f57e-451a-b813-9893047376f4	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:19:23.426339
f5cdaf24-59d8-481c-8490-9ff9f8d61572	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:19:40.456683
af7aee7f-27cf-46e9-bbc0-89fe5489389f	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:20:08.234754
0aac2f4b-0862-4bd2-9c6b-a07c100c49e8	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:20:36.417927
5e261a97-cf8b-4bbc-afdd-8699f6a02d00	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:21:05.602275
4a26f60b-577d-4a7b-af80-b732235908f2	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:22:22.6359
35aa5eef-763c-40e7-93e2-c66c1aee1298	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:22:31.544563
310de0e2-3391-4dc6-85b0-8b521f50d86b	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:22:46.455041
20a752ec-8419-4b9f-be66-24f9441146f2	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:23:05.030225
dea5f350-6336-487e-912f-e23f29a0e8ae	35323958	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:23:23.100073
e1ea1bc2-55f2-4f15-8461-530ac09f378b	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:23:35.607951
0b30e65b-d758-4dbf-879b-cc9ea9011b63	35323958	page_view	{"page": "dashboard"}	/	9e439eb7-3a0d-4b85-b347-00eec381006a	2026-02-28 23:23:36.556943
e553583d-de9d-4c27-8ef5-d50529462f79	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:23:45.334828
58b553a8-4d3b-4fdc-abc2-f79901a1b025	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:24:30.542035
3e581d6e-30ea-4bce-ba71-5afa2114545e	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:25:33.247584
252c6b6f-a9e0-421a-b2ec-85c76b046112	35323958	page_view	{"page": "dashboard"}	/	b5e12b0b-4019-42d5-83b1-3fd0b974ff48	2026-02-28 23:25:41.639393
ad39960f-e5cd-4586-973c-d4fd39a91245	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:26:35.915432
89753a49-51f4-49e7-b373-54bac20a53c1	35323958	page_view	{"page": "dashboard"}	/	aaf1656d-0579-4be4-b43d-8ec0c02f6be2	2026-03-01 01:18:04.371697
e6943f24-f854-44a9-b770-0aa0532d7ea0	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	aaf1656d-0579-4be4-b43d-8ec0c02f6be2	2026-03-01 01:18:27.615921
b1315304-f53e-4133-a1be-56bd16be487c	35323958	chapter_start	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "section": "shorts", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439/journey	aaf1656d-0579-4be4-b43d-8ec0c02f6be2	2026-03-01 01:18:50.840462
c7b461eb-5a09-4539-a59e-49b213f43289	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	aaf1656d-0579-4be4-b43d-8ec0c02f6be2	2026-03-01 01:18:54.169107
25238735-3c73-4589-9bb7-083afed28bcc	35323958	chapter_start	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "section": "mental-models", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439/journey	aaf1656d-0579-4be4-b43d-8ec0c02f6be2	2026-03-01 01:18:59.432475
6119c373-20c1-44fa-b7e5-59e3807e72b5	35323958	chapter_complete	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "section": "mental-models", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439/journey	aaf1656d-0579-4be4-b43d-8ec0c02f6be2	2026-03-01 01:19:04.456025
ea15464c-5e16-4d37-bace-ed2988f72782	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	aaf1656d-0579-4be4-b43d-8ec0c02f6be2	2026-03-01 01:19:05.066602
1f87aa95-1348-4547-841f-d3bbfe10e8a0	35323958	page_view	{"page": "dashboard"}	/	1368e3f4-a6b0-419d-98a7-8ad1589b38c2	2026-03-01 02:29:48.346592
3817a5b8-472c-436c-b5e2-b50014e8557b	35323958	page_view	{"page": "dashboard"}	/	1368e3f4-a6b0-419d-98a7-8ad1589b38c2	2026-03-01 02:30:35.533005
4ad2c8a3-daaa-402d-b0a6-130729325790	35323958	page_view	{"page": "dashboard"}	/	1368e3f4-a6b0-419d-98a7-8ad1589b38c2	2026-03-01 02:36:23.62244
5082df98-6c8f-4485-abc5-9d4ae1b432ac	35323958	chapter_start	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "section": "chapter-summaries", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439/journey	1368e3f4-a6b0-419d-98a7-8ad1589b38c2	2026-03-01 02:37:25.850932
0782dc56-6a71-4bbe-ac48-7584ff3d2327	35323958	page_view	{"page": "dashboard"}	/	b93c9f36-f78b-4619-b96b-fb0913dba463	2026-03-01 03:37:09.340497
768e43e2-f4d2-43d8-82d8-5322ed3f54ca	kWBQ4S	page_view	{"page": "dashboard"}	/	a69793bc-110b-432f-bf81-d3d7e2670ad4	2026-03-01 06:49:19.446518
774c8523-1622-41f3-a0eb-8d1050a0a20d	RqfxU0	page_view	{"page": "dashboard"}	/	8c3497fd-fa8c-4cc4-809b-96f671a1e016	2026-03-01 07:13:12.262407
2ae07862-1949-466c-97e5-453f6e05588e	RqfxU0	book_open	{"bookId": "83a8013d-9483-4495-a6f8-9bbdbdf6ecd2", "bookTitle": "The Power of Now"}	/book/83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	8c3497fd-fa8c-4cc4-809b-96f671a1e016	2026-03-01 07:13:47.362128
841c1a82-d1f6-4feb-ae43-d3de2378aff7	WJNhpw	page_view	{"page": "dashboard"}	/	a7ecbdee-63bd-4e20-88be-0befb240f69b	2026-03-01 17:41:37.595932
941dc285-6db4-405a-b108-29357b3fc292	WJNhpw	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	a7ecbdee-63bd-4e20-88be-0befb240f69b	2026-03-01 17:42:25.134414
64bf8ac0-7e04-4bbb-b373-35ff015e43ca	WJNhpw	chapter_start	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "section": "chapter-summaries", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5/journey	a7ecbdee-63bd-4e20-88be-0befb240f69b	2026-03-01 17:42:36.968065
056c205f-8380-4d6d-b21a-8fc06f1145a7	-GHxm6	page_view	{"page": "dashboard"}	/	b5a0f9f2-4b3f-4312-b1d7-57b4e0bc3345	2026-03-01 20:15:35.963358
c7ae51b5-0f29-49fc-abd4-652d02b2c43d	-GHxm6	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	b5a0f9f2-4b3f-4312-b1d7-57b4e0bc3345	2026-03-01 20:16:36.560767
4c64b710-5f8a-4648-9859-26d021b4d4bd	f0PZaY	page_view	{"page": "dashboard"}	/	3e839cde-c2d2-44b3-8919-3d157d7a09ac	2026-03-01 22:09:24.649152
07cd2a0e-c692-4154-8e82-c23ddc15cce2	f0PZaY	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	3e839cde-c2d2-44b3-8919-3d157d7a09ac	2026-03-01 22:10:45.750967
a9e6ef90-6fd8-4122-9fac-49e121c4958b	E4d0vZ	page_view	{"page": "dashboard"}	/	6d24a03b-6e1d-477a-ae92-026e5f70cee5	2026-03-01 22:29:37.860653
27ad9763-26a1-4d0f-8a34-6799688fcf9e	E4d0vZ	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	6d24a03b-6e1d-477a-ae92-026e5f70cee5	2026-03-01 22:30:31.607493
d533b56e-66e6-4304-88ac-d92ffe1e2973	E4d0vZ	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	6d24a03b-6e1d-477a-ae92-026e5f70cee5	2026-03-01 22:31:34.719475
bddf1c14-a224-4661-8d7d-47f186ab91a7	E4d0vZ	chapter_start	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "section": "chapter-summaries", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5/journey	6d24a03b-6e1d-477a-ae92-026e5f70cee5	2026-03-01 22:31:44.013728
3da10f9f-0dd1-41f9-9c22-f47875409799	E4d0vZ	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	6d24a03b-6e1d-477a-ae92-026e5f70cee5	2026-03-01 22:31:56.21504
4bafef37-2ee5-434e-b4dc-9f2a9250f71f	G35IpT	page_view	{"page": "dashboard"}	/	abbd5d57-ed7d-4188-9c5b-6425615f9152	2026-03-01 23:04:32.508027
beac12a3-767d-4474-af9f-14964cc2988b	nEiu_1	page_view	{"page": "dashboard"}	/	aa1ffd1e-1047-4ec4-ae36-135aa1e42ecd	2026-03-01 23:07:55.931941
121c69d5-4746-48ce-9510-b1f5ea8d09a7	nEiu_1	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	aa1ffd1e-1047-4ec4-ae36-135aa1e42ecd	2026-03-01 23:09:00.685929
2e72f5c0-3555-482b-93a3-f2b32522ee09	nEiu_1	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	aa1ffd1e-1047-4ec4-ae36-135aa1e42ecd	2026-03-01 23:09:38.691703
8467f601-f959-49fa-8515-0e18b1eba89c	nEiu_1	chapter_start	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "section": "chapter-summaries", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5/journey	aa1ffd1e-1047-4ec4-ae36-135aa1e42ecd	2026-03-01 23:09:52.723534
640d8dd7-41e8-4ad3-8aec-97fee890366d	nEiu_1	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	aa1ffd1e-1047-4ec4-ae36-135aa1e42ecd	2026-03-01 23:10:14.44494
e8001d36-7a4f-4b1a-a0c5-dea9b43696f3	nEiu_1	page_view	{"page": "dashboard"}	/	aa1ffd1e-1047-4ec4-ae36-135aa1e42ecd	2026-03-01 23:10:23.760177
f9c9e3cb-6491-4a00-b085-3f9a37e1f755	VouA0h	page_view	{"page": "dashboard"}	/	5e9eaf39-4098-4421-bddd-f791a815126c	2026-03-01 23:54:42.51062
d31cbe0a-7b3b-4887-9634-ac964b842d79	VouA0h	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	5e9eaf39-4098-4421-bddd-f791a815126c	2026-03-01 23:55:32.360757
bf7e2d68-f793-4e4f-9fe7-41ccb0c7e3dd	hE9ikf	page_view	{"page": "dashboard"}	/	16fb91ab-5cf9-4fac-b364-ee3cbe2d567e	2026-03-02 00:12:59.92191
eabbaaac-4dd9-4cba-b4cf-04de29796042	hE9ikf	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	16fb91ab-5cf9-4fac-b364-ee3cbe2d567e	2026-03-02 00:13:37.59638
d1902af6-c28c-450d-9d18-323d3f09bd25	72Nckd	page_view	{"page": "dashboard"}	/	877de9ba-ec21-48c3-8ebf-6c08dab972da	2026-03-02 00:44:40.632595
a8e03137-7e19-48b1-b92d-55cb45ccca13	72Nckd	page_view	{"page": "dashboard"}	/	877de9ba-ec21-48c3-8ebf-6c08dab972da	2026-03-02 00:45:15.105675
f52fe675-88d2-40df-9de8-035975a298b2	72Nckd	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	877de9ba-ec21-48c3-8ebf-6c08dab972da	2026-03-02 00:45:41.903178
3b513839-ad67-41cb-98be-53e67b72a610	bugfix-test-1772413553541	page_view	{"page": "dashboard"}	/	39333e33-e013-4cb2-928a-1e423de5f353	2026-03-02 01:06:38.234165
5faa5ab4-d55d-4243-95ed-ec43f6b20d38	bugfix-test-1772413553541	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	39333e33-e013-4cb2-928a-1e423de5f353	2026-03-02 01:07:09.348295
2834a2f5-7185-40fa-98f3-dc6392cfa062	bugfix-test-1772413553541	chapter_start	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "section": "shorts", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439/journey	39333e33-e013-4cb2-928a-1e423de5f353	2026-03-02 01:07:32.590296
2bcd5688-8957-4106-b958-4717067ef854	bugfix-test-1772413553541	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	39333e33-e013-4cb2-928a-1e423de5f353	2026-03-02 01:07:44.023211
130558f8-235b-4227-aec9-54bf9fb51bf3	bugfix-test-1772413553541	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	39333e33-e013-4cb2-928a-1e423de5f353	2026-03-02 01:08:23.017383
5435b962-c90e-4a04-a5aa-467e3da724a0	bugfix-test-1772413553541	page_view	{"page": "dashboard"}	/	39333e33-e013-4cb2-928a-1e423de5f353	2026-03-02 01:08:36.27316
1e5e9b8c-eb02-4306-b064-d1057e814674	bugfix-test-1772413553541	chapter_start	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "section": "chapter-summaries", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439/journey	39333e33-e013-4cb2-928a-1e423de5f353	2026-03-02 01:08:43.968236
c380ff3d-9e0b-468b-8055-0e9b75e9a88a	bugfix-test-1772413553541	page_view	{"page": "dashboard"}	/	39333e33-e013-4cb2-928a-1e423de5f353	2026-03-02 01:08:56.431668
edb1d2a0-6e28-42bd-be83-b3e72ace5a72	35323958	page_view	{"page": "dashboard"}	/	bac9a517-7ccb-40fd-ae96-59f6bbddbbcd	2026-03-02 18:13:15.33548
b52db4fd-807e-4d5e-8345-4b3fbc5d90c5	1l02Ad	page_view	{"page": "dashboard"}	/	95529293-e114-40a8-bd53-2aed674d7aa1	2026-03-05 01:35:41.922384
e6fbc9e1-877a-47e7-a2c5-73e1060c6c1d	35323958	chapter_start	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "section": "chapter-summaries", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5/journey	bac9a517-7ccb-40fd-ae96-59f6bbddbbcd	2026-03-02 18:14:00.203151
604082f4-de38-4fc8-8400-d4a8f4fe8e22	35323958	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	bac9a517-7ccb-40fd-ae96-59f6bbddbbcd	2026-03-02 18:14:03.524583
ced74f90-a90f-4e75-8fbb-96635c22deb8	35323958	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	bac9a517-7ccb-40fd-ae96-59f6bbddbbcd	2026-03-02 18:14:39.742429
10d8d272-0210-405e-a37b-7971a9f438b8	35323958	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	bac9a517-7ccb-40fd-ae96-59f6bbddbbcd	2026-03-02 18:22:53.13981
5fd072ef-27cb-4082-b580-c67e50e038c3	35323958	page_view	{"page": "dashboard"}	/	bac9a517-7ccb-40fd-ae96-59f6bbddbbcd	2026-03-02 18:22:56.936445
d0537edb-c3ce-42ad-b71f-d3ab4dc17ada	35323958	page_view	{"page": "dashboard"}	/	bac9a517-7ccb-40fd-ae96-59f6bbddbbcd	2026-03-02 18:23:19.077161
fb574abd-ad4e-4945-b8df-8b34a3d6bbd6	35323958	page_view	{"page": "dashboard"}	/	bac9a517-7ccb-40fd-ae96-59f6bbddbbcd	2026-03-02 18:23:30.845978
f63724ef-f96d-49cb-9fc0-77da9d33ec9e	35323958	page_view	{"page": "dashboard"}	/	bac9a517-7ccb-40fd-ae96-59f6bbddbbcd	2026-03-02 18:29:29.648174
48b914ce-924e-488c-bb81-54deb427a64e	35323958	page_view	{"page": "dashboard"}	/	bac9a517-7ccb-40fd-ae96-59f6bbddbbcd	2026-03-02 18:29:32.161961
e94aa0bb-45ee-427f-89ad-56e6e5ed5b0e	35323958	page_view	{"page": "dashboard"}	/	bac9a517-7ccb-40fd-ae96-59f6bbddbbcd	2026-03-02 18:30:06.043768
48ab327b-33f6-49f6-a9cb-ca1c35627605	35323958	page_view	{"page": "dashboard"}	/	cf5398af-3b4b-421d-99f3-ca874b898cfc	2026-03-02 19:45:19.159934
ec057150-547b-4e22-a95e-d8519630d283	35323958	page_view	{"page": "dashboard"}	/	cf5398af-3b4b-421d-99f3-ca874b898cfc	2026-03-02 19:50:02.468796
7832d465-6a80-47ea-95c3-fbf06952e55e	35323958	page_view	{"page": "dashboard"}	/	cf5398af-3b4b-421d-99f3-ca874b898cfc	2026-03-02 19:50:06.530677
747f1c82-6254-4012-9ad8-cae2685d495c	35323958	page_view	{"page": "dashboard"}	/	aa25dfec-490e-48f1-9d16-8c19ba36142f	2026-03-03 02:10:19.840328
1c57bd63-0499-49f5-a11a-ad2bbbfbc12f	35323958	page_view	{"page": "dashboard"}	/	aa25dfec-490e-48f1-9d16-8c19ba36142f	2026-03-03 02:11:00.493983
2f4196dd-f028-4da6-9846-c0ec99dfa30e	35323958	page_view	{"page": "dashboard"}	/	7c067db2-f419-4b37-99ab-870688a4834b	2026-03-03 08:46:05.999204
1351d854-468c-452f-8de8-e6529ba9f6f1	35323958	page_view	{"page": "dashboard"}	/	7c067db2-f419-4b37-99ab-870688a4834b	2026-03-03 08:47:16.41574
8d3d0ae5-b0ef-458e-a8e7-13b19160b9bb	35323958	page_view	{"page": "dashboard"}	/	7c067db2-f419-4b37-99ab-870688a4834b	2026-03-03 08:48:16.023217
c010b9e3-7809-4911-9d97-4a4fd020f36f	35323958	page_view	{"page": "dashboard"}	/	527b8b58-6d2f-4c04-80cd-5f93b87ab425	2026-03-04 18:24:17.490018
52e148f5-b16b-4339-baff-6e399963a4aa	35323958	page_view	{"page": "dashboard"}	/	527b8b58-6d2f-4c04-80cd-5f93b87ab425	2026-03-04 18:24:39.171232
23a1de81-5385-47db-b3ff-43774790b685	35323958	page_view	{"page": "dashboard"}	/	527b8b58-6d2f-4c04-80cd-5f93b87ab425	2026-03-04 18:24:51.559264
550699e0-4b1b-4deb-9bcb-e3b75eddc3f1	35323958	page_view	{"page": "dashboard"}	/	90d17508-aaf7-4d4d-bb74-6cc03552343c	2026-03-04 22:28:18.750533
39d37afc-71ce-400f-81af-6783e85f30b9	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:03:41.50556
6e02584b-0694-4a88-8f42-a3a802d152bb	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:05:49.825514
2b32ea7b-941b-4b8c-8f94-31d3c8a52319	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:06:05.240461
4e5e96fd-a41e-4079-a75e-5540b985f4e9	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:06:14.404242
a67c6fd9-2ee4-43bd-a380-c4d00b5aee21	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:09:02.822587
b6dd2c58-fedb-43cc-a2b6-98006b8cbc2c	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:09:05.110745
4c40e659-ebea-4d84-9199-8626446c5b07	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:09:33.317051
a03b9509-c0b7-42a6-8e80-d14b0bad9c77	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:09:44.734744
9b5abdbb-b8eb-40f0-a721-adbbe80e0d1f	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:12:24.526385
fbc5aafc-8e1a-4f66-8f41-70744108c47f	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:17:55.489242
9960e6e2-a98a-4856-abde-937a9b915b64	35323958	page_view	{"page": "dashboard"}	/	0a0cff40-034a-4ef7-af2b-a772ad67f02f	2026-03-05 00:18:15.909826
c0a623be-0762-4431-972d-219cf5892d5b	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:18:40.684822
762090fd-4011-4e43-beef-4e3dc36d95c4	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:25:53.988177
ceb65dea-dd3c-485f-ad75-93970c56567d	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:25:56.224872
42a25190-b27b-44bb-976b-98dd5d0ab706	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:29:25.535321
db0c3af1-ded8-4396-be12-b599ad549841	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:29:28.140496
05fdd9d4-f23d-45bc-a8b0-5317bc770c45	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:30:05.8466
c8d35d11-fe68-436c-9980-73331a3e8adc	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:30:11.179939
db36d082-47e0-425d-9aec-aadad590f4cc	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:33:27.568048
6a0ff73c-89a2-452d-9338-69da1aea0e6d	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:34:45.671459
81927b02-828d-4939-98ed-675d003fda6e	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:37:42.796391
83f08db8-82d9-4f81-9acd-36e6de4eb4b6	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:37:56.632004
3594cc6f-3308-41a0-9d7c-99d9e74c37ab	35323958	page_view	{"page": "dashboard"}	/	b7a5cd74-f5b5-44c6-ba54-8195f74cdff6	2026-03-05 00:38:41.223241
0e362706-3215-4a43-88a7-7d58e5425625	35323958	page_view	{"page": "dashboard"}	/	f289a254-35ee-432c-bb00-4a078e67a828	2026-03-05 00:39:08.640153
30ad1781-0293-4ab0-af51-827820645046	UyErpn	page_view	{"page": "dashboard"}	/	d79a881a-54fa-4640-b31f-704b681935eb	2026-03-05 01:31:35.038395
3326516d-58f5-406e-8523-a59f3e418ccc	1l02Ad	page_view	{"page": "dashboard"}	/	95529293-e114-40a8-bd53-2aed674d7aa1	2026-03-05 01:38:30.632434
3f139682-81c1-43c5-b75b-8e6c32f4b379	35323958	page_view	{"page": "dashboard"}	/	06dfb7a6-34d3-4d6d-a31b-2b46495b163b	2026-03-05 07:39:02.04713
b679ff89-d6b5-4df1-9927-4f8976687ca4	35323958	page_view	{"page": "dashboard"}	/	06dfb7a6-34d3-4d6d-a31b-2b46495b163b	2026-03-05 07:47:36.684322
09a09a34-23d7-4f69-bb70-f97a52ac3b36	35323958	page_view	{"page": "dashboard"}	/	06dfb7a6-34d3-4d6d-a31b-2b46495b163b	2026-03-05 07:51:55.632487
bc5dc9b7-054f-4f6e-93c5-25c31726e54f	35323958	page_view	{"page": "dashboard"}	/	06dfb7a6-34d3-4d6d-a31b-2b46495b163b	2026-03-05 07:54:20.074298
a3e38ebb-26a1-4228-8bea-e2a9f42f0ca2	35323958	page_view	{"page": "dashboard"}	/	06dfb7a6-34d3-4d6d-a31b-2b46495b163b	2026-03-05 07:54:22.249369
5ec6a2ed-16b4-4fa6-9862-02ed8bd7e696	35323958	page_view	{"page": "dashboard"}	/	06dfb7a6-34d3-4d6d-a31b-2b46495b163b	2026-03-05 07:56:02.820298
4dd5b3b0-3ec6-4ebe-81f3-65e5c89076f2	e2e-test-1772698062436	page_view	{"page": "dashboard"}	/	56bafb95-1d7d-48e2-93fc-bb2a1172e5d1	2026-03-05 08:08:18.705356
71643dac-36a7-4405-98a3-98648f036312	e2e-test-1772698062436	page_view	{"page": "dashboard"}	/	56bafb95-1d7d-48e2-93fc-bb2a1172e5d1	2026-03-05 08:08:35.307612
33fb752a-bf5d-4fdc-898e-91994b1a444a	35323958	page_view	{"page": "dashboard"}	/	06dfb7a6-34d3-4d6d-a31b-2b46495b163b	2026-03-05 09:25:04.397733
8a019661-276b-45f6-8406-42c7942a2058	35323958	page_view	{"page": "dashboard"}	/	06dfb7a6-34d3-4d6d-a31b-2b46495b163b	2026-03-05 09:27:11.7028
7cbcb4d8-01a6-479e-b924-7f0a9d439857	35323958	page_view	{"page": "dashboard"}	/	06dfb7a6-34d3-4d6d-a31b-2b46495b163b	2026-03-05 09:27:29.602041
b009c783-3419-4f8c-b585-3f5675323d13	35323958	page_view	{"page": "dashboard"}	/	06dfb7a6-34d3-4d6d-a31b-2b46495b163b	2026-03-05 09:28:42.814274
dc27931e-5c18-4edd-972f-07a931875591	35323958	page_view	{"page": "dashboard"}	/	06dfb7a6-34d3-4d6d-a31b-2b46495b163b	2026-03-05 09:29:35.385965
62bf0563-021b-4312-995b-a789d8f23ee3	35323958	page_view	{"page": "dashboard"}	/	06dfb7a6-34d3-4d6d-a31b-2b46495b163b	2026-03-05 09:30:15.093879
082ec641-0677-45ee-8b22-f0d29aaa3968	35323958	page_view	{"page": "dashboard"}	/	06dfb7a6-34d3-4d6d-a31b-2b46495b163b	2026-03-05 09:32:53.314655
d0d8eab1-67bb-4e94-a8e0-d34b22799038	35323958	page_view	{"page": "dashboard"}	/	06dfb7a6-34d3-4d6d-a31b-2b46495b163b	2026-03-05 09:32:55.653165
70a57ffe-1ce3-4d17-b215-ea580eb1ad32	35323958	page_view	{"page": "dashboard"}	/	4dddb5e3-f0de-4a37-a1bf-8efcdb0cb66f	2026-03-06 00:58:00.389108
2a56c0d6-0a27-4008-afee-1b703bbc2095	35323958	page_view	{"page": "dashboard"}	/	6e62282a-e6c0-4a3a-96d6-2998b1a3ab6e	2026-03-06 19:14:09.061011
d7acfd6b-0d83-4650-87a1-c7a940b359f7	35323958	page_view	{"page": "dashboard"}	/	6e62282a-e6c0-4a3a-96d6-2998b1a3ab6e	2026-03-06 19:19:10.71582
656e9df4-fee3-418f-9ff6-9c05400337df	35323958	page_view	{"page": "dashboard"}	/	e52d52a7-e235-44ef-8cc0-ac7a3fe76185	2026-03-06 19:55:13.364569
740f607e-b271-4fb5-9de5-9a67a7f03b6f	35323958	page_view	{"page": "dashboard"}	/	e52d52a7-e235-44ef-8cc0-ac7a3fe76185	2026-03-06 19:57:22.970889
f5610d17-0b26-4aa2-8770-146ecd1a6449	35323958	page_view	{"page": "dashboard"}	/	891d61fc-f813-4561-901b-7115d7f5da72	2026-03-06 21:44:08.605953
ad24a8b8-e1ad-45ae-82ac-906fbf164771	35323958	page_view	{"page": "dashboard"}	/	e5757c50-c386-4cfe-b8e1-be453c264560	2026-03-06 21:44:34.49552
980539f0-70c2-435a-b2b3-cecb0d5eacae	35323958	page_view	{"page": "dashboard"}	/	7c7a9def-a198-4b69-867c-c85aa58121d9	2026-03-06 23:58:36.621622
\.


--
-- Data for Name: book_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.book_versions (id, book_id, version_type, content, created_at, created_by, published_at) FROM stdin;
143787df-0ea8-4b9d-8906-719a1afddd6d	2ea408e9-dc96-444c-a0dc-93901f9029b5	draft	{"title": "Atomic Habits", "author": "James Clear", "audioUrl": "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3", "featured": true, "readTime": 12, "categoryId": "cda1b7d3-4089-499e-b7f7-2e41295155e6", "coreThesis": "Small, consistent changes in habits compound into remarkable results over time. Systems matter more than goals.", "coverImage": "https://example.com/test.jpg", "listenTime": 10, "description": "An easy and proven way to build good habits and break bad ones. Tiny changes, remarkable results.", "premiumOnly": false, "audioDuration": 600, "primaryChakra": "solar_plexus", "secondaryChakra": "sacral", "freePreviewCards": 5}	2026-03-01 19:03:49.182987	C9d4Mb	\N
\.


--
-- Data for Name: books; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.books (id, title, author, cover_image, description, category_id, read_time, listen_time, audio_url, featured, core_thesis, status, updated_at, primary_chakra, secondary_chakra, audio_duration, tags) FROM stdin;
7ba8d165-4195-43a3-9079-518dd4332439	Thinking, Fast and Slow	Daniel Kahneman	/images/book-thinking-fast-slow.png	A groundbreaking tour of the mind that explains the two systems that drive the way we think and make choices.	a6b4bfa5-b571-47d3-8b2f-fd4dab69d731	15	12	https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3	t	Our minds operate through two systems: fast intuitive thinking and slow deliberate reasoning. Understanding both helps us make better decisions.	published	2026-02-24 00:02:22.879032	third_eye	crown	720	\N
83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	The Power of Now	Eckhart Tolle	/images/book-power-of-now.png	A guide to spiritual enlightenment. Tolle takes readers on an inspiring spiritual journey to find their true and deepest self and reach the ultimate in personal growth and spirituality.	4f6ff107-44de-4a6e-b29e-bc3f1c9e5ae3	10	8	https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3	t	True freedom and enlightenment come from living fully in the present moment, free from the dominance of the thinking mind and ego.	published	2026-02-24 00:02:22.879032	third_eye	crown	480	\N
69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	Emotional Intelligence	Daniel Goleman	/images/book-emotional-intelligence.png	Why emotional intelligence can matter more than IQ. A revolutionary framework for understanding human behavior.	eb62a63f-dcb3-4341-b435-cc4f72f3ed52	14	11	https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3	f	Emotional intelligence — the ability to recognize, understand, and manage emotions — is as important as IQ for success in life.	published	2026-02-24 00:02:22.879032	heart	throat	660	\N
23f2345b-6336-4573-a63f-8ee2cd34f56b	Man's Search for Meaning	Viktor E. Frankl	/images/book-mans-search.png	A psychiatrist's experience in Nazi death camps and its lessons for spiritual survival. Finding meaning in suffering.	92ce161a-985c-43ee-9448-fe686fb5d312	8	7	https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3	f	Those who have a 'why' to live can bear with almost any 'how.' Meaning can be found even in the worst suffering.	published	2026-02-24 00:02:22.879032	crown	heart	420	\N
2ea408e9-dc96-444c-a0dc-93901f9029b5	Atomic Habits	James Clear	/images/book-atomic-habits.png	An easy and proven way to build good habits and break bad ones. Tiny changes, remarkable results.	cda1b7d3-4089-499e-b7f7-2e41295155e6	12	10	https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3	t	Small, consistent changes in habits compound into remarkable results over time. Systems matter more than goals.	published_with_changes	2026-03-01 22:38:07.225	solar_plexus	sacral	600	\N
85a98d4b-5d69-4e1c-8903-ca357e7178f9	E2E Test Book 12345	Test Author	\N	A book created during E2E testing of the new book flow	\N	10	8	\N	f	\N	draft	2026-03-03 06:19:51.218255	\N	\N	\N	\N
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, slug, icon, color) FROM stdin;
cda1b7d3-4089-499e-b7f7-2e41295155e6	Habits	habits	target	amber
a6b4bfa5-b571-47d3-8b2f-fd4dab69d731	Mindset	mindset	brain	purple
4f6ff107-44de-4a6e-b29e-bc3f1c9e5ae3	Mindfulness	mindfulness	eye	teal
eb62a63f-dcb3-4341-b435-cc4f72f3ed52	Emotions	emotions	lightbulb	rose
92ce161a-985c-43ee-9448-fe686fb5d312	Purpose	meaning	sparkles	indigo
1251c7bb-fb1e-4b62-8b21-ee83c1110bab	Business	business	briefcase	blue
65bf2119-099d-4183-be38-b565d6bb27fd	Leadership	leadership	crown	gold
b3e677a5-bd26-49d6-a80a-cd79ea9d688e	Productivity	productivity	zap	orange
2b72da16-732c-49c8-90a9-5f139b78379e	Science	science	flask	cyan
89fa163e-9a20-4701-9831-bbd33c5000a0	History	history	scroll	brown
08d2e1ba-35c0-4710-880c-53657b9b8881	Health & Fitness	health-fitness	heart-pulse	red
33258962-2734-4e86-a1e9-be0eb80c066d	Relationships	relationships	users	pink
d66583b9-e9cd-4063-bfb2-2e9e5f93b2c5	Money & Finance	money-finance	wallet	emerald
42082c64-ed61-42f0-8317-e7a088eb053f	Creativity	creativity	palette	violet
bff95500-1739-4c4c-b1ab-55bfaea7458c	Philosophy	philosophy	book-open	slate
76e16cef-ab58-4e29-b30c-aa4afd0af2b9	Parenting	parenting	baby	sky
5cc78b3c-bca3-4c53-8307-27ec1416491a	Spirituality	spirituality	sun	yellow
f4bfeba8-ef82-4284-91ac-e5a6cf934be1	Communication	communication	message-circle	lime
6863647a-b72a-4267-9fcb-4940fd58ec85	Technology	technology	cpu	zinc
8fa0aca7-0115-454f-b365-91acdea7ccab	Biography	biography	user	stone
\.


--
-- Data for Name: chakra_progress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chakra_progress (id, user_id, chakra, points, exercises_completed, updated_at) FROM stdin;
\.


--
-- Data for Name: chapter_summaries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chapter_summaries (id, book_id, chapter_number, chapter_title, cards, content, audio_url, audio_duration, subtitle, estimated_read_time) FROM stdin;
aef2f75d-3416-4e8a-883a-e54478b75dcd	2ea408e9-dc96-444c-a0dc-93901f9029b5	1	The Surprising Power of Atomic Habits	[{"text": "Habits are the compound interest of self-improvement. Getting 1% better every day seems small, but it adds up fast."}, {"text": "If you get 1% better each day for one year, you'll end up 37 times better. 1% worse each day, and you'll decline to nearly zero."}, {"text": "Your outcomes are a lagging measure of your habits. Your weight is a lagging measure of your eating. Your knowledge is a lagging measure of your learning."}, {"text": "Forget about goals. Focus on systems instead. Goals are about results. Systems are about the processes that lead to results."}, {"text": "You don't rise to the level of your goals. You fall to the level of your systems."}]	\N	\N	\N	\N	\N
1b0f687a-64c4-4558-8722-9ed9691fd449	2ea408e9-dc96-444c-a0dc-93901f9029b5	2	How Your Habits Shape Your Identity	[{"text": "There are three layers of behavior change: outcomes (what you get), processes (what you do), and identity (what you believe)."}, {"text": "The most effective way to change isn't to focus on goals, but on who you wish to become."}, {"text": "Every action you take is a vote for the type of person you wish to become."}, {"text": "Instead of 'I want to run a marathon,' think 'I am a runner.' The behavior then becomes obvious."}]	\N	\N	\N	\N	\N
8b80aa64-2eac-4458-aa90-96feb5e1faa2	2ea408e9-dc96-444c-a0dc-93901f9029b5	3	The Four Laws of Behavior Change	[{"text": "Every habit follows a 4-step loop: Cue, Craving, Response, Reward."}, {"text": "To build good habits, use the Four Laws: Make it Obvious, Make it Attractive, Make it Easy, Make it Satisfying."}, {"text": "To break bad habits, invert them: Make it Invisible, Make it Unattractive, Make it Difficult, Make it Unsatisfying."}, {"text": "This simple framework gives you a practical playbook for any behavior you want to change."}]	\N	\N	\N	\N	\N
e0565757-7089-4d57-abba-4c27dd0bb0f7	7ba8d165-4195-43a3-9079-518dd4332439	1	The Characters of the Story	[{"text": "Your brain uses two systems: System 1 (fast, automatic, emotional) and System 2 (slow, deliberate, logical)."}, {"text": "System 1 operates automatically with little effort. It's the voice that says 'that person looks angry' or solves 2+2 instantly."}, {"text": "System 2 allocates attention to effortful mental tasks. It's needed for complex math, comparing options, or checking your logic."}, {"text": "Most of the time, System 1 runs the show. System 2 is lazy and only kicks in when System 1 can't handle something."}]	\N	\N	\N	\N	\N
7143fa4c-9068-439e-aedc-29fc5a0c1d0c	7ba8d165-4195-43a3-9079-518dd4332439	2	Heuristics and Biases	[{"text": "System 1 takes mental shortcuts called heuristics. They're usually helpful but sometimes create systematic errors (biases)."}, {"text": "The Anchoring Effect: the first number you see in a negotiation disproportionately influences where you end up."}, {"text": "The Availability Heuristic: you judge how likely something is based on how easily an example comes to mind, not actual statistics."}, {"text": "These biases aren't flaws — they're features of a brain designed for speed over accuracy in a dangerous world."}]	\N	\N	\N	\N	\N
0f80735a-60ba-426e-9229-b46845803bc1	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	1	You Are Not Your Mind	[{"text": "The greatest obstacle to enlightenment is identification with the mind. You think you ARE your thoughts."}, {"text": "Start listening to the voice in your head as often as you can. Pay attention to repetitive thought patterns."}, {"text": "When you listen to a thought, you become the awareness behind the thought. The thought then loses its power over you."}, {"text": "The moment you realize you are not present, you ARE present. Awareness is the beginning of transformation."}]	\N	\N	\N	\N	\N
4897ed61-0363-455f-a4fa-c0be1fe720ac	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	2	Consciousness: The Way Out of Pain	[{"text": "Emotional pain is created by resistance to what is. The more you resist the present moment, the more you suffer."}, {"text": "The 'pain-body' is an accumulation of old emotional pain. It feeds on negative thinking and drama."}, {"text": "When the pain-body is activated, observe it. Say: 'There is the pain-body.' This simple act of recognition weakens it."}, {"text": "Accept the present moment as if you had chosen it. Work with it, not against it. This removes suffering instantly."}]	\N	\N	\N	\N	\N
a07ed59e-3637-4926-9db3-3691a7792222	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	1	What Are Emotions For?	[{"text": "Emotions evolved as survival signals. Fear triggers the fight-or-flight response. Anger prepares you to confront threats."}, {"text": "The problem: our emotional brain was designed for prehistoric threats, not modern stressors like emails and traffic."}, {"text": "The amygdala — our emotional alarm system — can hijack rational thinking in milliseconds, before the thinking brain even has a chance."}, {"text": "Understanding this hijack is the first step to emotional intelligence: creating space between stimulus and response."}]	\N	\N	\N	\N	\N
458a9a09-f8a5-43d4-97dd-60ded03b9df3	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	2	The Five Pillars of EQ	[{"text": "Pillar 1: Self-Awareness — knowing what you're feeling as you feel it."}, {"text": "Pillar 2: Self-Regulation — managing impulses and distressing emotions effectively."}, {"text": "Pillar 3: Motivation — using emotions to drive you toward goals despite setbacks."}, {"text": "Pillars 4 & 5: Empathy and Social Skills — reading others' emotions and managing relationships successfully."}]	\N	\N	\N	\N	\N
c38563a8-f2b9-41d5-8b34-2ec7c78cc716	23f2345b-6336-4573-a63f-8ee2cd34f56b	1	Experiences in a Concentration Camp	[{"text": "Frankl observed three psychological phases among prisoners: shock on arrival, apathy during imprisonment, and disorientation after liberation."}, {"text": "Those who survived were not the physically strongest, but those who found something to live for — a loved one, a task, a purpose."}, {"text": "Even in the most degrading conditions, prisoners who maintained an inner life and sense of meaning were more resilient."}, {"text": "Frankl realized: suffering ceases to be suffering the moment it finds a meaning — such as a sacrifice for a loved one."}]	\N	\N	\N	\N	\N
f88036ab-e9c0-4913-afdb-210045f18186	23f2345b-6336-4573-a63f-8ee2cd34f56b	2	Logotherapy in a Nutshell	[{"text": "Logotherapy is Frankl's therapeutic approach. 'Logos' means 'meaning.' The primary drive in humans is not pleasure or power, but meaning."}, {"text": "There are three ways to find meaning: through creative work, through experiencing beauty or love, and through the attitude we take toward unavoidable suffering."}, {"text": "The 'existential vacuum' — a feeling of inner emptiness and meaninglessness — is the mass neurosis of our time."}, {"text": "Freedom without responsibility is empty. True fulfillment comes when you take responsibility for creating meaning in your life."}]	\N	\N	\N	\N	\N
1b7f5aa2-64d2-4d60-9a63-a69afaee191c	2ea408e9-dc96-444c-a0dc-93901f9029b5	4	Chapter 4	[{"text": "Enter the first insight..."}]	\N	\N	\N	\N	\N
29f68e7c-fe01-4a78-9d1e-17f1256dc413	7ba8d165-4195-43a3-9079-518dd4332439	3	Overconfidence and the Illusion of Validity	[{"text": "We are often confident even when we are wrong. Overconfidence is fed by the illusion that we understand the past, which implies we can predict the future."}, {"text": "The 'illusion of validity' makes experts feel certain about predictions that are no better than chance — especially in complex, unpredictable domains."}, {"text": "Kahneman distinguishes between skilled intuition (firefighters, chess players) and overconfident intuition (stock pickers, political pundits)."}, {"text": "To calibrate confidence: ask yourself 'What is the base rate?' and 'How much does this specific evidence actually change the probability?'"}]	\N	\N	\N	\N	\N
f5df1883-d1fa-4ec7-861e-53e5b30136fb	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	3	Moving Deeply into the Now	[{"text": "Don't seek yourself in the mind. The mind is not who you are. Presence is the key — and it is always available."}, {"text": "Use your senses as a portal to the Now. Feel the aliveness in your hands, the air on your skin, the sounds around you."}, {"text": "The Now is the only point that can take you beyond the limited confines of the mind. It is your only point of access into the timeless realm of Being."}, {"text": "Whenever you deeply accept this moment as it is — whatever form it takes — you are still, you are at peace."}]	\N	\N	\N	\N	\N
8f831c6b-8d7a-42b8-9a29-726dd84c8629	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	3	The Emotionally Intelligent Brain	[{"text": "The amygdala acts as the brain's emotional sentinel, triggering fight-or-flight responses before the rational cortex can assess the situation."}, {"text": "Emotional hijacking occurs when the amygdala commandeers the brain, causing us to react before we think. Goleman calls this an 'amygdala hijack.'"}, {"text": "The prefrontal cortex can override the amygdala's alarm — but only if we develop the neural pathways through practice."}, {"text": "Emotional intelligence is not fixed at birth. The brain's neuroplasticity means we can strengthen emotional regulation throughout our entire lives."}]	\N	\N	\N	\N	\N
770beccc-b997-4e25-bad3-f0c513d1151c	23f2345b-6336-4573-a63f-8ee2cd34f56b	3	Logotherapy in a Nutshell	[{"text": "Logotherapy focuses on the meaning of human existence and on the search for such meaning as the primary motivation in life."}, {"text": "Frankl identifies three main sources of meaning: purposeful work (creating or doing something), love (experiencing something or encountering someone), and courage in suffering."}, {"text": "The 'existential vacuum' — a widespread phenomenon of the 20th century — manifests as boredom, apathy, and a feeling of inner emptiness."}, {"text": "Meaning must be found, not invented. It is unique and specific to each person and each situation — no one else can fulfill it for you."}]	\N	\N	\N	\N	\N
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comments (id, book_id, block_type, block_id, user_id, content, resolved, created_at) FROM stdin;
\.


--
-- Data for Name: daily_sparks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.daily_sparks (id, quote, author, book_id, category) FROM stdin;
fed10093-e41c-4377-951b-558eba55385b	We are what we repeatedly do. Excellence, then, is not an act, but a habit.	Aristotle	2ea408e9-dc96-444c-a0dc-93901f9029b5	habits
5272b598-ead7-41d8-9d6d-0c49b9cbee05	The happiness of your life depends upon the quality of your thoughts.	Marcus Aurelius	7ba8d165-4195-43a3-9079-518dd4332439	mindset
4234fe1d-183c-46bb-89ac-86b7f99c470d	Realize deeply that the present moment is all you have.	Eckhart Tolle	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	mindfulness
912fd99c-7e14-49e3-a63c-9a6395edec04	In a very real sense we have two minds, one that thinks and one that feels.	Daniel Goleman	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	emotions
23f01ea5-ab06-4edf-bc63-9be8057e822e	When we are no longer able to change a situation, we are challenged to change ourselves.	Viktor E. Frankl	23f2345b-6336-4573-a63f-8ee2cd34f56b	meaning
7badd41e-7ba8-43ce-86ab-fa41a1cc96c7	Between stimulus and response there is a space. In that space is our power to choose our response.	Viktor E. Frankl	23f2345b-6336-4573-a63f-8ee2cd34f56b	meaning
17356489-0a18-44b2-a7ce-154140b88ccd	You do not rise to the level of your goals. You fall to the level of your systems.	James Clear	2ea408e9-dc96-444c-a0dc-93901f9029b5	habits
27931d8d-43ae-4200-aa60-90880a849919	Nothing in life is as important as you think it is, while you are thinking about it.	Daniel Kahneman	7ba8d165-4195-43a3-9079-518dd4332439	mindset
31d5a531-940b-410e-a761-64123f4e4cdc	Life is not primarily a quest for pleasure or a quest for power, but a quest for meaning.	Viktor E. Frankl	23f2345b-6336-4573-a63f-8ee2cd34f56b	meaning
e8e9a3fb-9521-4e29-a755-dbd7b9db8794	The mind is everything. What you think you become.	Buddha	\N	mindfulness
b8f512bd-0029-43aa-943e-1765e36d19b6	Every action you take is a vote for the type of person you wish to become.	James Clear	2ea408e9-dc96-444c-a0dc-93901f9029b5	habits
ddb07402-80f9-4c55-a03d-c726eac5064c	The ability to observe without evaluating is the highest form of intelligence.	Jiddu Krishnamurti	\N	mindfulness
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.journal_entries (id, user_id, exercise_id, content, created_at) FROM stdin;
\.


--
-- Data for Name: mental_models; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mental_models (id, book_id, title, description, steps, order_index) FROM stdin;
18f88ce2-24bc-4a67-b9c9-bfbc398cd47e	2ea408e9-dc96-444c-a0dc-93901f9029b5	The Habit Loop	The four-step neurological pattern behind every habit.	[{"label": "Cue", "explanation": "A trigger that tells your brain to initiate a behavior. It predicts a reward."}, {"label": "Craving", "explanation": "The motivational force. You don't crave the habit itself, but the change in state it delivers."}, {"label": "Response", "explanation": "The actual habit you perform. It can be a thought or an action."}, {"label": "Reward", "explanation": "The end goal. Rewards satisfy your craving and teach your brain which actions are worth remembering."}]	1
91a8c9bb-6b05-47bf-92d6-22c5150a9f15	2ea408e9-dc96-444c-a0dc-93901f9029b5	The Plateau of Latent Potential	Why results seem to take forever, then arrive all at once.	[{"label": "The Valley of Disappointment", "explanation": "In the early days, your efforts seem to produce no visible results. This is where most people give up."}, {"label": "The Breakthrough", "explanation": "At a certain point, previous efforts unlock a breakthrough and results seem to arrive overnight."}, {"label": "The Ice Cube Analogy", "explanation": "Imagine heating an ice cube from 25 to 31 degrees. Nothing visible happens. At 32 degrees, it begins to melt. The work wasn't wasted — it was being stored."}]	2
1422322d-0174-4d0a-80d2-57ea5d1d252f	7ba8d165-4195-43a3-9079-518dd4332439	System 1 vs System 2	The dual-process model of human cognition.	[{"label": "System 1: The Automatic Pilot", "explanation": "Handles pattern recognition, emotional reactions, and well-practiced responses instantly without conscious effort."}, {"label": "System 2: The Careful Analyst", "explanation": "Engages for complex reasoning, self-control, and deliberate choices. Requires attention and energy."}, {"label": "The Handoff Problem", "explanation": "System 1 generates impressions and feelings that System 2 often endorses without checking. This is where biases slip in."}, {"label": "When System 2 Fails", "explanation": "Under cognitive load, time pressure, or fatigue, System 2 can't override System 1's mistakes. This is when we make our worst decisions."}]	1
52304cb8-897f-48d8-9d47-9c66a9af0b50	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	The Timeline of Suffering	How the mind creates pain through time-based thinking.	[{"label": "Past = Guilt & Regret", "explanation": "The mind replays past events, creating guilt, resentment, and 'if only' stories that have no power to change anything."}, {"label": "Future = Anxiety & Fear", "explanation": "The mind projects worst-case scenarios forward, generating anxiety about things that haven't happened and may never happen."}, {"label": "The Present = Peace", "explanation": "In the actual present moment, stripped of mental stories, there is usually no problem. There is only what IS."}, {"label": "The Practice", "explanation": "Ask yourself: 'Am I at ease in this moment?' If not, what are you resisting? Accept what is, then act from clarity, not fear."}]	1
0d1b9711-4807-45f5-9921-805a04c99982	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	The EQ Framework	Daniel Goleman's five components of emotional intelligence.	[{"label": "Self-Awareness", "explanation": "Recognizing your emotions in real-time. This is the foundation — you can't manage what you don't notice."}, {"label": "Self-Regulation", "explanation": "The ability to pause before reacting. Managing impulses, anxiety, and anger constructively."}, {"label": "Motivation", "explanation": "Using emotional energy to pursue goals with persistence. Delaying gratification for long-term rewards."}, {"label": "Empathy", "explanation": "Sensing what others feel without them telling you. Reading body language, tone, and unspoken signals."}, {"label": "Social Skills", "explanation": "Managing relationships effectively. Influence, conflict resolution, collaboration, and leadership."}]	1
b8bf9a20-03d4-4d4f-aecc-8510093ae8b9	23f2345b-6336-4573-a63f-8ee2cd34f56b	The Three Sources of Meaning	Frankl's framework for finding purpose in any circumstance.	[{"label": "Creative Values", "explanation": "Meaning through what you give to the world: your work, your art, your contributions. Creating something larger than yourself."}, {"label": "Experiential Values", "explanation": "Meaning through what you receive from the world: love, beauty, truth, nature. The richness of fully experiencing life."}, {"label": "Attitudinal Values", "explanation": "Meaning through the stance you take toward unavoidable suffering. The highest form of meaning — turning tragedy into triumph."}]	1
74d88331-6d50-425f-ac7a-7cbc837290e1	7ba8d165-4195-43a3-9079-518dd4332439	Prospect Theory	How people actually evaluate gains and losses, replacing classical expected utility theory.	[{"label": "Reference Point", "explanation": "People evaluate outcomes relative to a reference point (usually their current state), not in absolute terms."}, {"label": "Loss Aversion", "explanation": "Losses feel roughly twice as painful as equivalent gains feel good. Losing $100 hurts more than gaining $100 pleases."}, {"label": "Diminishing Sensitivity", "explanation": "The difference between $100 and $200 feels larger than the difference between $1,100 and $1,200, even though both are $100."}, {"label": "Probability Weighting", "explanation": "People overweight small probabilities (why we buy lottery tickets) and underweight large probabilities (why we buy insurance for unlikely events)."}]	2
0f82988d-bbbb-4f95-9f75-6dc7ee8ea640	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	The Pain-Body	Tolle's concept of accumulated emotional pain that lives in the body and feeds on negative thinking.	[{"label": "Accumulation", "explanation": "Every emotional pain that is not fully faced and accepted leaves behind a residue of pain that merges with pain from the past."}, {"label": "Activation", "explanation": "The pain-body can be triggered by situations that resonate with past pain. It then takes over your thinking and creates more suffering."}, {"label": "Recognition", "explanation": "The moment you recognize the pain-body in yourself — 'This is the pain-body' — you break its identification with your sense of self."}, {"label": "Dissolution", "explanation": "By staying present and witnessing the pain-body without reacting, you transmute it. Presence is the antidote to accumulated pain."}]	2
50847b3d-9dff-4b67-bba0-9d0f6241f0ff	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	The Amygdala Hijack	How the emotional brain can override rational thinking, and how to regain control.	[{"label": "Trigger", "explanation": "A perceived threat activates the amygdala, which sends an emergency signal faster than the rational brain can process."}, {"label": "Hijack", "explanation": "The amygdala floods the body with stress hormones, narrowing focus and preparing for fight or flight. Rational thinking is temporarily offline."}, {"label": "The 6-Second Rule", "explanation": "Stress hormones take about 6 seconds to dissipate. Pausing, breathing, and counting to 6 gives the prefrontal cortex time to re-engage."}, {"label": "Reappraisal", "explanation": "Once the rational brain is back online, you can reframe the situation: 'Is this truly dangerous, or am I overreacting?'"}]	2
f1b5c9ac-d65d-4e21-bd85-c99b48160d40	23f2345b-6336-4573-a63f-8ee2cd34f56b	The Three Sources of Meaning	Frankl's framework for finding meaning in any circumstance, even unavoidable suffering.	[{"label": "Creative Values", "explanation": "Meaning through what we give to the world — through work, art, service, or any act of creation."}, {"label": "Experiential Values", "explanation": "Meaning through what we receive from the world — through love, beauty, truth, nature, or encounter with another human being."}, {"label": "Attitudinal Values", "explanation": "Meaning through the stance we take toward unavoidable suffering. When we can no longer change a situation, we are challenged to change ourselves."}, {"label": "The Defiant Human Spirit", "explanation": "Even in the worst conditions, humans retain the freedom to choose their attitude. This is the last of human freedoms that cannot be taken away."}]	2
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_preferences (id, user_id, daily_reminder, streak_alerts, new_content, weekly_summary, reminder_time, push_subscription, permission_status, last_prompt_dismissed, updated_at) FROM stdin;
f61e82d9-63ab-4554-b02b-ef2ad03c3784	tcBg5V	t	t	t	t	09:00	\N	dismissed	2026-02-27 08:13:10.038	2026-02-27 08:13:10.038
b9eb1f72-bae9-4a2e-8aff-e722e78c8b15	X5bqd-	t	t	t	t	09:00	\N	dismissed	2026-02-27 08:21:52.633	2026-02-27 08:21:52.633
9eedc182-a525-4914-b967-792753b50b64	b5yZvL	t	t	t	t	09:00	\N	dismissed	2026-02-27 08:28:14.398	2026-02-27 08:28:14.398
8b192010-6608-409e-9d59-3b73b85106f8	-GHxm6	t	t	t	t	09:00	\N	dismissed	2026-03-01 20:15:51.34	2026-03-01 20:15:51.34
dbe9f9fb-8b57-41b0-82c4-9b1133645462	yuVB4U	t	t	t	t	09:00	\N	dismissed	2026-02-27 08:39:45.874	2026-02-27 08:39:45.874
0d612860-b97d-4354-9782-636a38a86e99	a8S2dP	t	t	t	t	09:00	\N	default	\N	2026-02-27 09:03:06.609014
95344c17-6a79-474d-bbe0-198d91d1b36a	j69UEF	t	t	t	t	09:00	\N	dismissed	2026-02-27 09:09:04.848	2026-02-27 09:09:04.848
ce4c7a86-031a-4660-b067-b65464c1df6b	pIDdI2	t	t	t	t	09:00	\N	dismissed	2026-02-27 09:13:38.278	2026-02-27 09:13:38.278
87b965ba-4c75-4428-b647-16885bfb5dc0	Jkp87u	t	t	t	t	09:00	\N	dismissed	2026-02-27 09:20:02.193	2026-02-27 09:20:02.193
c7b6b867-3e42-40f0-b71a-44c5381f856f	tImpmS	t	t	t	t	09:00	\N	dismissed	2026-02-27 09:30:50.534	2026-02-27 09:30:50.534
24495acd-651a-45c6-b3e5-9c6db3701e14	9BmmO0	t	t	t	t	09:00	\N	dismissed	2026-02-27 09:49:15.224	2026-02-27 09:49:15.224
7cece49b-0614-4b10-8d8e-089083212557	W46Jai	t	t	t	t	09:00	\N	dismissed	2026-02-27 10:14:10.903	2026-02-27 10:14:10.903
ee4152da-3c70-4da1-b8d8-bc44dc6df55c	oU-UWK	t	t	t	t	09:00	\N	dismissed	2026-02-27 15:00:01.219	2026-02-27 15:00:01.219
a1621a66-1e59-46c6-baf5-2f293cd8f287	a_rJjy	t	t	t	t	09:00	\N	dismissed	2026-02-27 15:05:52.235	2026-02-27 15:05:52.235
4d9e8e57-5c61-496a-98bc-d7152d07980a	Wc93iB	t	t	t	t	09:00	\N	dismissed	2026-02-28 05:36:14.554	2026-02-28 05:36:14.554
99ce2acd-42cc-40ee-9159-dd6bf85ef35b	8wB_v6	t	t	t	t	09:00	\N	dismissed	2026-02-28 05:53:35.577	2026-02-28 05:53:35.577
04b1fdb8-0ace-42a5-9f91-c5e486f31804	z5Axnh	t	t	t	t	09:00	\N	dismissed	2026-02-28 07:13:54.094	2026-02-28 07:13:54.094
31d0f3d3-d9cc-4c17-ad88-d2958f513b55	aZw-6w	t	t	t	t	09:00	\N	dismissed	2026-02-28 18:59:03.202	2026-02-28 18:59:03.202
e2df7729-2322-40b8-8519-858ebe0f0022	1udX-Q	t	t	t	t	09:00	\N	default	\N	2026-02-28 19:19:03.578119
a62b5619-94c0-4f42-81ed-3c3ba133f436	BQ7kP2	t	t	t	t	09:00	\N	dismissed	2026-02-28 20:49:05.62	2026-02-28 20:49:05.62
ac880192-91d4-4679-ba5a-549ea63c6efa	test-user-999	t	t	t	t	09:00	\N	dismissed	2026-02-28 21:34:16.693	2026-02-28 21:34:16.693
021e201d-1d05-4d58-8e0f-500133d5a077	test-sweep-001	t	t	t	t	09:00	\N	dismissed	2026-02-28 21:43:07.975	2026-02-28 21:43:07.975
2c07c2de-5076-4fea-b0d9-2262109c21a4	test-fix-007	t	t	t	t	09:00	\N	dismissed	2026-02-28 22:08:42.779	2026-02-28 22:08:42.779
ad0f9461-563d-4bac-b5f8-db61e2143a59	admin-check-001	t	t	t	t	09:00	\N	default	\N	2026-02-28 22:29:29.246974
7167ea74-9573-4a7d-b4cf-dc2489de6fac	test-buttons-001	t	t	t	t	09:00	\N	dismissed	2026-02-28 22:32:22.77	2026-02-28 22:32:22.77
79405222-3f1e-43ac-bf66-53600a7ee3fc	35323958	t	t	t	t	09:00	{"keys": {"auth": "_p2a3GmMSf--Are0QqmA5g", "p256dh": "BPSSAzatFgKYJ9mZOqpVATxstr3ePp81BU7yx05nAc0quVLTzFWHVSe2Yz7kcsV9abJ0l10TL9zopb0_HNpzkuc"}, "endpoint": "https://fcm.googleapis.com/fcm/send/cKW6bllMAp8:APA91bER5qUDJ99-O3TA_0Ha8M44gQPndccIBZzn9rO3cyPyU3TchNyhe8e2e6D9_4tmQZduohqN5zbSYkF63imDSa31XIKXt4qiI5TRv-u25mH5f5hK3n8otQdQH5ieoos09peZV4cB", "expirationTime": null}	dismissed	2026-02-28 23:24:00.064	2026-02-28 23:24:00.064
3da9162b-ac6c-42e7-8dd5-fb247578f6a4	kWBQ4S	t	t	t	t	09:00	\N	default	\N	2026-03-01 06:49:19.536449
3c58e971-2c95-4b1a-aff0-8606f40b2ea3	RqfxU0	t	t	t	t	09:00	\N	dismissed	2026-03-01 07:13:36.469	2026-03-01 07:13:36.469
76d6340f-06a1-422d-80e6-5b52b9b764ab	WJNhpw	t	t	t	t	09:00	\N	dismissed	2026-03-01 17:41:56.886	2026-03-01 17:41:56.886
ca46bf2c-2c49-41d9-8144-1c11be099c30	f0PZaY	t	t	t	t	09:00	\N	dismissed	2026-03-01 22:09:48.413	2026-03-01 22:09:48.413
0b9a580b-3282-4254-a35f-cdaef1615678	E4d0vZ	t	t	t	t	09:00	\N	dismissed	2026-03-01 22:30:21.984	2026-03-01 22:30:21.984
5232ed4e-35bc-4a4f-ad3d-582c9c318133	G35IpT	t	t	t	t	09:00	\N	dismissed	2026-03-01 23:04:52.498	2026-03-01 23:04:52.498
058309be-fe87-47a8-80fb-3bb59da223cd	nEiu_1	t	t	t	t	09:00	\N	dismissed	2026-03-01 23:08:13.242	2026-03-01 23:08:13.242
6a5cad42-c065-4e3b-aa56-5150c03b6bcb	VouA0h	t	t	t	t	09:00	\N	dismissed	2026-03-01 23:55:22.393	2026-03-01 23:55:22.393
cae263de-8159-4ba9-8b39-8199887a1230	hE9ikf	t	t	t	t	09:00	\N	dismissed	2026-03-02 00:13:22.837	2026-03-02 00:13:22.837
dc2fc846-e565-40df-bbdd-512f3f1347c7	72Nckd	t	t	t	t	09:00	\N	dismissed	2026-03-02 00:44:58.793	2026-03-02 00:44:58.793
7f871e78-d6cf-4af7-b385-7555d5b2c536	bugfix-test-1772413553541	t	t	t	t	09:00	\N	dismissed	2026-03-02 01:07:26.003	2026-03-02 01:07:26.003
300ec240-e7b2-4d50-b7dd-c0c166c96357	UyErpn	t	t	t	t	09:00	\N	dismissed	2026-03-05 01:32:11.992	2026-03-05 01:32:11.992
9d1b6f06-f1c8-4816-a340-7aeca9be4c15	1l02Ad	t	t	t	t	09:00	\N	dismissed	2026-03-05 01:36:25.983	2026-03-05 01:36:25.983
3d6b4b25-aac4-4ba2-b092-60e1b8f9ecf8	e2e-test-1772698062436	t	t	t	t	09:00	\N	default	\N	2026-03-05 08:08:17.924555
\.


--
-- Data for Name: quiz_results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quiz_results (id, user_id, book_id, chapter_id, score, total_questions, answers, completed_at) FROM stdin;
073ca218-6eca-4331-bd42-747fd14cb408	a_rJjy	2ea408e9-dc96-444c-a0dc-93901f9029b5	aef2f75d-3416-4e8a-883a-e54478b75dcd	1	4	[{"correct": false, "selected": 0, "questionId": "ch-aef2f75d-3416-4e8a-883a-e54478b75dcd"}, {"correct": true, "selected": 0, "questionId": "ch-1b0f687a-64c4-4558-8722-9ed9691fd449"}, {"correct": false, "selected": 0, "questionId": "ch-1b7f5aa2-64d2-4d60-9a63-a69afaee191c"}, {"correct": false, "selected": 0, "questionId": "ch-8b80aa64-2eac-4458-aa90-96feb5e1faa2"}]	2026-02-27 15:06:41.745873
\.


--
-- Data for Name: saved_highlights; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.saved_highlights (id, user_id, book_id, principle_id, content, type, created_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (sid, sess, expire) FROM stdin;
7utUyzJ9BYNC0vTM_0FXVmEMWmTIwgw2	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T05:35:03.683Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772260503, "iat": 1772256903, "iss": "https://test-mock-oidc.replit.app/", "jti": "d32302b05535b0ac3dc0320d9ab2710e", "sub": "Wc93iB", "email": "Wc93iB@example.com", "auth_time": 1772256903, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772260503, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMjU2OTAzLCJleHAiOjE3NzIyNjA1MDMsInN1YiI6IldjOTNpQiIsImVtYWlsIjoiV2M5M2lCQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.DlH5f_aCrrfxC8zquKux_GOtYq4OWXruxyOOBP1R6wDzuVlBn2buKdLbmnNELdN7jIdJ2HnklSz-buv0yiJm8M0PDv5uYxLGymkBmUL1FNfOBOH5sbjmjXbF-a1OMf8-k9O6gCX-avBD-j3zG253Kx0-OuOxq7_xm96b0E5tPioujmZMxgveSKZLQgTmHTA-V5Ly1JYeLKMoOInuFAJzZUIo5BAc6sLRBT_TJu1mHMakMG5hEtEiU5qtAetqg6FpbDGBVCZEa7E3NBAjEaxMHW82JlYKHXKSC6e1EpsqqTR8JJBE0TmaadNzqwzj6fPtvocPMwv47_78jJ0rTM218w", "refresh_token": "eyJzdWIiOiJXYzkzaUIiLCJlbWFpbCI6IldjOTNpQkBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-07 05:37:23
B9pKyO8iuq2P_ZbtbU7rEAv8ZkbrfmbH	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T06:37:22.589Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772264242, "iat": 1772260642, "iss": "https://test-mock-oidc.replit.app/", "jti": "cdee4b94156d6cee0b38cc09fdf909d2", "sub": "admin_SyQ1", "email": "admin_SyQ1@example.com", "auth_time": 1772260642, "last_name": "User", "first_name": "Admin"}, "expires_at": 1772264242, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMjYwNjQyLCJleHAiOjE3NzIyNjQyNDIsInN1YiI6ImFkbWluX1N5UTEiLCJlbWFpbCI6ImFkbWluX1N5UTFAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiQWRtaW4iLCJsYXN0X25hbWUiOiJVc2VyIn0.HRT_UWkL0FkyGKzqJqqB_u6RbMe0aIy-lla2p9cludtEYxdREO907oN5f5W8WkWOZlt_Oez8bKqWN_7CUwQpJWac6r3BBsh5Cc_KNLO5iBWwkkhKTABzkAFJOPhTuwiEu35g5QCkh_ppVy6XiJbzKoJU7TAVkxAocPmK3ZwiqoD9bqi24BWiFlp3h8p6ZXKgT8NuW79PP7KXaptoPpCLmYDMrvv8CckGdyjS9KNSrPimzK3OExIHKWZtOzFbx1Y7I3CWnFKMPVm2r_JAgCo7GxSQZwDi_czPRQkx9R575kEI9rvsAotljM3himOCAolqLhzMM3Bp6FeKO-wLn1uzEw", "refresh_token": "eyJzdWIiOiJhZG1pbl9TeVExIiwiZW1haWwiOiJhZG1pbl9TeVExQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkFkbWluIiwibGFzdF9uYW1lIjoiVXNlciJ9"}}}	2026-03-07 06:38:15
e22_16zkr8SyWWXa9q36txsVBAe2ZoTi	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-12T01:35:16.565Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772678116, "iat": 1772674516, "iss": "https://test-mock-oidc.replit.app/", "jti": "84cc74d61bd80749568f9546f9a0c1cb", "sub": "1l02Ad", "email": "1l02Ad@example.com", "auth_time": 1772674516, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772678116, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyNjc0NTE2LCJleHAiOjE3NzI2NzgxMTYsInN1YiI6IjFsMDJBZCIsImVtYWlsIjoiMWwwMkFkQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.g_Cvcv1xt4D7cTuenmMY_f9QQ9nDjvEfWnIEd19cDqt3yXop1U3HxiowwTA4-Sq-iSmkM5_UcMylTrg1UhMHgY4pQ6Fog2uBtVatidC5feAX7Omc1jbWKK3wYxCYmeqFvyiK_yddyEglNWtcD4CUgkoEeq5BkIy-9MzViOVOVhuJxyV80W0m94XP5jxzuJMURC_SPXaG60vL9Ot58GnJCam_rF8ytTsMW2VNI17t6rcymClTRhGavy4DIt45d_0opJroK-L-TbNm5QD_2FRqryTYtPUsO4JUh1Fu_wK1C5KNG-uqB5vhRfPIF8CJdC1hCIFudNALRi4nN08kqR7rLw", "refresh_token": "eyJzdWIiOiIxbDAyQWQiLCJlbWFpbCI6IjFsMDJBZEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-12 01:38:33
0Wg0drLAipXkjV12w1gxO3nM_cxz_l_E	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T19:18:50.495Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772309930, "iat": 1772306330, "iss": "https://test-mock-oidc.replit.app/", "jti": "9741678cbf40b7e5edd9859dff7ba2a2", "sub": "1udX-Q", "email": "1udX-Q@example.com", "auth_time": 1772306330, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772309930, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzA2MzMwLCJleHAiOjE3NzIzMDk5MzAsInN1YiI6IjF1ZFgtUSIsImVtYWlsIjoiMXVkWC1RQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.Hmt3E6vm4FoTktgE8WQZCLq7o6GCGLRjxEcQnzSp1xhIuQngbO9F2zSkJKaT2qRCXqGgz4iKP7fSXwSYAIMWETg9_4mhFhznr4LN6_MRSgS92NSDQCcoCwOLXBBtztar_9zfrabFSqTp7WDrFWT6jeILqgm7PLaDcMV6odl-UsIXNyuhhRNbGRbQAisFhczQgaSUVZCG3TS2S4YcnYAXdgXmTH-dupOG717hoWYtHDtuFM_QUxxgZgH8d4Rdl-EDvon8_RTu1Dfp70N9mgxcjTKKpaE6j0HbNWHtSMvGtE6FxgIjJpplHQj2s2r8TVew6_cfbvEI4kXhCG6kRuFgPg", "refresh_token": "eyJzdWIiOiIxdWRYLVEiLCJlbWFpbCI6IjF1ZFgtUUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-07 19:19:43
fhabidgAJPmxWXIqvVuHJa2421r2JATT	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-12T08:07:12.930Z", "httpOnly": true, "originalMaxAge": 604800000}, "returnTo": "/admin", "test-mock-oidc.replit.app": {"code_verifier": "7uA3-iUaK5yPerQ67jp2V0CZlKGOXcXZmcwQqRcLQAA"}}	2026-03-12 08:07:13
owPzNVFKi4oh3HvWkKjx-Sk0KdN3NIhn	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T18:48:20.976Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772308100, "iat": 1772304500, "iss": "https://test-mock-oidc.replit.app/", "jti": "7d4d5c8fb3aba48ea974281773eca5b5", "sub": "xVhSzI", "email": "xVhSzI@example.com", "auth_time": 1772304500, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772308100, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzA0NTAwLCJleHAiOjE3NzIzMDgxMDAsInN1YiI6InhWaFN6SSIsImVtYWlsIjoieFZoU3pJQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.SXhPRkFavrbh4auPcxesyaASMKSbgM9E_mUsbgED2C6XzQD_fqfCR7dusBoezaHaiEYYnRlU4nfSVU6TK-PxAtZlKM1bPfJ7lj7dC_AMhCWl160lApPvzb3WMc0Yq0wtdjRY11S_0h0xWI3Itl81KDnM2OYZk0-ubUBDpNmXizySvLAUVh53IdhQiG7izrHyIYMSCIK8xaWvRF3B25PVQPTW6aBjUZtWB4ZM6QObPR8D7hT-FS4uICGjRs2KNQMVk4_cyWC8lZg59HLGBRS3UjeDt26w97XiTbCJPiun6e2CZ3hNWKJ3DtUa7-RQbIkneMMxuiCxJo2GAMgvcpX5iw", "refresh_token": "eyJzdWIiOiJ4VmhTekkiLCJlbWFpbCI6InhWaFN6SUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-07 18:48:23
XPUWJuff7iZN-CYqHxr9Ut60U4tWo_jp	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-13T23:58:35.735Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772845115, "iat": 1772841515, "iss": "https://replit.com/oidc", "sub": "35323958", "email": "4980005@gmail.com", "at_hash": "rpscDsoTBRlof51sEf16iA", "username": "4980005", "auth_time": 1772475191, "last_name": "Rej", "first_name": "Pete", "email_verified": true}, "expires_at": 1772845115, "access_token": "KOv1WFXS30HQwbTkpRZMQAOfv0AhNMnEFqwOTXxiHZh", "refresh_token": "WMuB93SK4M0-kQDIdN7F4amoUt1N39zVWnMvbjkogU2"}}}	2026-03-14 00:03:03
4m_GFidDYxMr0Nnz_GTZZQ8jF42LkEjd	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-08T22:29:03.598Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772407743, "iat": 1772404143, "iss": "https://test-mock-oidc.replit.app/", "jti": "4e9d133c8a077869fb17efb52170b408", "sub": "E4d0vZ", "email": "E4d0vZ@example.com", "auth_time": 1772404143, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772407743, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyNDA0MTQzLCJleHAiOjE3NzI0MDc3NDMsInN1YiI6IkU0ZDB2WiIsImVtYWlsIjoiRTRkMHZaQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.YSX7a8DRAGHmopgArjdT1zGKE1LkXq6PEH2D_igrWTCUFg2dt0VTDzRDSXbuY27v-5HJEMcCjaTszD277x-fW5FbSlfy2KfNuP6AmLmcTw3OtxDBcnz1pYqLV6Je6ex_LwDOF4FUgbcWkZCtnQ6Foa9C1hSSypZVzG5keoT8Qmq3aXQA1a7DrlLKKHJ7hm12DIbglBsKujaeGFJ0lkEzIezjpadqeyeTN5uyhvN07Qgi2YcHQYjXwExK695gMcWOT80IbwMsMqUL8SwyVKisMIcx9vPdgED0vJLJyMXrmBTgpMRQysh8OS3-bz3ioFz_AqfIV_W5tGImzP_cAnFdVw", "refresh_token": "eyJzdWIiOiJFNGQwdloiLCJlbWFpbCI6IkU0ZDB2WkBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-08 22:31:57
C0fg36iStwbdEOEN9p9hL02LPvFMwrDU	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-08T23:03:58.932Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772409838, "iat": 1772406238, "iss": "https://test-mock-oidc.replit.app/", "jti": "1377a3dae73624cc19ec04e98259d9d7", "sub": "G35IpT", "email": "G35IpT@example.com", "auth_time": 1772406238, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772409838, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyNDA2MjM4LCJleHAiOjE3NzI0MDk4MzgsInN1YiI6IkczNUlwVCIsImVtYWlsIjoiRzM1SXBUQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.tEEaqQOsEcfoIGsNyrS9tKuHpUu0A4TRVe_DAIGpd1iM9TjVYw44byAqF-1yY-YxI2otBPyZ1kQ5H4TH9DJFID4imFYXehn8bftm7aIXKwD8gYnEB8ApkOKmypppmKeCgLr6L9sef5yGOS6vAcrSLP0lmfK4N8-ZLRSEugWxIhDRZKDoIm4rnHEDXVvzMeBqwssQb7bfc0nBLRQag6sFjY8ox37TWaN8Q_--HyHVlA1jtQL1_6Age7Iv8zjAKOn4Z9uNBjJVnKxiu3YwefBzqM4cqNCI_NvCg1UCbe82KNQgHM8MnnWhfporAk-KLHuYtZ343OGmYQwtH4Q7MapSTw", "refresh_token": "eyJzdWIiOiJHMzVJcFQiLCJlbWFpbCI6IkczNUlwVEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-08 23:05:47
FW3y0M5eliX9nIOb90FbVsp4UEngVKOM	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T09:13:52.957Z", "httpOnly": true, "originalMaxAge": 604799999}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772143800, "iat": 1772140200, "iss": "https://replit.com/oidc", "sub": "35323958", "email": "4980005@gmail.com", "at_hash": "knaCs3-F8L6qP4BNS8W7WA", "username": "4980005", "auth_time": 1771991262, "last_name": "Rej", "first_name": "Pete", "email_verified": true}, "expires_at": 1772143800, "access_token": "CAlsAYgLvzT_tgwrbVZT8eVhr2ORfB1ydW5nR87o8JZ", "refresh_token": "mjCUHs1LZEqNR1A80OKrr3FPWlnB43mRS6V-Ydp8y1g"}}, "test-mock-oidc.replit.app": {"code_verifier": "jIxU0vfmTLzEudEj3jPUn_1dgeQzy4S7IIM9u4kyV7Y"}}	2026-03-12 00:30:14
k1d4i9w19votvHim5J9BHMdgJAzOff4R	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T10:08:57.944Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772190537, "iat": 1772186937, "iss": "https://replit.com/oidc", "sub": "35323958", "email": "4980005@gmail.com", "at_hash": "j6vss1JJhUPCMPfvGsnW-g", "username": "4980005", "auth_time": 1772172195, "last_name": "Rej", "first_name": "Pete", "email_verified": true}, "expires_at": 1772190537, "access_token": "FypBl_SitptVUPb8bnq9ROTf5tWjC-n7S_5vi2vKMaM", "refresh_token": "qpZJn-TISYoXl9C2C8vPnaf8tXFL7hyaZjFkp6kYpjY"}}}	2026-03-12 20:00:02
p42cbXj0eEIdf3h3vc4WUKwh0TmPcTsc	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T21:42:14.956Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772318534, "iat": 1772314934, "iss": "https://test-mock-oidc.replit.app/", "jti": "6b73a99f55cb2cc9947300b1a046130b", "sub": "test-sweep-001", "email": "test-sweep-001@example.com", "auth_time": 1772314934, "last_name": "Tester", "first_name": "Sweep"}, "expires_at": 1772318534, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzE0OTM0LCJleHAiOjE3NzIzMTg1MzQsInN1YiI6InRlc3Qtc3dlZXAtMDAxIiwiZW1haWwiOiJ0ZXN0LXN3ZWVwLTAwMUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJTd2VlcCIsImxhc3RfbmFtZSI6IlRlc3RlciJ9.tyjxQLzXZUasAplI2ZlMJdpamnqfM00vhc7Zs1KkHHNTuPGt19_dmo7h0QGB_5gTrwJSV6tCqDWQPxkt6V-fQsSJFKNuG_z5NVTVqupwFM6se7Nd3mAGnkCXIsHywdcnjlMHtHTi_iwwe9TwxyHgNbq5yVfl8-iCipT2us7lNOcQnHPMzfckHqMTbajY0PUYK4SStkM90rPrOv0-TsH71OyQGigaLxIx6dJ5Jz5IXCrr_QnXCmmBKALlc4TJwf9aR6aNpmUhgkF4GITHTKheWDRroZXEJ8BSUNCLZq-xbVz8g-ee1iivgJZcwFoWFCupwI2rTEPJ9deITmgnI6TCeg", "refresh_token": "eyJzdWIiOiJ0ZXN0LXN3ZWVwLTAwMSIsImVtYWlsIjoidGVzdC1zd2VlcC0wMDFAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiU3dlZXAiLCJsYXN0X25hbWUiOiJUZXN0ZXIifQ"}}}	2026-03-07 21:44:33
cJ9LR_q6gktmJop_8kXSiQWFpEIfFNC7	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T22:28:27.917Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772321307, "iat": 1772317707, "iss": "https://test-mock-oidc.replit.app/", "jti": "15ab0ccef11f76b23206cfdd94a2fcd5", "sub": "admin-check-001", "email": "admin-check-001@example.com", "auth_time": 1772317707, "last_name": "User", "first_name": "AdminCheck"}, "expires_at": 1772321307, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzE3NzA3LCJleHAiOjE3NzIzMjEzMDcsInN1YiI6ImFkbWluLWNoZWNrLTAwMSIsImVtYWlsIjoiYWRtaW4tY2hlY2stMDAxQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkFkbWluQ2hlY2siLCJsYXN0X25hbWUiOiJVc2VyIn0.j-7wR2s9AmlQ662SoGk5NW20WNIQ1T6TyqjrhY17X9Xf4SOcEoJcudM-Xrdfg2C94sQpJhRh5aNmgdXODnWHBay2p45S-eLS_RqwQPS8NKJXUTzgA80LwPk6D3oWk4coFXllplIpW0aiOc9gsackRFNbHKB4xpKUFapkMKrdCU4vD-23_xyX8ijmjJkFEKO7dnnrgq_NK-M5-DjeVZP7FLqLgull6yck91RhyUZLRoCytzTRfc2xmbI092Dyz9VVOMDiQ3HIW3qagzwRA5129GZIixBuHnM7NgMyUcILAYrIQz2ncndPVfwvmQBzbNuZiVWdOspg9zkWOQUMl59X0A", "refresh_token": "eyJzdWIiOiJhZG1pbi1jaGVjay0wMDEiLCJlbWFpbCI6ImFkbWluLWNoZWNrLTAwMUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJBZG1pbkNoZWNrIiwibGFzdF9uYW1lIjoiVXNlciJ9"}}}	2026-03-07 22:29:41
taq1RvBo7SCZwCd43GUcVEEVFBMPK3vC	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-08T22:09:04.903Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772406544, "iat": 1772402944, "iss": "https://test-mock-oidc.replit.app/", "jti": "c110f824fc3cca81abf58e21cf5b946d", "sub": "f0PZaY", "email": "f0PZaY@example.com", "auth_time": 1772402944, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772406544, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyNDAyOTQ0LCJleHAiOjE3NzI0MDY1NDQsInN1YiI6ImYwUFphWSIsImVtYWlsIjoiZjBQWmFZQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.eMroE-jGk4hFs5gGxAlNUmyQ-XADOqYaHSAP0klk3dBND7MfyGb21t6x-RYv_z54M8V5r-ZHGyGLZ7QDZuj9nhry7GWUXaYCdiW67nQ-Hy7uhwFMLB7Pi9-bNv8pC9fDOYaTRq9nH4E5JoG6ZemM_WQOKiuqKG1lz-mNDjw5Ko_IeYYlu6iG_sCO9BAwOzJAqt4SsIL-dpjIjcmjr7Wa4AcpdJBcWcmfh-6SKWRA0WFXPS1e7anboBz5pzzOQaZWRElAQGHRV9QUAf4haZP4g2L4FkaMHkAVZ6XPVhno0UwVieX0hgsRI9MhMPHp58wb6a_8qjQO3wY-bgnevfLMtw", "refresh_token": "eyJzdWIiOiJmMFBaYVkiLCJlbWFpbCI6ImYwUFphWUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-08 22:10:52
LXRQrkzA2JjZVS9kd2EZaT-rOaiuP9kY	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T21:33:25.148Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772318005, "iat": 1772314405, "iss": "https://test-mock-oidc.replit.app/", "jti": "112b7b574583fd496162a68c2b52dacc", "sub": "test-user-999", "email": "test-user-999@example.com", "auth_time": 1772314405, "last_name": "Runner", "first_name": "TestUser", "profile_image": ""}, "expires_at": 1772318005, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzE0NDA1LCJleHAiOjE3NzIzMTgwMDUsInN1YiI6InRlc3QtdXNlci05OTkiLCJlbWFpbCI6InRlc3QtdXNlci05OTlAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiVGVzdFVzZXIiLCJsYXN0X25hbWUiOiJSdW5uZXIiLCJwcm9maWxlX2ltYWdlIjoiIn0.gXR2K6p8bnvTNV1urwbDjYtBAQr2lKnicldEjWJpDt9oy0zVUZA4GeRGtTF9vnhUpIZIUHfzyhzTWbVY0Xdj0gsiRm1NrsMcJq9jwQ73ofcslLQNJgti8wrEgBTJVAx3E6FAxi_wa-eOr2_wMjwExGCOEzrXhAAqd_kkr8mUzNSCajoUZRwkmdhoV-j118gmRY4-tzgVtD2ZjejXyrvy1NL5o5oJzDVONxZlbMMIuePcWHVADrGS-_sgtSfFYAAjxJ026fE80ICWdSCoGUKLRub4jDrnm30CFm0VZX8S_IH5nTUQSms29MGaj06udlvjR6RCybHz6SKQKQdtIpX9_g", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItOTk5IiwiZW1haWwiOiJ0ZXN0LXVzZXItOTk5QGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IlRlc3RVc2VyIiwibGFzdF9uYW1lIjoiUnVubmVyIiwicHJvZmlsZV9pbWFnZSI6IiJ9"}}}	2026-03-07 21:34:17
_fnzmU1kzARjMjm5uHaXSqQkUZpcnKuA	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T23:25:40.928Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772324740, "iat": 1772321140, "iss": "https://test-mock-oidc.replit.app/", "jti": "3925f61eefa45d4ae5f8e7598e141222", "sub": "35323958", "email": "35323958@example.com", "auth_time": 1772321140, "last_name": "Rej", "first_name": "Pete", "profile_image": ""}, "expires_at": 1772324740, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzIxMTQwLCJleHAiOjE3NzIzMjQ3NDAsInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiIzNTMyMzk1OEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJQZXRlIiwibGFzdF9uYW1lIjoiUmVqIiwicHJvZmlsZV9pbWFnZSI6IiJ9.khJwTocXYGfViz7roEOhGelMGha68c5Usk-iRIzfon1dt2KcuGJVkcws-ZtJjzPVYCiJ5FIFsKhG65rZAgKqcKkzGiIfeENUoMS2AzVB1eeMPv7kqBPOM74W9GyIfOawmvJPkkxqDECN0OmyeK9re7BW547QIf82z05TugLgk4EO53gP08aOBjI8MV55zQMfMxkC4_DYPY_qcYuLGMSyITNvA453xGigvbngDvEHIm_YjyK40z-mBeSoskbCF5OqdE0IfXbiaAlggaUCTfHxunPznDOT1gQdT-xsf9KmkgrzYaOXKMufhld0WnJW5l_NvbJycWpA45IDRNY3hCWr8g", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiMzUzMjM5NThAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiUGV0ZSIsImxhc3RfbmFtZSI6IlJlaiIsInByb2ZpbGVfaW1hZ2UiOiIifQ"}}}	2026-03-07 23:26:09
D5BRfG1jrxc6Ye-ayuvynLmXm4ghAWgf	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T18:58:17.683Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772308697, "iat": 1772305097, "iss": "https://test-mock-oidc.replit.app/", "jti": "88bc7ffd0bb01ccbd16b2ef61942941e", "sub": "aZw-6w", "email": "aZw-6w@example.com", "auth_time": 1772305097, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772308697, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzA1MDk3LCJleHAiOjE3NzIzMDg2OTcsInN1YiI6ImFady02dyIsImVtYWlsIjoiYVp3LTZ3QGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.Nnq11-oJpNPxcod4JGzSRhA4cbnylza6YkwqOFpsqNQW2GNXYnbrAE7oKsSPyS7xjpE0jleusnR8uLTPOvATi8KGAnt1ubDbsyhNe0ZX3wLuOXVFtYIT4Zkoc26kdeEPkTlVovj_mes1B90wEn-9v6TmH927OZr71SHwVH7CFivjVJuEuUn55IzSYSEV-vK5bzH2r8KyiYQ4-ESJklec05Vgepw22QvZ8HebLGIMrdKAtgRr1MPpF3jBY2pILTXIyJRe7NjGsWVpkSeH1OwKSsx8CQFyH0TNKwPSSsSwt90_OqRUCBtnJ6kJMDf79Rw5a0-fPqRk3AYOtPocvKcZ8Q", "refresh_token": "eyJzdWIiOiJhWnctNnciLCJlbWFpbCI6ImFady02d0BleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-07 19:00:24
P0YRvdn1Aee6I2Fypr7LIKbb40TCbGKE	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-08T20:15:20.778Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772399720, "iat": 1772396120, "iss": "https://test-mock-oidc.replit.app/", "jti": "1e31cc2bb7e740f447cbf70f825de44e", "sub": "-GHxm6", "email": "-GHxm6@example.com", "auth_time": 1772396120, "last_name": "User", "first_name": "Test"}, "expires_at": 1772399720, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzk2MTIwLCJleHAiOjE3NzIzOTk3MjAsInN1YiI6Ii1HSHhtNiIsImVtYWlsIjoiLUdIeG02QGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IlRlc3QiLCJsYXN0X25hbWUiOiJVc2VyIn0.UcXB7Ujj78XLxpwJ1jiBfip-ZF6DAFNDYi7cnGKY8Afhx08BhPd4q63jARFYu7_68DlV8aOEONr7O_NZ8xidveBpCMYCvH5yuwA-SpAD-nflCUWTloqLCw6O3DLM2m0XSiTnRyNd9Rl7fuBJVAxbgypTmJ0EuvLxX2O_jOUk1RYK9WCz80X6sY8hCb9pJeZ17D2wOmk9AaTnLayBYPFF6qD_GKhKk1CjhJmrkNuk66dKgmsR-5wVIV4qISrPqiqA3pCJnPFQW8erQxGaoxJmVdavn5Q-ZBnH0vqJ2gCHDAJls4lpFGpdWuKCy_45AkEvdolg0_RRoem5tDRP0o_1iA", "refresh_token": "eyJzdWIiOiItR0h4bTYiLCJlbWFpbCI6Ii1HSHhtNkBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJUZXN0IiwibGFzdF9uYW1lIjoiVXNlciJ9"}}}	2026-03-08 20:17:17
jx1iKLr0fY2ZtnjlWIWd4_qnoWxlxfQO	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T07:13:15.473Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772266395, "iat": 1772262795, "iss": "https://test-mock-oidc.replit.app/", "jti": "695cba625eeff07304f0979cdac411fa", "sub": "z5Axnh", "email": "z5Axnh@example.com", "auth_time": 1772262795, "last_name": "User", "first_name": "Test"}, "expires_at": 1772266395, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMjYyNzk1LCJleHAiOjE3NzIyNjYzOTUsInN1YiI6Ino1QXhuaCIsImVtYWlsIjoiejVBeG5oQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IlRlc3QiLCJsYXN0X25hbWUiOiJVc2VyIn0.NQu63wxj_-IiqDXHs_s6_DprymgFW2eMtcylAF06_im18ArOLY7MSQPrxaebwEHWqR3yhgzT3bkdpNS9Tc5YknTfeAtQ_OlrSZat26U5l19PG_hqeiWBxJCqsewKxdtp0otSBTFvqGCcZ8Sm9QU2rl9I9vTiL2Ii3GnSqRG9K2owHGmKg_IZkmujQhx7VzawMGzLv9xfAHMAjnDTYgbb5RFUpbFvaEwLCP4cLJpBq0b5xA4suORocEhda8xPN-iFzcS5cIuubx7P9sFPDFD9QBbwLUgdJQDkSQzkkNKED5qW82iZj8S3rCmUORsLHzuKSQw8nc3MtRLTed88J-P8qw", "refresh_token": "eyJzdWIiOiJ6NUF4bmgiLCJlbWFpbCI6Ino1QXhuaEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJUZXN0IiwibGFzdF9uYW1lIjoiVXNlciJ9"}}}	2026-03-07 07:16:19
1T7d9NYHXxZ9hjUYi4vSg2jM_EBCMkWw	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-08T19:11:07.101Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772395867, "iat": 1772392267, "iss": "https://test-mock-oidc.replit.app/", "jti": "48ae277d1874759543f1f0088ac1fe17", "sub": "35323958", "name": "Admin User", "email": "admin@test.com", "auth_time": 1772392267, "profile_image": ""}, "expires_at": 1772395867, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzkyMjY3LCJleHAiOjE3NzIzOTU4NjcsInN1YiI6IjM1MzIzOTU4IiwibmFtZSI6IkFkbWluIFVzZXIiLCJlbWFpbCI6ImFkbWluQHRlc3QuY29tIiwicHJvZmlsZV9pbWFnZSI6IiJ9.tGcObJVD06fSO8WvKehoI93eNqOFle0HiMRkpsbMmP3kNTOCHridmURxAQebkfJ7I0A0Spjj8Z5SgFEaI0dnmG6J8ZTdlNwOOBfdNrkgcwpmu528pO6oW9fwIL63nt-UHa8EKKL1Q16UnJvmFnuUt3VIMCRb8GPmC74jADip3rEnpkM7wLaychyFo12JBE58r6qRLTVAoO8rClLHDlfj-B2xbsTcrVKCLGfot6X9lvxCMlIO-S8_IaXEIxIE67Zgo_91NdXvjOxThNGM3l6VW2Gp07wEGWigX3kSln518g3H0DTMfsgHFumrtQ3PhTeexjqyaIKMYuAME86ehN6gGg", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsIm5hbWUiOiJBZG1pbiBVc2VyIiwiZW1haWwiOiJhZG1pbkB0ZXN0LmNvbSIsInByb2ZpbGVfaW1hZ2UiOiIifQ"}}}	2026-03-08 19:11:45
5UPiGWkqzAKNGjDLleBuPEvxR4bQOrz3	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-08T19:03:31.706Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772395411, "iat": 1772391811, "iss": "https://test-mock-oidc.replit.app/", "jti": "b71adf0502e91301d42c79bb012711a7", "sub": "35323958", "name": "Admin User", "email": "admin@test.com", "auth_time": 1772391811, "profile_image": ""}, "expires_at": 1772395411, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzkxODExLCJleHAiOjE3NzIzOTU0MTEsInN1YiI6IjM1MzIzOTU4IiwibmFtZSI6IkFkbWluIFVzZXIiLCJlbWFpbCI6ImFkbWluQHRlc3QuY29tIiwicHJvZmlsZV9pbWFnZSI6IiJ9.nw2fuQeVq02ibakFOSc3yaJFiWTWbJCT73ZC4vvPOgw4Gd7V5bRv6H_0VDILuI4y-RcQZEWQ76UIEWkzUhOmJcvdjVHQGKLhI6B9TYbMd91g0FeEFiMr73ADhn6QmgO_SUB4CbKMyVbg6Ao33Y5f7hu9Rq0TTjbERj7DlhnKRCAhgoVyGLhEqm20xfITmgAwpVzDd3jD7n1EEuc7H3XH_n_oeAxZUgTFrzY7PNzmwWVn0kePQBAAwGWeTLGeoL3OYjb2bnD8RFAccZXMLuUtoWwi1l0LFriObCUbizefiAykDHtQF-Sm35rpMp94SkPY87cf0mndUNIHXJ3a4B6Nww", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsIm5hbWUiOiJBZG1pbiBVc2VyIiwiZW1haWwiOiJhZG1pbkB0ZXN0LmNvbSIsInByb2ZpbGVfaW1hZ2UiOiIifQ"}}}	2026-03-08 19:04:43
gyKiahSQjJU73ZVAI3-MAs_JoHQA4gFt	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T20:47:37.668Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772315257, "iat": 1772311657, "iss": "https://test-mock-oidc.replit.app/", "jti": "f4aa25f2ca7df02173e7e90a2f0315b4", "sub": "BQ7kP2", "email": "BQ7kP2@example.com", "auth_time": 1772311657, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772315257, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzExNjU3LCJleHAiOjE3NzIzMTUyNTcsInN1YiI6IkJRN2tQMiIsImVtYWlsIjoiQlE3a1AyQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.bakLwq_1uqPHjAleHJVqHZOh09JnbgEyzxf1b1VNVfw0KfaQeMsBGBfpQJ7JPfSklP1xE1cqKErbHN7JlJEMZ--TB0CP2sqz98p2pil77lI05d8NbwdWRBI8uvo8qnR7woEpqkJoH5fy9oGPi1P82W783aWl9CLZsIkaYU47k3xOu8jWgAJRUtH0NRMoTDGvZO5ikWmbFaFGcD1h0kkg4Q71QJFRNSfVnUWpeYKp_Qb9ybe5LcQwZPIzBn0daqtp6VguVAvchnVkCoQIAQzssr3Ynnzbnz_tqbrzZU5vwOJ3Qf8-WDMNjZfDRIltXOUGVWrv-xpcaPmhmmkfqEWh3Q", "refresh_token": "eyJzdWIiOiJCUTdrUDIiLCJlbWFpbCI6IkJRN2tQMkBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-07 20:49:06
q0QceraOuPKS9iwav1vdJtF2YECVcmSR	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T18:41:54.578Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772307714, "iat": 1772304114, "iss": "https://test-mock-oidc.replit.app/", "jti": "e642392ee777aaca4b93c589b9e12924", "sub": "eiM0S2", "email": "eiM0S2@example.com", "auth_time": 1772304114, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772307714, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzA0MTE0LCJleHAiOjE3NzIzMDc3MTQsInN1YiI6ImVpTTBTMiIsImVtYWlsIjoiZWlNMFMyQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.jMGYI496nQIHwfZuLWYjRWyclZt6HGz00j9G0vayq3Nt8LftIZjJheVE0E-bzu9ziMzK7OPVa4Yw5ykyt5ITUVtrPiIpDtG0o6FrdNHJkH1-uO9n-Xb9J9PMzvIrL7VrTMhJUbbSl3rdVvGYNfyu7XOLmpq08SsXDIbm29FcJy-REY-z5cEbKKRdtRPGQXNkrL0msVN4ODqwspZCPRQunay67ZnLuOupyqkmNStwifE2KNV6MD9fbCjHA-iF650gsm6IWwkvw5omg8ld3zhWL5izN2yt6HHUx1kyL3ncXYp-bSZJfm41eUE7Gd9wbwCkAZ4uOsyIqgkzRxjsxUrPMg", "refresh_token": "eyJzdWIiOiJlaU0wUzIiLCJlbWFpbCI6ImVpTTBTMkBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-07 18:41:58
ig1vh9t0dDnt3MKRj0a5Qt54X-Di2T3S	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T05:52:26.178Z", "httpOnly": true, "originalMaxAge": 604799999}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772261546, "iat": 1772257946, "iss": "https://test-mock-oidc.replit.app/", "jti": "304fec77af68b2f18d7b5fbf2d157677", "sub": "8wB_v6", "email": "8wB_v6@example.com", "auth_time": 1772257946, "last_name": "User", "first_name": "Replit"}, "expires_at": 1772261546, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMjU3OTQ2LCJleHAiOjE3NzIyNjE1NDYsInN1YiI6Ijh3Ql92NiIsImVtYWlsIjoiOHdCX3Y2QGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IlJlcGxpdCIsImxhc3RfbmFtZSI6IlVzZXIifQ.s9-_63teG2EgKtsxOu25zZHYlxusXup7se1w3XmFkPyh-Zi1vTToBjn1mkDXg2pF2goYslUaRVYxc2RVn2U9Jo44WBtDAn3JfX4Q2WG4BTL7J-MDWghLGOicpZGHfBAsiURWzfLl9VtQiUo_2TxOopu98tJ0fWdkkWcnpjOh8xicG6XLKuGKeYDIIggRr-OJTqHwsV7SRdreBTzOIld8PtZj1d772ynpeisguhuGmNeFOMH9QsZAby1krVwn7WzfLFyz1Ai5XsCCXt0AAaTf4roTvmn_ATDzq1im9NhrZ4hMCjzp1et7R1YZMsPP6iQ9FeQputE1S9O2Ihl-YUqM9Q", "refresh_token": "eyJzdWIiOiI4d0JfdjYiLCJlbWFpbCI6Ijh3Ql92NkBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJSZXBsaXQiLCJsYXN0X25hbWUiOiJVc2VyIn0"}}}	2026-03-07 05:55:19
YVLa3d8cEG1F6gCP5ung0bG6BwiaVVxe	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-08T23:51:40.886Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772412700, "iat": 1772409100, "iss": "https://test-mock-oidc.replit.app/", "jti": "93b3556180a14250a9f334883bb0ec8d", "sub": "t_XhuL", "email": "t_XhuL@example.com", "auth_time": 1772409100, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772412700, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyNDA5MTAwLCJleHAiOjE3NzI0MTI3MDAsInN1YiI6InRfWGh1TCIsImVtYWlsIjoidF9YaHVMQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.vfas0cSxVJVLFY4M-U4lG94g2Nv2l8-jLoNt-6SQN3f6NvvKzqn5nWCetVkMT3LcxNXca06SCIWDccJ21RcGHXcO6Fl-roZIf4p0aCNv1lqHrOHuxmHfnDeEvkPIgwENY-y4cED2xtixbfuxI-t87pPr_Bi9zcs6LL-4fzc5bYaCjiDd-m4ltfRGjS9hQsEwBzjPudFyiaVB3WGwm2SVt1FVk1B1h4JVxucDtodWVesDkt4kHyWBuBI1oV8rxOumPkDBlhK32fzETFSCLOAy1vkV9CC06SnY7JS9kWrHaZTFv6lVFG61XVLj4VoF_lshksmCSivGUWZQAKXAq_A2mg", "refresh_token": "eyJzdWIiOiJ0X1hodUwiLCJlbWFpbCI6InRfWGh1TEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-08 23:52:12
ZQfnkEyb0OZScyumHHNYEEWIglzGmhq2	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-08T17:41:25.160Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772390485, "iat": 1772386885, "iss": "https://test-mock-oidc.replit.app/", "jti": "7e3a0452f77d8ffc9552bb25b0843fcb", "sub": "WJNhpw", "email": "WJNhpw@example.com", "auth_time": 1772386885, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772390485, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzg2ODg1LCJleHAiOjE3NzIzOTA0ODUsInN1YiI6IldKTmhwdyIsImVtYWlsIjoiV0pOaHB3QGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.p-4SCqXFl1sk3dykt0zC7UDasdNJw7kvjl3VwMi46wYQI7iWCUYlbDt50OdF3MhLFeMoDzFJfXki23od8ke9l9JO9tztWmFMjCYqGqWIqeXToXGU23DK9qNP2AA6twtpYX9bGryJxPWeybLGw1LeDti0hmrla6ArS_XsEtSOAaZeMzwz-zMXAGzReuVcBru37SnbLe6rXurJ1J2fP3iJXWuwJRwZg7bH2XloXNWhs-SwmgcsYZrYd7YlH6ytwlXoZvIpbcC6RLkD_-U9t_qNrAqv_yL_9rOsgRMxIQRn986-Lk5GmyPI1CoEe1sWRNXoUUkIBK1wBTpk1Z88czsPOA", "refresh_token": "eyJzdWIiOiJXSk5ocHciLCJlbWFpbCI6IldKTmhwd0BleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-08 17:42:37
j_iXVr_Ahtqxhapd-aAVWiFpC9Aul-PJ	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-08T06:48:52.360Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772351332, "iat": 1772347732, "iss": "https://test-mock-oidc.replit.app/", "jti": "2a4769c9234a56db145f0fc723484000", "sub": "kWBQ4S", "email": "kWBQ4S@example.com", "auth_time": 1772347732, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772351332, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzQ3NzMyLCJleHAiOjE3NzIzNTEzMzIsInN1YiI6ImtXQlE0UyIsImVtYWlsIjoia1dCUTRTQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.tFjovKbZNJuRfWFMpYxOut3IC4p2uMzBQc4xAsknFPBwWwPDeZ2iLOgIAj8PXYdUsw9Oo3RdMwRiV3seR5TzUIug_lxHyVySZB4wS28ohP_Q6ueOzOY_vcIz3Ewcb2qLTqe9CH_MOdxKZCHjEdLyLdi7tyRnGktn6W7EApr1aAjgKzSDh4vHsPYXmjoo2TMKiSlaej9QhenwxTM9rggd4CjIR4sWZjKLrasjydEVGkstI9aIpsYmYWyrUgy84hQqT-2v3f8aujDFUjkCEZUkD1dmboAcGkQLYFRYik8js1O4DpfbrwgRyNNFY6DQTAPHk37FWgM64s1_YcQfGndjKw", "refresh_token": "eyJzdWIiOiJrV0JRNFMiLCJlbWFpbCI6ImtXQlE0U0BleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-08 06:49:20
RsGpcsLJL11sNE7NPw6daMF-xHJoqDv_	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T22:07:56.350Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772320076, "iat": 1772316476, "iss": "https://test-mock-oidc.replit.app/", "jti": "d5f91850ce64342e8541230692afe254", "sub": "test-fix-007", "email": "test-fix-007@example.com", "auth_time": 1772316476, "last_name": "Runner", "first_name": "FixTest", "profile_image": ""}, "expires_at": 1772320076, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzE2NDc2LCJleHAiOjE3NzIzMjAwNzYsInN1YiI6InRlc3QtZml4LTAwNyIsImVtYWlsIjoidGVzdC1maXgtMDA3QGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkZpeFRlc3QiLCJsYXN0X25hbWUiOiJSdW5uZXIiLCJwcm9maWxlX2ltYWdlIjoiIn0.nCBq-45HKLSpUGFZtjZW66k0yyJh9dBO5QqTE6394egy8z3Kc9HsRyi03dceANGHB5_O6v-CGtz4d3CkgVlflJ9DG-ShBzKrTPpqKVEPkvcFlGBT1P3haJhxZ9GsYhQx-q7wDx9yWPZq1gxsxWZ-hDg2KxKgQznIZ5FY3A0_FgdamovoMrZbeHwQSGlrLi7EhQlXscLA6RxcS3iXlY8TIaB5uPvO9HmkeT5Z5l4okuVylrqx2Qlp9erJjwyytRFN7kPohEGEJy7rW1_xNptRy6Fu6UJop_fnX8rxPbHsWFlZXRxq6VR_52IBpQa4zUBAvwKhREL8dQtAtK9dYlQF7A", "refresh_token": "eyJzdWIiOiJ0ZXN0LWZpeC0wMDciLCJlbWFpbCI6InRlc3QtZml4LTAwN0BleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJGaXhUZXN0IiwibGFzdF9uYW1lIjoiUnVubmVyIiwicHJvZmlsZV9pbWFnZSI6IiJ9"}}}	2026-03-07 22:08:58
tQKkvB7BunO57oNnsyL79j-20Dpjg3te	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-08T22:37:09.966Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772408229, "iat": 1772404629, "iss": "https://test-mock-oidc.replit.app/", "jti": "09ffaff74eef658f234fb0a1720f89b8", "sub": "C9d4Mb", "email": "C9d4Mb@example.com", "auth_time": 1772404629, "last_name": "User", "first_name": "Admin"}, "expires_at": 1772408229, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyNDA0NjI5LCJleHAiOjE3NzI0MDgyMjksInN1YiI6IkM5ZDRNYiIsImVtYWlsIjoiQzlkNE1iQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkFkbWluIiwibGFzdF9uYW1lIjoiVXNlciJ9.fQF-pi3I5-hYPkaGWDKPJYpAU7J8kgaCA8QUvWn5ZWrAXGgQyDgWWWY2SBTcQG4K9zCEIs9YSbGhtXknIcfkv_Uc82XlIlqtbSg6fYPXr8HTQN_Uwnhif9UKFH62dM_t7MLrYDEkvD7ikmvJY8SMGHdYuUQN0GTqz4dVejTmMpLqBsn-vg7XtRdrEwoXcl5EAXHcJRfFhENMVoDG5vwEzopyPU495-ct0kjaiv03y9siOf-ifVNGPy4tTMX6cMwk6xmLHMfCXxehalC5Xp9w_fZh-Su1rcd4vonCtUxtcJ0L1nFomzrH7_NjO7hHPe_3hf90RFWLGIO05koSYX1cvw", "refresh_token": "eyJzdWIiOiJDOWQ0TWIiLCJlbWFpbCI6IkM5ZDRNYkBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJBZG1pbiIsImxhc3RfbmFtZSI6IlVzZXIifQ"}}}	2026-03-08 22:38:08
qyL6YoGjmHp3qHlAq-wf6TEGFHiORc0W	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T21:32:07.096Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772317927, "iat": 1772314327, "iss": "https://test-mock-oidc.replit.app/", "jti": "e2442979916f23d7fde6da828aefdc77", "sub": "z5AXX1", "email": "z5AXX1@example.com", "auth_time": 1772314327, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772317927, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzE0MzI3LCJleHAiOjE3NzIzMTc5MjcsInN1YiI6Ino1QVhYMSIsImVtYWlsIjoiejVBWFgxQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.csRiXGrPmckL09ccexznT7viDkCoaJRZENyj2S2ln3m-7uwvP4QL0oV-HwBQ5N3UCO-Rlb6RCHziNr1xbWTXPhhLMeBWzxxMxX0Qceo2tFQXHN4htD7MnFj0q9mzK2zWmmmYQvCHuqkWnEY9xNl3uMMjtaBSPPDA_-eMgwyU-GasNmDpIbs91hzTH_hKkdbvYExb6e_tKAdk6NwIbehVRtnwmavG-olwqfYi6tuO-MgYM4r4RbV0CHt2qfwVG_7X_NT_wm5dOXB5ymiTTUbddywHYfmQJqBAv-YUBzadorfp790lwmjmV7zvFgF_dgAiZqAsdwj621WIcReUPHJ5ag", "refresh_token": "eyJzdWIiOiJ6NUFYWDEiLCJlbWFpbCI6Ino1QVhYMUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-07 21:32:23
Z1lQHwTl-rvavmwl8IvaC6wxMtuyArkK	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-10T06:17:42.560Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772522262, "iat": 1772518662, "iss": "https://test-mock-oidc.replit.app/", "jti": "e0a766b8d3464090de8d2b8a10997086", "sub": "admin-test-user", "email": "admin@test.com", "auth_time": 1772518662, "first_name": "Admin Tester"}, "expires_at": 1772522262, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyNTE4NjYyLCJleHAiOjE3NzI1MjIyNjIsInN1YiI6ImFkbWluLXRlc3QtdXNlciIsImVtYWlsIjoiYWRtaW5AdGVzdC5jb20iLCJmaXJzdF9uYW1lIjoiQWRtaW4gVGVzdGVyIn0.nXf4zE8i8V5p6nei7t_ph8A1K0WfbimPb4zd_UNPOH2Ph5zogljDnOFPwAeoT1wsPcZUjtHwsaqNF8IYRVkJZFtxp6s1dNJTzUpio4euHA5BoW2PRnHbjX0IX9QKxiy5AsUrUJF1uZlGMWLDY9Nw-VFomH37IPcOwymyeL-mbwJqvEBiu4gZQYvegFuzBFOB0tep81lnuJQo0oEeZEsb4tDuIyY_LxeeAAOBq-jALZDrKccJJHaWtWUcpU1cb-q-KNxpf8_KstT4yDQPbH-pgJVAOi7MZVL3a7mPwDNDrrrog0yiK_aioj5YpHdVLoyIAjVHVydIE_ak7mZxKNuITw", "refresh_token": "eyJzdWIiOiJhZG1pbi10ZXN0LXVzZXIiLCJlbWFpbCI6ImFkbWluQHRlc3QuY29tIiwiZmlyc3RfbmFtZSI6IkFkbWluIFRlc3RlciJ9"}}}	2026-03-10 06:18:01
jQeXFSfTF-bQw_qT-pCncD-c9Spvm4nS	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T22:31:06.008Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772321465, "iat": 1772317865, "iss": "https://test-mock-oidc.replit.app/", "jti": "407bd351caac06ca5fe5f2684e07d019", "sub": "test-buttons-001", "email": "test-buttons-001@example.com", "auth_time": 1772317865, "last_name": "User", "first_name": "ButtonTest"}, "expires_at": 1772321465, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzE3ODY1LCJleHAiOjE3NzIzMjE0NjUsInN1YiI6InRlc3QtYnV0dG9ucy0wMDEiLCJlbWFpbCI6InRlc3QtYnV0dG9ucy0wMDFAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiQnV0dG9uVGVzdCIsImxhc3RfbmFtZSI6IlVzZXIifQ.V-69G9xEHYzVuyRJ227-m_AkQg3KTvjwkB0yZjhq-Wdtt0gfGuwqcHwgIdCE8oyTO8VrNsuA5Axa3fwK98xqAHq5Rj0tI5aQfIbNs5H9vSiq3BzJGSIChn8HC9KAlf29tGAtqBKeMqFDpMzFcb2UL8hGjoZwWx8kwLuMyjQ7X6YodM0DcYGspowVsYXrV0Udzcur3rDQw1cFyI6K5n-ZFa8rsOg9ZuQnzS79mcmbY4RICUJphJEWpbqHu55TMpHdWzYvVJLP4679lc9g2BBMpSMNDzfVjhaOZO3jKAXsB83QrIgjuhkb6sBSOAsqWZT6fzekitMUzDrGLsZktGzTmg", "refresh_token": "eyJzdWIiOiJ0ZXN0LWJ1dHRvbnMtMDAxIiwiZW1haWwiOiJ0ZXN0LWJ1dHRvbnMtMDAxQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkJ1dHRvblRlc3QiLCJsYXN0X25hbWUiOiJVc2VyIn0"}}}	2026-03-07 22:32:29
TgWQl4qIFFSymei3KHK9DG7Kp6t5odxM	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-12T08:08:03.353Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772701683, "iat": 1772698083, "iss": "https://test-mock-oidc.replit.app/", "jti": "748e70d802701de12a64e9cb8ea3e651", "sub": "e2e-test-1772698062436", "name": "E2E Tester", "email": "e2e-1772698062436@test.com", "auth_time": 1772698083, "profile_image": ""}, "expires_at": 1772701683, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyNjk4MDgzLCJleHAiOjE3NzI3MDE2ODMsInN1YiI6ImUyZS10ZXN0LTE3NzI2OTgwNjI0MzYiLCJuYW1lIjoiRTJFIFRlc3RlciIsImVtYWlsIjoiZTJlLTE3NzI2OTgwNjI0MzZAdGVzdC5jb20iLCJwcm9maWxlX2ltYWdlIjoiIn0.qS4E023IsZHe37SQwKU52IVDW8fy5H12pNQRdH1LbFvJv0tNgk75cgfPAcOSPfNZSrhU4dBD2kVE8ihFyJxCl09AzVkPdNKMqRif62OiZdxHUKW3j2k2g0rd6elRK7S3W8gM2lU5kmQZujjnJHUcxRcbXlyz2EeaNatYRI1up42a9-x2RnBas8b6zE8gApFCj2YrPhEnj5PWTi-LrQr665TnPeY5PV0FdTs5QobQFxtTJ6ic7_tdl59JqK4a_WfxzR3gGMNVI2OmKWyH4HQZJ71KUfRLP-RWeCtxKwPDEH4dgsJ06xvZWOAT-Po6obp69avtcRU86yfgIhr4YNCtSg", "refresh_token": "eyJzdWIiOiJlMmUtdGVzdC0xNzcyNjk4MDYyNDM2IiwibmFtZSI6IkUyRSBUZXN0ZXIiLCJlbWFpbCI6ImUyZS0xNzcyNjk4MDYyNDM2QHRlc3QuY29tIiwicHJvZmlsZV9pbWFnZSI6IiJ9"}}}	2026-03-12 08:08:48
m-5KTHmEOcaTl0bExC3V9PDM-XYAUBvQ	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-08T23:07:48.026Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772410067, "iat": 1772406467, "iss": "https://test-mock-oidc.replit.app/", "jti": "5a6794aedaaecdf18265e5748bb6cd91", "sub": "nEiu_1", "email": "nEiu_1@example.com", "auth_time": 1772406467, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772410067, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyNDA2NDY3LCJleHAiOjE3NzI0MTAwNjcsInN1YiI6Im5FaXVfMSIsImVtYWlsIjoibkVpdV8xQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.XNtlEM5uP46wuxntI2MGFNrIf_BeSA_n0uptakuo9LDgRbnaXHe-YztvXA5zmmQLPHQU_uP5WyJg6QcnQo883BpQ3s42q8wZtRHY7RG11v0iqoh7KbMLLQL-189xLT9K1MAZVoWjrpPiEq_s-q8hwCDUoHVkIWQXHNJ_leomwgkQSk761hhZRodu2cCM67hs1FjTwh0YqhoOTOFrpdvgbDMLS_QS2ilD1MBmK559LhCXaBn-TZNzs5PhcpYvmTs9DUZOGKi_V9VK0jYCxu7gk3OjkRanNrgdjPrjogsY6MIbis4o2ma3E2egjy_c5300-uiycqGneFTdvtA_hI-MZw", "refresh_token": "eyJzdWIiOiJuRWl1XzEiLCJlbWFpbCI6Im5FaXVfMUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-08 23:11:03
0D0-lv4QD6HNsY9E5lbbBL5j30kLHw-L	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T23:23:35.911Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772324615, "iat": 1772321015, "iss": "https://test-mock-oidc.replit.app/", "jti": "1724af18c4f5742ee173420572b4b790", "sub": "35323958", "email": "35323958@example.com", "auth_time": 1772321015, "last_name": "Rej", "first_name": "Pete", "profile_image": ""}, "expires_at": 1772324615, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzIxMDE1LCJleHAiOjE3NzIzMjQ2MTUsInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiIzNTMyMzk1OEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJQZXRlIiwibGFzdF9uYW1lIjoiUmVqIiwicHJvZmlsZV9pbWFnZSI6IiJ9.dbZy8ik0JvUxGBwT-gm6izrkPkOk3RZlqMEVnECzqGbBVjKxmUCBzKljK-6t_6oEoAN00XTmnx9Y1eD2vY2PwO3wdHMCa0PXVqWibP_QJZwbQeTExxi64EC96rJQw9RnQsNfceSDsLC8iPjdcLozNMTbYOyGKRbIT19Bwrp6PO-j0qkPKo2b3VRnfQyTEoar4fLvrryWG9R78QYcz5FvUYqgBOGFjfXPholNFmmPGbew6sW72yuWRJsClKr8w9c2_g88hqaXtkGIAi7Px1jNCxwltaS9ogbvo8pA8AYfUdXHZg8WFGEhZb768Ck55iICPYKwa8DkGhkh8ua4JRs6sw", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiMzUzMjM5NThAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiUGV0ZSIsImxhc3RfbmFtZSI6IlJlaiIsInByb2ZpbGVfaW1hZ2UiOiIifQ"}}}	2026-03-07 23:24:24
Fkg4VSD6lx7VEgDOC7tKf9VkPLP0ql6b	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-09T01:06:15.486Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772417175, "iat": 1772413575, "iss": "https://test-mock-oidc.replit.app/", "jti": "b657443203244b223c691bc87919157f", "sub": "bugfix-test-1772413553541", "name": "Bug Tester", "email": "bugtest1772413553541@test.com", "auth_time": 1772413575, "profile_image": ""}, "expires_at": 1772417175, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyNDEzNTc1LCJleHAiOjE3NzI0MTcxNzUsInN1YiI6ImJ1Z2ZpeC10ZXN0LTE3NzI0MTM1NTM1NDEiLCJuYW1lIjoiQnVnIFRlc3RlciIsImVtYWlsIjoiYnVndGVzdDE3NzI0MTM1NTM1NDFAdGVzdC5jb20iLCJwcm9maWxlX2ltYWdlIjoiIn0.Z3Sy6QJnQ9P_S-oyl6_HMAvB-Ul9XLTYB3JgRr6is-4A_QTrvQ8EYIqczLiVctYO6XVMQko1__00DHDd5aijGdiE2DNXgCsv6L2UPffma2N7BnnPlgUCz_mTWOJT8obFMix3a3P_pp9C9iumIpwBFgM0S3PR3nwUnR40Wm6xVXBPIT7VSXC8yb28pGwjTI247GSetvJQ-KZjH_4fkptFngB74HYBSrLYS4oDnXSHvhJq0njDTcv1DPJa1Ezwa4c62nAyGPaR48zze7BuGqr5zt16_mNxxvJNeU7wXNnfBLg9gMIozS2RE9QCSCcuKU5Z1huRd4WQmlKAshiF9ZufeQ", "refresh_token": "eyJzdWIiOiJidWdmaXgtdGVzdC0xNzcyNDEzNTUzNTQxIiwibmFtZSI6IkJ1ZyBUZXN0ZXIiLCJlbWFpbCI6ImJ1Z3Rlc3QxNzcyNDEzNTUzNTQxQHRlc3QuY29tIiwicHJvZmlsZV9pbWFnZSI6IiJ9"}}}	2026-03-09 01:08:59
Mglmyfxii5n0soo0UDEzLMSSSK4BCQPy	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-08T18:22:22.421Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772392942, "iat": 1772389342, "iss": "https://test-mock-oidc.replit.app/", "jti": "db9af8647f4f7a05e40e2706810c8a95", "sub": "35323958", "email": "admin@test.com", "auth_time": 1772389342, "last_name": "User", "first_name": "Admin"}, "expires_at": 1772392942, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzg5MzQyLCJleHAiOjE3NzIzOTI5NDIsInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiJhZG1pbkB0ZXN0LmNvbSIsImZpcnN0X25hbWUiOiJBZG1pbiIsImxhc3RfbmFtZSI6IlVzZXIifQ.vDjBauaKBAU_cGOKAzvqHYT2NKzP5XnpZenHkQhsqaS86-uyLxvlIfXfzQ6zFVJOJptYfF-dWUWtWGix6gJdza8Pt0ZtRUctIvu5zeuak47DSyVuVLT4lYCIhIR_NECprJu8uqXz7ciVWoYS2hbHtGVoewb_Phk5_b4dCtrcnBA2bWbRSPQxPg6wjU-wPI5fR4wmS675d_fJU8FCQd84n0ij3mPHYbL2mpgGwtvrVGBn4YtslzqUTbd7OuzI7XM4TR7k_ngqk-XmbFfXkoQpa0eyYdtThA6ovjgnc8IknBeLRbPNhfTWPd9oFXWWwrDF9YbEqCVIvB0t8WHNOoKVBg", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiYWRtaW5AdGVzdC5jb20iLCJmaXJzdF9uYW1lIjoiQWRtaW4iLCJsYXN0X25hbWUiOiJVc2VyIn0"}}}	2026-03-08 18:24:04
abogvyRHkSfph4eIOsckmqizdXwCFnpH	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T23:20:12.257Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772324412, "iat": 1772320812, "iss": "https://test-mock-oidc.replit.app/", "jti": "c9ffadfca3721c5bd56323791d638993", "sub": "test-blend-001", "auth_time": 1772320812, "last_name": "User", "first_name": "BlendTest", "profile_image": ""}, "expires_at": 1772324412, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzIwODEyLCJleHAiOjE3NzIzMjQ0MTIsInN1YiI6InRlc3QtYmxlbmQtMDAxIiwiZmlyc3RfbmFtZSI6IkJsZW5kVGVzdCIsImxhc3RfbmFtZSI6IlVzZXIiLCJwcm9maWxlX2ltYWdlIjoiIn0.PLD5F6PKVMskK_A6Saqb-mOYqDDAl73PLihQXDWVSTEpwGBDp_-IBcFwaWj1BA2F_CxQGiVUwy_wNG23g5G6PISNtbYGaRxOwylHfxJpmUdzwwvJSGfkbSoBSO9ZZ3w2I8oqfJ-5A6ttL8iPivskSwnJH3nbUm_KwXvEVql_2faQVU9ELUGBbyC4MVgPh7dZJDK_a3AeIfZ1H9iJz5BKAGN5fwqwTTGT5JMOtPLNniPw-fPm7KleXCMeq5z82kaQV2im1siZ-Z2eKe1m0Dj0-Ci5yw04vc2KL9Jspwco4QG_QTUqeFe40u8ZNSyh6-oB125FnndByjYl987KOU1pRA", "refresh_token": "eyJzdWIiOiJ0ZXN0LWJsZW5kLTAwMSIsImZpcnN0X25hbWUiOiJCbGVuZFRlc3QiLCJsYXN0X25hbWUiOiJVc2VyIiwicHJvZmlsZV9pbWFnZSI6IiJ9"}}}	2026-03-07 23:20:20
E1j6NJhHPhB7l7ad0snPcAA27qZR5g6l	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-08T07:12:56.175Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772352776, "iat": 1772349176, "iss": "https://test-mock-oidc.replit.app/", "jti": "9820e94272348c6239cb03ac12acb091", "sub": "RqfxU0", "email": "RqfxU0@example.com", "auth_time": 1772349176, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772352776, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzQ5MTc2LCJleHAiOjE3NzIzNTI3NzYsInN1YiI6IlJxZnhVMCIsImVtYWlsIjoiUnFmeFUwQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.MJpMQIqwplqUJQz5S9bPnY-6MWbSyofZTwpOcSYDvavyF5sy--1t69lRpeZFmkGyuICnyjVqAnlQ66BFjL83G43sLCcAlJ0KfIk2aSsHsKlZtYTMV_jLNpfmE2LCRlzkIRrdmqTD2p7HJcsXzvM49ex8_RCahihCitDw_1Uy_Wmb6KI86mbBDSIM_aqGoH6vXyChN1V5zaJDp_Ak9UOOGmwX7_bW2UfvU8Q_Vkd2Hvnz4Ik9gLRf8ULVxrYcAtiiuHZ_dBAlyAbbpZfxv15iJ6f72RbXFAxP4JHZYksR6ngh8C_zojv9tOnD4P7s1ykb6-ht31jrziBImZbK3hVnpQ", "refresh_token": "eyJzdWIiOiJScWZ4VTAiLCJlbWFpbCI6IlJxZnhVMEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-08 07:13:48
x1alYhUz6KWA19XSKUd4mZuOZ86DfZZU	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-09T00:12:43.755Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772413963, "iat": 1772410363, "iss": "https://test-mock-oidc.replit.app/", "jti": "a7dc83eba3307938571630abbeff216b", "sub": "hE9ikf", "email": "hE9ikf@example.com", "auth_time": 1772410363, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772413963, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyNDEwMzYzLCJleHAiOjE3NzI0MTM5NjMsInN1YiI6ImhFOWlrZiIsImVtYWlsIjoiaEU5aWtmQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.SHFkr7J5DLMwndVqLc_YtGyP7xSl8OayhMSTxpYepRcbdlC8oQG4fvlevdA15EjfCgRPtlc6aPQnEHrm9ISKrA48kRqyEkcdhDyDhkR6JuDvqsWSrqWcknm_fDWnSpIuc2lGmaiCRrzc5VZwUUSrn-SXpUBw_Qz2Re4imPF1mc9M3NxpEKnZy6wpiQdivJ57CriBYG6p5kVfHDa2toghJ4GG7cJYgVvipRx4uy3ZeQN_MqzUSwJ098BH3qOI29TIRMdGKx2ODllKJB-Hxi8WacvD0DBaxG-4jwUpsRQHozDylH7FQ7iQHxGIvf9NNYTzAqnILOv30vri5ykBzLRlZw", "refresh_token": "eyJzdWIiOiJoRTlpa2YiLCJlbWFpbCI6ImhFOWlrZkBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-09 00:13:58
kkyCvPvUisYhoSwEpQuM32M8-SQqmR1s	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-09T00:44:25.448Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772415865, "iat": 1772412265, "iss": "https://test-mock-oidc.replit.app/", "jti": "6f445e5481a9089249607fe7d93fb519", "sub": "72Nckd", "email": "72Nckd@example.com", "auth_time": 1772412265, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772415865, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyNDEyMjY1LCJleHAiOjE3NzI0MTU4NjUsInN1YiI6IjcyTmNrZCIsImVtYWlsIjoiNzJOY2tkQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.CXR8rSfI4iQQc4x9A7HYpGKjqRf30YVAbMiYRSEQ58ZHSJoUwYmPOaoubRhSBR7gC01GOM5rnlbQWE12Xs_7-hv2pXbfvVwX1rGR0QHM3ApH94w14z1GqKCw-yDH2qvEmxTeNVMQxTbmo1dizwGK5PyRF7FNR0YJiMxlI54KEzwSpPJGIlKxP3fe9gAHfQvn_7uRERNnBFHQg870HYsOh3CLPh9ve7DbqjZLR56snhq87Okig0O7IH7JDfIrmqp5z2dZ2FYgQm8mSnjYBJA776npjx-xbuwSmP4NT6f0_rNand9C-Q4d5FnzT7OpwO0ttpBbHBAlIcxD98rKBILOKQ", "refresh_token": "eyJzdWIiOiI3Mk5ja2QiLCJlbWFpbCI6IjcyTmNrZEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-09 00:46:00
SCKxu2ele_NZdh3g_xReH13XAN-KtJ3Q	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-12T00:17:41.197Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772673461, "iat": 1772669861, "iss": "https://test-mock-oidc.replit.app/", "jti": "adfec38139f2d38e45381941aefaf365", "sub": "35323958", "email": "4980005@gmail.com", "auth_time": 1772669861, "last_name": "Rej", "first_name": "Pete"}, "expires_at": 1772673461, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyNjY5ODYxLCJleHAiOjE3NzI2NzM0NjEsInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiI0OTgwMDA1QGdtYWlsLmNvbSIsImZpcnN0X25hbWUiOiJQZXRlIiwibGFzdF9uYW1lIjoiUmVqIn0.La0iPLC3lT5WyyChBp3wLdgloFLxFLSkgGyXvyHcZ3-u9euoM4hyKUSV-QWhy0i-tJG3naEXPCYJI1BkIXZBpkw7zoRLX4WBbunGeuazw3tlkZnS5FrNdBFfn9AYzPf28GEjcf_CspGVzkj0U_hynfEda-icg-fv6RsbcT_jnlVDFIelHgKWQBKYJcnOMOC7nLjiKXOykMYUE8ENqN2tqhMcaWcpXM0Z1wE3HNOtALuDST6_FFmTYt1M7Gk4LRAmLrbHPyV8vRYwSDdGBzVze-uohFLEEp2C5OoZdVBwsvJX8AhKU6T6tsYuwK-maTV34U1ZnVZkHwQSSvS69vK8vQ", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiNDk4MDAwNUBnbWFpbC5jb20iLCJmaXJzdF9uYW1lIjoiUGV0ZSIsImxhc3RfbmFtZSI6IlJlaiJ9"}}}	2026-03-12 00:18:17
JJjuRtmEFvbHZJKKn1j5a2wSXsdpK7zI	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-09T01:05:12.666Z", "httpOnly": true, "originalMaxAge": 604800000}, "test-mock-oidc.replit.app": {"code_verifier": "sx2cVQHgNDNBiDG3UyySQpEzh0YIHqM7Facj68Jf3Bw"}}	2026-03-09 01:05:13
dAS69NziP8bAXNo8o5fakIEI-R-JNDZQ	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-10T06:19:23.048Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772522363, "iat": 1772518763, "iss": "https://test-mock-oidc.replit.app/", "jti": "a6060ce19f2ea4bd41ec306edfbeff6d", "sub": "admin-test-user", "email": "admin@test.com", "auth_time": 1772518762, "last_name": "Tester", "first_name": "Admin"}, "expires_at": 1772522363, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyNTE4NzYzLCJleHAiOjE3NzI1MjIzNjMsInN1YiI6ImFkbWluLXRlc3QtdXNlciIsImVtYWlsIjoiYWRtaW5AdGVzdC5jb20iLCJmaXJzdF9uYW1lIjoiQWRtaW4iLCJsYXN0X25hbWUiOiJUZXN0ZXIifQ.bFsSKJuDfhQiqUdem_E6LCWWWc_VWb4GLJ_qRfpRL7bROUiszPYNpmXuF8rh7-_2NcCALTFGvEnZ9yKS2FxEvhDhQhGpS125g-Wf_mB_WIzk6jIDTtgh6vCerOMNxNOCA59pz5UJEFdlLowDLTRVdhg9faKfiNC06EKUTR9PcyXOQQ3thSU94WTzyA-z2rmBCmQlP40xyCb_X5GV-Tqd4ur8ZONxyvMUAVktWGrevVrl4a7eSZE9pMQ_VR4dvCC8tFBTrn1yOehSl4vc8QCx61cuJxi4cDua5hLYWR6Q2_jCLr0w8nMoc8JNmmWzPwKwt-TwpiKha36gLFftqY73dA", "refresh_token": "eyJzdWIiOiJhZG1pbi10ZXN0LXVzZXIiLCJlbWFpbCI6ImFkbWluQHRlc3QuY29tIiwiZmlyc3RfbmFtZSI6IkFkbWluIiwibGFzdF9uYW1lIjoiVGVzdGVyIn0"}}}	2026-03-10 06:19:59
6-rnWdhAom1bbSaIz-DfRdvrFQi-4HtB	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-10T06:24:34.299Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772522674, "iat": 1772519074, "iss": "https://test-mock-oidc.replit.app/", "jti": "c3983b8d8713105ec96263d1597a5f6a", "sub": "admin-test-user-2", "email": "admin2@test.com", "auth_time": 1772519074, "last_name": "Tester 2", "first_name": "Admin"}, "expires_at": 1772522674, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyNTE5MDc0LCJleHAiOjE3NzI1MjI2NzQsInN1YiI6ImFkbWluLXRlc3QtdXNlci0yIiwiZW1haWwiOiJhZG1pbjJAdGVzdC5jb20iLCJmaXJzdF9uYW1lIjoiQWRtaW4iLCJsYXN0X25hbWUiOiJUZXN0ZXIgMiJ9.gxY8gSf9nCy88-0BwLn9XOZefuZJW5JBppai8aawhkOYIDVkx8qsBeMmnB1X7n6UxqxXEkQd0eH4U-tpnQY_6CGnz7Lpj7cN_hI9d3rzIaPdd16AXMxRgvQrTScKNC5iZ5NBvNiRvgrJb4R9eshGf98Wgsug_wYRJ-P8mi79xzPXz4A1nbB3iNJExPIHHoPR62PIiWkSKNqF3p-20lq48oaFm4qn2c9zJXbu2qm9VW0omjRNmVWzzqtJmjTmIPJC_G8gKQ_-Q55xgdENF20BCCrae3U47d-jogDslmaf6n3gyxASxTj33CRp5jn4lfp7Bx6ej0dPfX2dcznnTcuu5Q", "refresh_token": "eyJzdWIiOiJhZG1pbi10ZXN0LXVzZXItMiIsImVtYWlsIjoiYWRtaW4yQHRlc3QuY29tIiwiZmlyc3RfbmFtZSI6IkFkbWluIiwibGFzdF9uYW1lIjoiVGVzdGVyIDIifQ"}}}	2026-03-10 06:25:12
KeihpzxJaRqvZ3mNzC_n0Snt6juAG5j-	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-10T06:28:09.890Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772522889, "iat": 1772519289, "iss": "https://test-mock-oidc.replit.app/", "jti": "8f79c143e7843e0c1a3a58ae094ebdf2", "sub": "admin-test-user-typing", "name": "Typing Tester", "email": "typing@test.com", "roles": "admin", "auth_time": 1772519289}, "expires_at": 1772522889, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyNTE5Mjg5LCJleHAiOjE3NzI1MjI4ODksInN1YiI6ImFkbWluLXRlc3QtdXNlci10eXBpbmciLCJuYW1lIjoiVHlwaW5nIFRlc3RlciIsImVtYWlsIjoidHlwaW5nQHRlc3QuY29tIiwicm9sZXMiOiJhZG1pbiJ9.LfVJYwBvH_RpKzfKG7_6KqXTP4QvekGfBl2PYKg94bDxH5s4TWOSBV59F2yNNXfwdZIEGfDJ8U-DPOKEMlHJNzAW4oWuH4baHKyS0w8xP_6KBdzzdLjUUpVnhfrvU_18-C85pPP5LodSZrF02A49rs17qkuRf7sALv9HP_OcbfYwdIuja_3l9EvapWab5_jTgEr7lAn9mjCD4IbJ94K50ezG46EDqVr4k0thAIIpY5GpvUQuv40plEI7Hhud3sBHBMriqODzzlWfFnQ6ECW2eH0OSaRvGjGx1O4jF7fJMvzvH_PA-lrnjc98X7PCTecWsuPvIWQYxcBJmto4Btsx3Q", "refresh_token": "eyJzdWIiOiJhZG1pbi10ZXN0LXVzZXItdHlwaW5nIiwibmFtZSI6IlR5cGluZyBUZXN0ZXIiLCJlbWFpbCI6InR5cGluZ0B0ZXN0LmNvbSIsInJvbGVzIjoiYWRtaW4ifQ"}}}	2026-03-10 06:28:19
HFV2As8vMU70W9WNQOxw8rXZFpUMwhOW	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-08T23:54:26.047Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772412866, "iat": 1772409266, "iss": "https://test-mock-oidc.replit.app/", "jti": "3b98e885cd75721a714736a28e8df339", "sub": "VouA0h", "email": "VouA0h@example.com", "auth_time": 1772409265, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772412866, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyNDA5MjY2LCJleHAiOjE3NzI0MTI4NjYsInN1YiI6IlZvdUEwaCIsImVtYWlsIjoiVm91QTBoQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.okBI-J66_4oM5TlWqYsygamcasaWerOKboJJIqnE7DhSQeZma6viZjNwNrICXbBSBt0ZgCBA8fg7GbqFXZ0JUjGF4WluC4FKNaiAN-PWM5J6Mxts6k3YJzZ3IxyM4TgaS2bclRuqtQPI4hDv3EheB3e7qlwJbxVXotHCjSM8FsT039_FgXAExiBSJoiwMkKM_ipfhl4ObOvARF62FaRDUz70kBzWefJoBqEfHgwn6d5dx8-hiH5ALuo8eMhQeWl5d0aVW-KDG46tozikv7CXUFdUghBQSp6crv2gCXIyjXScJKqewRb90p0YhUMujbwyYGNFNupzTVls_3_fo797nw", "refresh_token": "eyJzdWIiOiJWb3VBMGgiLCJlbWFpbCI6IlZvdUEwaEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-08 23:55:44
7yoaH552bKjeQLUihfa-jEB-k70jf9o2	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-12T01:31:07.201Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772677867, "iat": 1772674267, "iss": "https://test-mock-oidc.replit.app/", "jti": "e0f0b7211f7d333709877b6be5308c9c", "sub": "UyErpn", "email": "UyErpn@example.com", "auth_time": 1772674267, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772677867, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyNjc0MjY3LCJleHAiOjE3NzI2Nzc4NjcsInN1YiI6IlV5RXJwbiIsImVtYWlsIjoiVXlFcnBuQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.vWOJGl4PO8mKV2-TCh6_hqzSIV1IFSX7he0XVMxFXp037mz1PhtlbRkFmO6mZZfvP1SEx4LOSr6f4hytzTYx8M8u5YTOYp_iazKXPadZHFuiQ7HLO0sCkm9VQFYQQYr3l4PYvf9yQoT4_OMXdZanGgzBV1X12vUgv-46N7XYVYbHG0uYPTAS3AsI6oKkVXEwHvRDX13klx_F8rpoglnOXL--jKwVkkVCSzms6amW-_UmgEHHvFk9-i_6ypNLbK7NOaDcOc-dbzTqxdiyfDIji48_Za1y-WCTUiHNYpdeZqlov4E7KA518vctWNofGzfX2JK2KD-eYty-WGJaR4FBug", "refresh_token": "eyJzdWIiOiJVeUVycG4iLCJlbWFpbCI6IlV5RXJwbkBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-12 01:32:21
\.


--
-- Data for Name: short_views; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.short_views (id, short_id, user_id, viewed_at) FROM stdin;
bce0845e-c92a-47cf-9fd1-b22925c1e33d	c69aba67-6c04-499a-b472-12fa4e6260cc	f0PZaY	2026-03-01 22:10:17.524193
7d8c68fb-3109-418e-8dfe-4d5e3923808a	c69aba67-6c04-499a-b472-12fa4e6260cc	G35IpT	2026-03-01 23:05:07.544184
daeb8c5d-f33e-487b-839a-332003252a38	c69aba67-6c04-499a-b472-12fa4e6260cc	G35IpT	2026-03-01 23:05:46.946593
2a0ef20e-f252-445c-a8ae-38f0c79d3f9e	c69aba67-6c04-499a-b472-12fa4e6260cc	nEiu_1	2026-03-01 23:08:30.618307
e2830891-d611-4b19-8582-c93dd4c9ecf1	c69aba67-6c04-499a-b472-12fa4e6260cc	VouA0h	2026-03-01 23:54:51.631546
d0673dc1-cae8-478a-bb82-2e7d84755f69	c69aba67-6c04-499a-b472-12fa4e6260cc	72Nckd	2026-03-02 00:45:09.017353
7d39ddf0-8842-414b-96a0-8e50e3e498d5	c69aba67-6c04-499a-b472-12fa4e6260cc	bugfix-test-1772413553541	2026-03-02 01:07:53.631932
36a7dc59-03cd-4a9f-848b-49fe4ce1af01	c69aba67-6c04-499a-b472-12fa4e6260cc	35323958	2026-03-02 18:13:30.065831
a0393e48-5d70-4c48-99f2-60ba5a20c4ff	c69aba67-6c04-499a-b472-12fa4e6260cc	35323958	2026-03-02 18:23:21.697607
f249a273-e075-4e63-b048-252f8f11218b	c69aba67-6c04-499a-b472-12fa4e6260cc	35323958	2026-03-05 00:30:18.091021
0be30ab1-dd08-4562-a78b-6f7f9f060b05	8e5a19c1-1936-4fd8-b33b-1da4892b0bc7	35323958	2026-03-05 00:30:22.139149
1c03b859-41e7-4592-aacf-e57419aef78e	80c76248-5fdc-4416-aed2-dab2e8aa09e8	35323958	2026-03-05 00:30:31.256731
19668892-1440-424d-9d74-9f213f44e19c	80c76248-5fdc-4416-aed2-dab2e8aa09e8	35323958	2026-03-05 00:31:09.493899
7413c207-9a22-483d-a72f-facf9b85f33b	fdcd5c69-c124-4fc8-a52f-29f3340ce2fc	35323958	2026-03-05 00:31:13.153712
0acb166c-e5b7-4f1a-8d70-015efc78e276	c69aba67-6c04-499a-b472-12fa4e6260cc	UyErpn	2026-03-05 01:32:20.670191
9d55d165-58cd-4214-997e-da72e8b7ed77	c69aba67-6c04-499a-b472-12fa4e6260cc	1l02Ad	2026-03-05 01:36:32.710369
aaa72252-3a45-4971-a2ac-8de8b439e98f	942f8bea-2f4d-4620-8418-0337616296f0	1l02Ad	2026-03-05 01:37:28.646817
58d71716-4abb-46b4-ab50-0a9a54e62691	8e5a19c1-1936-4fd8-b33b-1da4892b0bc7	1l02Ad	2026-03-05 01:37:45.660748
c2fd01df-19e2-4b46-8899-9a8b32649e55	4997d4bc-2676-4843-89ed-709e5b4b070e	1l02Ad	2026-03-05 01:38:13.308415
7df4320a-4260-4086-b357-1db89786bd1b	c69aba67-6c04-499a-b472-12fa4e6260cc	e2e-test-1772698062436	2026-03-05 08:08:28.094796
55119ab2-bdb9-44e0-a902-a8575f8ed03e	942f8bea-2f4d-4620-8418-0337616296f0	35323958	2026-03-05 09:29:38.306612
9149d6fb-870b-42f0-94eb-348feb454638	4997d4bc-2676-4843-89ed-709e5b4b070e	35323958	2026-03-05 09:29:48.865623
e0159d8c-0601-41ce-9c15-b465b5bd6be3	8e5a19c1-1936-4fd8-b33b-1da4892b0bc7	35323958	2026-03-05 09:29:53.494592
7e064491-d887-4e97-bb07-4088cdba86dd	4997d4bc-2676-4843-89ed-709e5b4b070e	35323958	2026-03-05 09:29:57.161314
a6d50aef-a910-4272-8230-149d986e0f03	273c2058-0d15-40c8-b913-780fcd5bd3ea	35323958	2026-03-05 09:29:58.461624
1c70fdb0-33b8-4ccb-9e42-ee67a01e3095	e61c1ca0-015c-4aeb-b65d-32f2c5ad62aa	35323958	2026-03-05 09:29:59.605811
acc1eb21-996a-46a7-9e1d-c3d03e45cddf	7d9d4151-6912-4921-95d3-8fcdfe02a849	35323958	2026-03-05 09:30:00.51353
73db6d54-b434-455f-8231-3778e2c1813d	11496859-e56a-42ae-bc25-ed7e1f4f5ed3	35323958	2026-03-05 09:30:01.545946
01128547-7a15-4a51-8b69-0b1753673147	f264e3bc-2a47-460b-8e47-9c98e0525f4f	35323958	2026-03-05 09:30:02.485628
3df42c87-24d7-4bd8-bbbb-351270715b83	25a64d4a-04b2-4628-a9c5-2d3daa89a6bf	35323958	2026-03-05 09:30:03.241705
309b5aaf-32f3-495d-9352-0bec3450ce57	fdcd5c69-c124-4fc8-a52f-29f3340ce2fc	35323958	2026-03-05 09:30:03.973474
10ee919f-bc9d-4c11-a71d-de0b2fe62d74	80c76248-5fdc-4416-aed2-dab2e8aa09e8	35323958	2026-03-05 09:30:05.878576
\.


--
-- Data for Name: shorts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shorts (id, book_id, title, content, media_type, media_url, thumbnail_url, background_gradient, duration, order_index, status, created_at, updated_at) FROM stdin;
c69aba67-6c04-499a-b472-12fa4e6260cc	2ea408e9-dc96-444c-a0dc-93901f9029b5	The 1% Rule That Changes Everything	If you get just 1% better each day, you'll be 37 times better in one year. The secret isn't massive action — it's tiny, consistent improvements that compound over time. Your habits are the compound interest of self-improvement.	text	\N	\N	linear-gradient(135deg, #6B21A8, #9333EA, #A855F7)	15	1	published	2026-03-01 18:15:07.99293	2026-03-01 18:15:07.99293
942f8bea-2f4d-4620-8418-0337616296f0	2ea408e9-dc96-444c-a0dc-93901f9029b5	You Don't Rise to Your Goals	You don't rise to the level of your goals. You fall to the level of your systems. Every Olympic athlete wants to win gold — the difference is in the daily systems they build. Stop obsessing over outcomes. Build better systems instead.	text	\N	\N	linear-gradient(135deg, #7C3AED, #8B5CF6, #C084FC)	15	2	published	2026-03-01 18:15:07.99293	2026-03-01 18:15:07.99293
8e5a19c1-1936-4fd8-b33b-1da4892b0bc7	7ba8d165-4195-43a3-9079-518dd4332439	Your Brain Has Two Pilots	System 1 is your autopilot — fast, intuitive, and often wrong. System 2 is your co-pilot — slow, deliberate, and lazy. Most of your 'decisions' are actually System 1 reflexes that System 2 never bothered to check. The key? Know which system is flying.	text	\N	\N	linear-gradient(135deg, #1E3A5F, #2563EB, #60A5FA)	15	3	published	2026-03-01 18:15:07.99293	2026-03-01 18:15:07.99293
4997d4bc-2676-4843-89ed-709e5b4b070e	7ba8d165-4195-43a3-9079-518dd4332439	The Anchoring Trap	The first number you hear in any negotiation becomes your anchor — and it silently controls the entire outcome. Even random numbers influence your estimates. Next time someone throws out a number first, pause. Ask yourself: is this anchor real, or is it manipulating me?	text	\N	\N	linear-gradient(135deg, #0F766E, #14B8A6, #5EEAD4)	15	4	published	2026-03-01 18:15:07.99293	2026-03-01 18:15:07.99293
273c2058-0d15-40c8-b913-780fcd5bd3ea	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	The Only Moment That Exists	Nothing has ever happened in the past. It happened in the Now. Nothing will ever happen in the future. It will happen in the Now. The present moment is literally all you ever have. Yet most people spend their entire lives lost in memories and projections.	text	\N	\N	linear-gradient(135deg, #581C87, #7E22CE, #D8B4FE)	15	5	published	2026-03-01 18:15:07.99293	2026-03-01 18:15:07.99293
e61c1ca0-015c-4aeb-b65d-32f2c5ad62aa	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	You Are Not Your Thoughts	The moment you realize you are not present, you ARE present. You can't observe the thinker if you ARE the thinker. This gap — between the thought and the awareness of the thought — is where freedom lives. Watch your mind like you'd watch clouds passing.	text	\N	\N	linear-gradient(135deg, #4C1D95, #6D28D9, #A78BFA)	15	6	published	2026-03-01 18:15:07.99293	2026-03-01 18:15:07.99293
7d9d4151-6912-4921-95d3-8fcdfe02a849	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	The 6-Second Rule	Your amygdala can hijack your brain in milliseconds — triggering anger, fear, or panic before your rational mind even wakes up. The antidote? Six seconds. One full breath cycle. That's all it takes to let your prefrontal cortex catch up and choose a better response.	text	\N	\N	linear-gradient(135deg, #9F1239, #E11D48, #FB7185)	15	7	published	2026-03-01 18:15:07.99293	2026-03-01 18:15:07.99293
11496859-e56a-42ae-bc25-ed7e1f4f5ed3	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	Name It to Tame It	When you name an emotion — 'I notice I'm feeling anxious right now' — brain scans show the amygdala's activity drops by up to 50%. Labeling emotions engages your prefrontal cortex, which calms the emotional brain. Awareness is not weakness. It's your superpower.	text	\N	\N	linear-gradient(135deg, #B91C1C, #DC2626, #F87171)	15	8	published	2026-03-01 18:15:07.99293	2026-03-01 18:15:07.99293
f264e3bc-2a47-460b-8e47-9c98e0525f4f	23f2345b-6336-4573-a63f-8ee2cd34f56b	The Last Human Freedom	Everything can be taken from a person except one thing: the freedom to choose your attitude in any circumstance. Viktor Frankl discovered this in Auschwitz. The guards could control his body, but never his mind. Between stimulus and response, there is a space. In that space is your power.	text	\N	\N	linear-gradient(135deg, #1E40AF, #3B82F6, #93C5FD)	15	9	published	2026-03-01 18:15:07.99293	2026-03-01 18:15:07.99293
25a64d4a-04b2-4628-a9c5-2d3daa89a6bf	23f2345b-6336-4573-a63f-8ee2cd34f56b	Why Happiness Can't Be Chased	Happiness cannot be pursued — it must ensue. The more you chase happiness directly, the more it eludes you. It comes as a side effect of dedicating yourself to a cause greater than yourself, or loving another person deeply. Stop chasing. Start meaning.	text	\N	\N	linear-gradient(135deg, #312E81, #4338CA, #818CF8)	15	10	published	2026-03-01 18:15:07.99293	2026-03-01 18:15:07.99293
fdcd5c69-c124-4fc8-a52f-29f3340ce2fc	2ea408e9-dc96-444c-a0dc-93901f9029b5	Identity Beats Motivation	Don't say 'I want to read more.' Say 'I am a reader.' Every action you take is a vote for the type of person you wish to become. No single vote is decisive, but as the votes build up, the evidence of your new identity builds up too. Become the person, then the habits follow.	text	\N	\N	linear-gradient(135deg, #92400E, #D97706, #FCD34D)	15	11	published	2026-03-01 18:15:07.99293	2026-03-01 18:15:07.99293
80c76248-5fdc-4416-aed2-dab2e8aa09e8	7ba8d165-4195-43a3-9079-518dd4332439	Losses Hit Twice as Hard	Losing $100 feels about twice as painful as gaining $100 feels good. This asymmetry — loss aversion — shapes almost every decision you make. It's why you hold losing stocks too long, stay in bad relationships, and fear change even when the odds favor it.	text	\N	\N	linear-gradient(135deg, #065F46, #059669, #6EE7B7)	15	12	published	2026-03-01 18:15:07.99293	2026-03-01 18:15:07.99293
\.


--
-- Data for Name: user_activity_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_activity_log (id, user_id, event_type, event_data, book_id, session_duration, created_at) FROM stdin;
\.


--
-- Data for Name: user_interests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_interests (id, user_id, interests, onboarding_completed, created_at) FROM stdin;
bb1ecc9c-9824-4f4e-a8b7-13070c8124b8	35323958	{emotional-iq}	t	2026-02-23 05:26:51.849636
38ce5c5e-f6e8-41b0-a3fe-04b8c4dbf316	U1mC5u	{habits,productivity,mindfulness}	t	2026-02-25 13:37:54.238686
7d80f338-7e42-466e-ae64-8996273db83d	test-user-123	{mindfulness,habits}	t	2026-02-27 02:24:02.127362
28ce8c5e-cf34-4237-b5e5-963067b71501	test-user-42	{emotional-iq}	t	2026-02-27 06:07:30.278044
4c074693-ea1b-4e91-88fe-0884c74861dc	tcBg5V	{anxiety}	t	2026-02-27 08:12:46.038503
eb478ac3-b9c5-4795-8df2-fb22fd9bb5fd	X5bqd-	{anxiety}	t	2026-02-27 08:21:33.307886
bce4b2ef-a3a4-4574-8743-e84b45bf1d51	b5yZvL	{productivity}	t	2026-02-27 08:27:29.483258
9e0bc196-8137-4a6a-9deb-b8a4020f3b70	yuVB4U	{anxiety,productivity}	t	2026-02-27 08:39:19.659355
6c352b80-5f76-45f8-b667-3dd90e37548d	a8S2dP	{anxiety}	t	2026-02-27 09:03:06.494449
d676c4fd-66e2-413f-a878-017650a94731	j69UEF	{anxiety}	t	2026-02-27 09:08:43.286694
2733cc0d-5cf8-45cf-b608-7ea61a340144	pIDdI2	{habits,mindfulness,productivity}	t	2026-02-27 09:12:33.714156
83fea42f-1e7f-4e06-81c9-97a90a365023	Jkp87u	{habits}	t	2026-02-27 09:19:40.01199
1dcc7694-3ff7-497b-be1e-db83e720feda	tImpmS	{habits}	t	2026-02-27 09:30:25.016579
5a52d725-9681-411b-8e8e-bc8689e8c8fe	9BmmO0	{habits}	t	2026-02-27 09:48:27.140761
5e52d733-284a-4800-8ed7-f9adf7eb62b3	W46Jai	{habits}	t	2026-02-27 10:13:38.390925
1bfe4dfa-7f7b-406d-8c19-80ae9cdbb70b	oU-UWK	{habits,mindfulness,productivity}	t	2026-02-27 14:59:41.189419
1b035a70-a262-4bf8-bc27-96d14b74be13	a_rJjy	{habits}	t	2026-02-27 15:05:16.244066
c62ef76b-c5f3-4903-8972-d40ba4426f21	Wc93iB	{habits}	t	2026-02-28 05:35:23.702294
8aa2315f-ea9b-4388-a4bd-7988cd3d8f4d	8wB_v6	{habits}	t	2026-02-28 05:53:05.888245
13d47837-7db8-4213-80bc-5086c3ab3202	z5Axnh	{habits}	t	2026-02-28 07:13:30.369264
fcbdf699-f4f1-4751-87a4-e8a56f81cf7e	aZw-6w	{anxiety}	t	2026-02-28 18:58:33.334972
2b7bbd58-79f5-4e93-b20f-89be18591129	1udX-Q	{anxiety}	t	2026-02-28 19:19:03.433448
406f9f91-a7d1-410c-a025-4449233db541	BQ7kP2	{anxiety,productivity}	t	2026-02-28 20:48:02.932274
138d2c82-a75e-4acf-8405-994ee334aede	test-user-999	{productivity,mindfulness}	t	2026-02-28 21:33:56.820943
03920d6c-0e15-41f0-9d2d-3deac50dc7c9	test-sweep-001	{anxiety}	t	2026-02-28 21:42:26.641403
4e1a114e-b227-4bea-99ea-d8d220a164af	test-fix-007	{anxiety}	t	2026-02-28 22:08:14.791338
be301104-f588-4ee2-a04c-8d622f730619	admin-check-001	{habits}	t	2026-02-28 22:29:29.053358
a0165440-8d04-463a-9a7f-a2564edb5076	test-buttons-001	{anxiety}	t	2026-02-28 22:31:24.800609
e2009362-d34f-45e6-8897-58fa3fe33e27	kWBQ4S	{habits}	t	2026-03-01 06:49:19.20702
fd2951a0-6d23-49c6-b78c-b5767f679b61	RqfxU0	{habits,mindfulness}	t	2026-03-01 07:13:12.205438
63210e21-79a3-49ed-9fdd-e54347019bb1	WJNhpw	{habits,productivity}	t	2026-03-01 17:41:37.53461
240e8760-6f63-4800-8861-2b9d1461939f	-GHxm6	{anxiety}	t	2026-03-01 20:15:35.124461
d59e36b2-0652-4c8d-b3dc-ead1ecc8e06e	f0PZaY	{anxiety}	t	2026-03-01 22:09:23.889971
b940f13e-307a-4069-ade0-6c6836de6f97	E4d0vZ	{habits}	t	2026-03-01 22:29:36.972861
7838c6c6-8a89-4b30-ab51-15b00b8f8b4f	G35IpT	{anxiety}	t	2026-03-01 23:04:31.625652
84c5c0f0-f9ce-4309-9f6c-16023e005e31	nEiu_1	{habits}	t	2026-03-01 23:07:55.214152
7473f1f8-5d2b-4a37-992e-bda658402748	VouA0h	{habits}	t	2026-03-01 23:54:41.577086
bb73c855-f816-4c64-be37-c0a2650a70a2	hE9ikf	{habits}	t	2026-03-02 00:12:59.046037
f60d763f-82ef-4292-a142-38364289c57f	72Nckd	{habits}	t	2026-03-02 00:44:39.805592
01a4c5b7-6d85-4943-80e1-5fe70ae8077d	bugfix-test-1772413553541	{anxiety}	t	2026-03-02 01:06:37.150824
426f8ca1-df90-4c3c-bbb7-63307e387985	UyErpn	{anxiety}	t	2026-03-05 01:31:34.219169
063074ff-58a7-473f-8665-e811741caa90	1l02Ad	{anxiety}	t	2026-03-05 01:35:41.074619
6156db13-ab1e-42d7-92f1-160fa8b770ac	e2e-test-1772698062436	{productivity}	t	2026-03-05 08:08:17.608337
\.


--
-- Data for Name: user_progress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_progress (id, user_id, book_id, bookmarked, last_accessed_at, current_card_index, total_cards, current_section) FROM stdin;
53cecf59-35cd-4a7c-9324-718eb14dec29	nEiu_1	2ea408e9-dc96-444c-a0dc-93901f9029b5	f	2026-03-01 23:10:08.714	2	17	chapter-summaries
d5f6d78e-e0bc-417c-afaa-0c29209ac61d	pIDdI2	7ba8d165-4195-43a3-9079-518dd4332439	f	2026-02-27 09:14:35.462888	1	9	chapter-summaries
fb931232-37e7-482e-8002-4f4f7e507fe3	35323958	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	f	2026-02-27 12:28:12.27	4	6	infographics
644677c8-4837-4fed-877d-0e4d320961cc	8wB_v6	2ea408e9-dc96-444c-a0dc-93901f9029b5	f	2026-02-28 05:54:47.178398	1	17	chapter-summaries
63dd6f1a-ff3f-4f89-8a90-dd792da42843	35323958	2ea408e9-dc96-444c-a0dc-93901f9029b5	t	2026-02-28 06:53:30.128	2	17	chapter-summaries
55ed264b-d004-4d78-b9bd-520b69d9d2be	35323958	23f2345b-6336-4573-a63f-8ee2cd34f56b	f	2026-02-27 01:45:59.999	1	9	chapter-summaries
4e29b531-a9b1-470c-a6d0-c94b35f1cd8a	35323958	7ba8d165-4195-43a3-9079-518dd4332439	f	2026-03-01 01:19:04.737	4	5	mental-models
c54091dd-691e-45c9-aa54-921f52c258f2	test-user-42	23f2345b-6336-4573-a63f-8ee2cd34f56b	t	2026-02-27 06:17:53.503	1	9	chapter-summaries
0e09cb3c-3696-43bf-bf36-f74b6dfd405a	E4d0vZ	2ea408e9-dc96-444c-a0dc-93901f9029b5	f	2026-03-01 22:31:50.071998	1	17	chapter-summaries
\.


--
-- Data for Name: user_streaks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_streaks (id, user_id, current_streak, longest_streak, last_active_date, total_minutes_listened, total_books_started, streak_freeze_available, last_freeze_used_at) FROM stdin;
4b16239a-e9f5-4070-870d-88b068127147	test-user-42	1	1	2026-02-27	0	0	t	\N
47bb5af8-9d0f-4115-a392-9c7e57eedd4d	pIDdI2	1	1	2026-02-27	0	0	t	\N
c89ffaf3-443e-4a74-919a-174c5dcff75a	8wB_v6	1	1	2026-02-28	0	0	t	\N
6d5cbc3f-8cae-4c59-9616-986bcf660f95	35323958	7	7	2026-03-01	0	0	t	\N
a975ccc0-27c4-4612-8698-e27e42fff2d4	E4d0vZ	1	1	2026-03-01	0	0	t	\N
d24fcd50-c70d-41fd-92f9-31afee8e757f	nEiu_1	1	1	2026-03-01	0	0	t	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, first_name, last_name, profile_image_url, created_at, updated_at, role, is_premium, stripe_customer_id, stripe_subscription_id, current_period_end) FROM stdin;
a8S2dP	a8S2dP@example.com	John	Doe	\N	2026-02-27 09:02:45.768094	2026-02-27 09:02:45.768094	super_admin	f	\N	\N	\N
j69UEF	j69UEF@example.com	Admin	User	\N	2026-02-27 09:08:18.549195	2026-02-27 09:08:18.549195	user	f	\N	\N	\N
admin-test-user	admin@test.com	Admin	Tester	\N	2026-03-03 06:17:42.547023	2026-03-03 06:19:23.027	admin	f	\N	\N	\N
pIDdI2	pIDdI2@example.com	John	Doe	\N	2026-02-27 09:12:21.504085	2026-02-27 09:12:21.504085	user	f	\N	\N	\N
Jkp87u	Jkp87u@example.com	Customer	User	\N	2026-02-27 09:19:27.22225	2026-02-27 09:19:27.22225	user	f	\N	\N	\N
U1mC5u	U1mC5u@example.com	John	Doe	\N	2026-02-25 13:37:43.02982	2026-02-25 13:37:43.02982	user	f	\N	\N	\N
tImpmS	tImpmS@example.com	Replit	User	\N	2026-02-27 09:30:08.881955	2026-02-27 09:30:08.881955	user	f	\N	\N	\N
nH8jar	nH8jar@example.com	Admin	User	\N	2026-02-25 13:44:46.523579	2026-02-25 13:44:46.523579	admin	f	\N	\N	\N
9BmmO0	9BmmO0@example.com	Replit	User	\N	2026-02-27 09:47:49.212253	2026-02-27 09:47:49.212253	user	f	\N	\N	\N
VaoZ0a	VaoZ0a@example.com	Admin	User	\N	2026-02-25 13:57:07.727847	2026-02-25 13:57:07.727847	admin	f	\N	\N	\N
W46Jai	W46Jai@example.com	John	Doe	\N	2026-02-27 10:13:20.597795	2026-02-27 10:13:20.597795	user	f	\N	\N	\N
admin-test-user-2	admin2@test.com	Admin	Tester 2	\N	2026-03-03 06:24:34.285851	2026-03-03 06:24:34.285851	user	f	\N	\N	\N
oU-UWK	oU-UWK@example.com	Test	User	\N	2026-02-27 14:59:28.545386	2026-02-27 14:59:28.545386	user	f	\N	\N	\N
a_rJjy	a_rJjy@example.com	John	Doe	\N	2026-02-27 15:04:53.479382	2026-02-27 15:04:53.479382	user	f	\N	\N	\N
Wc93iB	Wc93iB@example.com	John	Doe	\N	2026-02-28 05:35:03.644812	2026-02-28 05:35:03.644812	user	f	\N	\N	\N
8wB_v6	8wB_v6@example.com	Replit	User	\N	2026-02-28 05:52:26.166151	2026-02-28 05:52:26.166151	user	f	\N	\N	\N
6WfO6B	6WfO6B@example.com	Test	User	\N	2026-02-28 06:35:39.174971	2026-02-28 06:35:39.174971	user	f	\N	\N	\N
admin_SyQ1	admin_SyQ1@example.com	Admin	User	\N	2026-02-28 06:36:05.737368	2026-02-28 06:37:22.571	admin	f	\N	\N	\N
z5Axnh	z5Axnh@example.com	Test	User	\N	2026-02-28 07:13:15.459444	2026-02-28 07:13:15.459444	admin	f	\N	\N	\N
eiM0S2	eiM0S2@example.com	John	Doe	\N	2026-02-28 18:41:54.547348	2026-02-28 18:41:54.547348	user	f	\N	\N	\N
xVhSzI	xVhSzI@example.com	John	Doe	\N	2026-02-28 18:48:20.789927	2026-02-28 18:48:20.789927	user	f	\N	\N	\N
aZw-6w	aZw-6w@example.com	John	Doe	\N	2026-02-28 18:58:17.670579	2026-02-28 18:58:17.670579	user	f	\N	\N	\N
1udX-Q	1udX-Q@example.com	John	Doe	\N	2026-02-28 19:18:50.483388	2026-02-28 19:18:50.483388	user	f	\N	\N	\N
BQ7kP2	BQ7kP2@example.com	John	Doe	\N	2026-02-28 20:47:37.65636	2026-02-28 20:47:37.65636	user	f	\N	\N	\N
z5AXX1	z5AXX1@example.com	John	Doe	\N	2026-02-28 21:32:07.074582	2026-02-28 21:32:07.074582	user	f	\N	\N	\N
test-user-999	test-user-999@example.com	TestUser	Runner	\N	2026-02-28 21:33:25.136694	2026-02-28 21:33:25.136694	user	f	\N	\N	\N
test-sweep-001	test-sweep-001@example.com	Sweep	Tester	\N	2026-02-28 21:42:14.943181	2026-02-28 21:42:14.943181	user	f	\N	\N	\N
test-fix-007	test-fix-007@example.com	FixTest	Runner	\N	2026-02-28 22:07:56.339705	2026-02-28 22:07:56.339705	user	f	\N	\N	\N
test-user-123	test@example.com	Test	User		2026-02-23 04:00:45.562398	2026-02-27 05:49:28.722	user	f	\N	\N	\N
admin-check-001	admin-check-001@example.com	AdminCheck	User	\N	2026-02-28 22:28:27.902416	2026-02-28 22:28:27.902416	admin	f	\N	\N	\N
test-buttons-001	test-buttons-001@example.com	ButtonTest	User	\N	2026-02-28 22:31:05.997579	2026-02-28 22:31:05.997579	user	f	\N	\N	\N
test-blend-001	\N	BlendTest	User	\N	2026-02-28 23:20:12.246513	2026-02-28 23:20:12.246513	user	f	\N	\N	\N
brand-new-user-999	newuser@example.com	New	User	\N	2026-02-27 06:18:24.867126	2026-02-27 06:18:24.867126	user	f	\N	\N	\N
admin-test-user-typing	typing@test.com	\N	\N	\N	2026-03-03 06:27:18.453867	2026-03-03 06:28:09.868	admin	f	\N	\N	\N
kWBQ4S	kWBQ4S@example.com	John	Doe	\N	2026-03-01 06:48:52.348731	2026-03-01 06:48:52.348731	user	f	\N	\N	\N
RqfxU0	RqfxU0@example.com	John	Doe	\N	2026-03-01 07:12:56.165646	2026-03-01 07:12:56.165646	user	f	\N	\N	\N
WJNhpw	WJNhpw@example.com	John	Doe	\N	2026-03-01 17:41:25.144257	2026-03-01 17:41:25.144257	user	f	\N	\N	\N
35323958	4980005@gmail.com	Pete	Rej	\N	2026-02-23 04:10:00.491791	2026-03-05 00:17:41.175	super_admin	f	\N	\N	\N
UyErpn	UyErpn@example.com	John	Doe	\N	2026-03-05 01:31:07.132663	2026-03-05 01:31:07.132663	user	f	\N	\N	\N
-GHxm6	-GHxm6@example.com	Test	User	\N	2026-03-01 20:15:20.748319	2026-03-01 20:15:20.748319	user	f	\N	\N	\N
f0PZaY	f0PZaY@example.com	John	Doe	\N	2026-03-01 22:09:04.890676	2026-03-01 22:09:04.890676	user	f	\N	\N	\N
39646895	admin@mindprism.com	Admin	Boss	\N	2026-02-27 06:14:50.736943	2026-02-27 07:20:48.605	admin	f	\N	\N	\N
test-user-42	maya@example.com	Maya	Johnson		2026-02-27 06:07:14.226526	2026-02-27 07:23:25.281	user	f	\N	\N	\N
Z1JoTp	Z1JoTp@example.com	John	Doe	\N	2026-02-27 08:09:15.483826	2026-02-27 08:09:15.483826	user	f	\N	\N	\N
tcBg5V	tcBg5V@example.com	John	Doe	\N	2026-02-27 08:11:49.341845	2026-02-27 08:11:49.341845	user	f	\N	\N	\N
X5bqd-	X5bqd-@example.com	John	Doe	\N	2026-02-27 08:20:00.100527	2026-02-27 08:20:00.100527	user	f	\N	\N	\N
b5yZvL	b5yZvL@example.com	John	Doe	\N	2026-02-27 08:26:00.624376	2026-02-27 08:26:00.624376	user	f	\N	\N	\N
yuVB4U	yuVB4U@example.com	John	Doe	\N	2026-02-27 08:39:08.956641	2026-02-27 08:39:08.956641	user	f	\N	\N	\N
E4d0vZ	E4d0vZ@example.com	John	Doe	\N	2026-03-01 22:29:03.581793	2026-03-01 22:29:03.581793	user	f	\N	\N	\N
C9d4Mb	C9d4Mb@example.com	Admin	User	\N	2026-03-01 22:37:09.952086	2026-03-01 22:37:09.952086	admin	f	\N	\N	\N
G35IpT	G35IpT@example.com	John	Doe	\N	2026-03-01 23:03:58.919496	2026-03-01 23:03:58.919496	user	f	\N	\N	\N
nEiu_1	nEiu_1@example.com	John	Doe	\N	2026-03-01 23:07:48.012481	2026-03-01 23:07:48.012481	admin	f	\N	\N	\N
t_XhuL	t_XhuL@example.com	John	Doe	\N	2026-03-01 23:51:40.871081	2026-03-01 23:51:40.871081	user	f	\N	\N	\N
VouA0h	VouA0h@example.com	John	Doe	\N	2026-03-01 23:54:26.032366	2026-03-01 23:54:26.032366	user	f	\N	\N	\N
hE9ikf	hE9ikf@example.com	John	Doe	\N	2026-03-02 00:12:43.737462	2026-03-02 00:12:43.737462	user	f	\N	\N	\N
72Nckd	72Nckd@example.com	John	Doe	\N	2026-03-02 00:44:25.431759	2026-03-02 00:44:25.431759	user	f	\N	\N	\N
bugfix-test-1772413553541	bugtest1772413553541@test.com	\N	\N	\N	2026-03-02 01:06:15.472126	2026-03-02 01:06:15.472126	user	f	\N	\N	\N
1l02Ad	1l02Ad@example.com	John	Doe	\N	2026-03-05 01:35:16.544975	2026-03-05 01:35:16.544975	user	f	\N	\N	\N
e2e-test-1772698062436	e2e-1772698062436@test.com	\N	\N	\N	2026-03-05 08:08:03.32725	2026-03-05 08:08:03.32725	user	f	\N	\N	\N
\.


--
-- Name: analytics_events analytics_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_events
    ADD CONSTRAINT analytics_events_pkey PRIMARY KEY (id);


--
-- Name: book_versions book_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_versions
    ADD CONSTRAINT book_versions_pkey PRIMARY KEY (id);


--
-- Name: books books_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT books_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: categories categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_slug_unique UNIQUE (slug);


--
-- Name: chakra_progress chakra_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chakra_progress
    ADD CONSTRAINT chakra_progress_pkey PRIMARY KEY (id);


--
-- Name: chapter_summaries chapter_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chapter_summaries
    ADD CONSTRAINT chapter_summaries_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: daily_sparks daily_sparks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_sparks
    ADD CONSTRAINT daily_sparks_pkey PRIMARY KEY (id);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: mental_models mental_models_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mental_models
    ADD CONSTRAINT mental_models_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_key UNIQUE (user_id);


--
-- Name: quiz_results quiz_results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_results
    ADD CONSTRAINT quiz_results_pkey PRIMARY KEY (id);


--
-- Name: saved_highlights saved_highlights_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saved_highlights
    ADD CONSTRAINT saved_highlights_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (sid);


--
-- Name: short_views short_views_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.short_views
    ADD CONSTRAINT short_views_pkey PRIMARY KEY (id);


--
-- Name: shorts shorts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shorts
    ADD CONSTRAINT shorts_pkey PRIMARY KEY (id);


--
-- Name: user_activity_log user_activity_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity_log
    ADD CONSTRAINT user_activity_log_pkey PRIMARY KEY (id);


--
-- Name: user_interests user_interests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_interests
    ADD CONSTRAINT user_interests_pkey PRIMARY KEY (id);


--
-- Name: user_progress user_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_progress
    ADD CONSTRAINT user_progress_pkey PRIMARY KEY (id);


--
-- Name: user_streaks user_streaks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_streaks
    ADD CONSTRAINT user_streaks_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_stripe_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_stripe_customer_id_key UNIQUE (stripe_customer_id);


--
-- Name: users users_stripe_subscription_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_stripe_subscription_id_key UNIQUE (stripe_subscription_id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_session_expire" ON public.sessions USING btree (expire);


--
-- Name: analytics_events_type_created_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_events_type_created_idx ON public.analytics_events USING btree (event_type, created_at);


--
-- Name: books_status_category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX books_status_category_idx ON public.books USING btree (status, category_id);


--
-- Name: idx_activity_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_activity_created_at ON public.user_activity_log USING btree (created_at);


--
-- Name: idx_activity_event_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_activity_event_type ON public.user_activity_log USING btree (event_type);


--
-- Name: idx_activity_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_activity_user_id ON public.user_activity_log USING btree (user_id);


--
-- Name: idx_analytics_events_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_events_created ON public.analytics_events USING btree (created_at);


--
-- Name: idx_analytics_events_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_events_type ON public.analytics_events USING btree (event_type);


--
-- Name: idx_analytics_events_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_events_user ON public.analytics_events USING btree (user_id);


--
-- Name: idx_quiz_user_book; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quiz_user_book ON public.quiz_results USING btree (user_id, book_id);


--
-- Name: journal_entries_user_created_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX journal_entries_user_created_idx ON public.journal_entries USING btree (user_id, created_at);


--
-- Name: user_activity_log_user_created_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_activity_log_user_created_idx ON public.user_activity_log USING btree (user_id, created_at);


--
-- Name: user_progress_user_book_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_progress_user_book_idx ON public.user_progress USING btree (user_id, book_id);


--
-- Name: analytics_events analytics_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_events
    ADD CONSTRAINT analytics_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: book_versions book_versions_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_versions
    ADD CONSTRAINT book_versions_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.books(id) ON DELETE CASCADE;


--
-- Name: books books_category_id_categories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT books_category_id_categories_id_fk FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: chakra_progress chakra_progress_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chakra_progress
    ADD CONSTRAINT chakra_progress_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: chapter_summaries chapter_summaries_book_id_books_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chapter_summaries
    ADD CONSTRAINT chapter_summaries_book_id_books_id_fk FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: comments comments_book_id_books_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_book_id_books_id_fk FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: comments comments_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: daily_sparks daily_sparks_book_id_books_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_sparks
    ADD CONSTRAINT daily_sparks_book_id_books_id_fk FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: journal_entries journal_entries_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: mental_models mental_models_book_id_books_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mental_models
    ADD CONSTRAINT mental_models_book_id_books_id_fk FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: notification_preferences notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: quiz_results quiz_results_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_results
    ADD CONSTRAINT quiz_results_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.books(id) ON DELETE CASCADE;


--
-- Name: quiz_results quiz_results_chapter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_results
    ADD CONSTRAINT quiz_results_chapter_id_fkey FOREIGN KEY (chapter_id) REFERENCES public.chapter_summaries(id) ON DELETE CASCADE;


--
-- Name: saved_highlights saved_highlights_book_id_books_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saved_highlights
    ADD CONSTRAINT saved_highlights_book_id_books_id_fk FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: saved_highlights saved_highlights_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saved_highlights
    ADD CONSTRAINT saved_highlights_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: short_views short_views_short_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.short_views
    ADD CONSTRAINT short_views_short_id_fkey FOREIGN KEY (short_id) REFERENCES public.shorts(id);


--
-- Name: shorts shorts_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shorts
    ADD CONSTRAINT shorts_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: user_activity_log user_activity_log_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity_log
    ADD CONSTRAINT user_activity_log_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: user_activity_log user_activity_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity_log
    ADD CONSTRAINT user_activity_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_interests user_interests_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_interests
    ADD CONSTRAINT user_interests_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_progress user_progress_book_id_books_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_progress
    ADD CONSTRAINT user_progress_book_id_books_id_fk FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: user_progress user_progress_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_progress
    ADD CONSTRAINT user_progress_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_streaks user_streaks_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_streaks
    ADD CONSTRAINT user_streaks_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: journal_entries journal_admin_access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY journal_admin_access ON public.journal_entries USING ((current_setting('app.current_user_role'::text, true) = ANY (ARRAY['admin'::text, 'super_admin'::text])));


--
-- Name: journal_entries; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.journal_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: journal_entries journal_owner_access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY journal_owner_access ON public.journal_entries USING (((user_id)::text = current_setting('app.current_user_id'::text, true))) WITH CHECK (((user_id)::text = current_setting('app.current_user_id'::text, true)));


--
-- PostgreSQL database dump complete
--

\unrestrict xhgTuNBnV8pvwT6blBagkeJQra7BQSe06zOLkxm5M8RbaYmHwGRCjjdnY5EBChe

