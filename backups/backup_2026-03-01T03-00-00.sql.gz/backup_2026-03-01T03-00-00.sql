--
-- PostgreSQL database dump
--

\restrict 2q32IbP2XdQfQwqBzV6PdMu2wXGVHVjVc5BOFLqdNRdaIf2pUXPEP4dE85vcikJ

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: action_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.action_items (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    book_id character varying NOT NULL,
    text text NOT NULL,
    type text NOT NULL,
    order_index integer NOT NULL,
    powers_up_chakra text
);


ALTER TABLE public.action_items OWNER TO postgres;

--
-- Name: analytics_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_events (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    event_type text NOT NULL,
    event_data jsonb,
    page_url text,
    session_id text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.analytics_events OWNER TO postgres;

--
-- Name: book_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.book_versions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    book_id character varying NOT NULL,
    version_type character varying DEFAULT 'draft'::character varying NOT NULL,
    content jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    created_by character varying,
    published_at timestamp without time zone
);


ALTER TABLE public.book_versions OWNER TO postgres;

--
-- Name: books; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.books (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    author text NOT NULL,
    cover_image text,
    description text NOT NULL,
    category_id character varying,
    read_time integer NOT NULL,
    listen_time integer NOT NULL,
    audio_url text,
    featured boolean DEFAULT false,
    principle_count integer DEFAULT 0,
    story_count integer DEFAULT 0,
    exercise_count integer DEFAULT 0,
    core_thesis text,
    status text DEFAULT 'draft'::text,
    updated_at timestamp without time zone DEFAULT now(),
    primary_chakra text,
    secondary_chakra text,
    current_draft_version_id character varying,
    current_published_version_id character varying,
    affiliate_url character varying(500),
    audio_duration integer,
    premium_only boolean DEFAULT false,
    free_preview_cards integer DEFAULT 5
);


ALTER TABLE public.books OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    icon text NOT NULL,
    color text NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: chakra_progress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chakra_progress (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    chakra text NOT NULL,
    points integer DEFAULT 0,
    exercises_completed integer DEFAULT 0,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.chakra_progress OWNER TO postgres;

--
-- Name: chapter_summaries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chapter_summaries (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    book_id character varying NOT NULL,
    chapter_number integer NOT NULL,
    chapter_title text NOT NULL,
    cards jsonb NOT NULL
);


ALTER TABLE public.chapter_summaries OWNER TO postgres;

--
-- Name: comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    book_id character varying NOT NULL,
    block_type text NOT NULL,
    block_id text NOT NULL,
    user_id character varying NOT NULL,
    content text NOT NULL,
    resolved boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.comments OWNER TO postgres;

--
-- Name: common_mistakes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.common_mistakes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    book_id character varying NOT NULL,
    mistake text NOT NULL,
    correction text NOT NULL,
    order_index integer NOT NULL
);


ALTER TABLE public.common_mistakes OWNER TO postgres;

--
-- Name: daily_sparks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.daily_sparks (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    quote text NOT NULL,
    author text NOT NULL,
    book_id character varying,
    category text
);


ALTER TABLE public.daily_sparks OWNER TO postgres;

--
-- Name: exercises; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exercises (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    book_id character varying NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    type text NOT NULL,
    content jsonb NOT NULL,
    order_index integer NOT NULL,
    impact text DEFAULT 'medium'::text,
    powers_up_chakra text
);


ALTER TABLE public.exercises OWNER TO postgres;

--
-- Name: flashcard_progress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flashcard_progress (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    book_id character varying NOT NULL,
    principle_id character varying NOT NULL,
    status character varying DEFAULT 'new'::character varying NOT NULL,
    next_review_date timestamp without time zone DEFAULT now(),
    ease_factor real DEFAULT 2.5,
    "interval" integer DEFAULT 0,
    repetitions integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.flashcard_progress OWNER TO postgres;

--
-- Name: infographics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.infographics (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    book_id character varying NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    image_url text,
    steps jsonb NOT NULL,
    order_index integer NOT NULL
);


ALTER TABLE public.infographics OWNER TO postgres;

--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.journal_entries (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    exercise_id character varying,
    content text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.journal_entries OWNER TO postgres;

--
-- Name: mental_models; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mental_models (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    book_id character varying NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    steps jsonb NOT NULL,
    order_index integer NOT NULL
);


ALTER TABLE public.mental_models OWNER TO postgres;

--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_preferences (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    daily_reminder boolean DEFAULT true,
    streak_alerts boolean DEFAULT true,
    new_content boolean DEFAULT true,
    weekly_summary boolean DEFAULT true,
    reminder_time text DEFAULT '09:00'::text,
    push_subscription jsonb,
    permission_status text DEFAULT 'default'::text,
    last_prompt_dismissed timestamp without time zone,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.notification_preferences OWNER TO postgres;

--
-- Name: principles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.principles (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    book_id character varying NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    order_index integer NOT NULL,
    icon text,
    visual_type text,
    visual_data jsonb
);


ALTER TABLE public.principles OWNER TO postgres;

--
-- Name: quiz_results; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quiz_results (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    book_id character varying NOT NULL,
    chapter_id character varying NOT NULL,
    score integer NOT NULL,
    total_questions integer NOT NULL,
    answers jsonb DEFAULT '[]'::jsonb,
    completed_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.quiz_results OWNER TO postgres;

--
-- Name: saved_highlights; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.saved_highlights (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    book_id character varying NOT NULL,
    principle_id character varying,
    content text NOT NULL,
    type text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.saved_highlights OWNER TO postgres;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    sid character varying NOT NULL,
    sess jsonb NOT NULL,
    expire timestamp without time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: short_views; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.short_views (
    id character varying(255) DEFAULT gen_random_uuid() NOT NULL,
    short_id character varying(255) NOT NULL,
    user_id text,
    viewed_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.short_views OWNER TO postgres;

--
-- Name: shorts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shorts (
    id character varying(255) DEFAULT gen_random_uuid() NOT NULL,
    book_id character varying(255) NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    media_type text NOT NULL,
    media_url text,
    thumbnail_url text,
    background_gradient text,
    duration integer,
    order_index integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.shorts OWNER TO postgres;

--
-- Name: stories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stories (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    book_id character varying NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    moral text,
    order_index integer NOT NULL,
    principle_id character varying
);


ALTER TABLE public.stories OWNER TO postgres;

--
-- Name: user_activity_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_activity_log (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    event_type text NOT NULL,
    event_data jsonb DEFAULT '{}'::jsonb,
    book_id character varying,
    session_duration integer,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_activity_log OWNER TO postgres;

--
-- Name: user_interests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_interests (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    interests text[] DEFAULT '{}'::text[],
    onboarding_completed boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_interests OWNER TO postgres;

--
-- Name: user_progress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_progress (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    book_id character varying NOT NULL,
    completed_principles text[] DEFAULT '{}'::text[],
    completed_exercises text[] DEFAULT '{}'::text[],
    bookmarked boolean DEFAULT false,
    last_accessed_at timestamp without time zone DEFAULT now(),
    current_card_index integer DEFAULT 0,
    total_cards integer DEFAULT 0,
    current_section text
);


ALTER TABLE public.user_progress OWNER TO postgres;

--
-- Name: user_streaks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_streaks (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    current_streak integer DEFAULT 0,
    longest_streak integer DEFAULT 0,
    last_active_date date,
    total_minutes_listened integer DEFAULT 0,
    total_exercises_completed integer DEFAULT 0,
    total_books_started integer DEFAULT 0,
    streak_freeze_available boolean DEFAULT true,
    last_freeze_used_at timestamp without time zone
);


ALTER TABLE public.user_streaks OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    email character varying,
    first_name character varying,
    last_name character varying,
    profile_image_url character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    role character varying DEFAULT 'user'::character varying,
    is_premium boolean DEFAULT false,
    stripe_customer_id character varying,
    stripe_subscription_id character varying,
    current_period_end timestamp without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: action_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.action_items (id, book_id, text, type, order_index, powers_up_chakra) FROM stdin;
7cf20a90-a318-4dc2-94ec-6aad42f623b8	2ea408e9-dc96-444c-a0dc-93901f9029b5	Write down 3 habits you want to build and reframe each as an identity statement (e.g., 'I am a writer')	immediate	1	\N
9cee2968-487a-4d6d-b015-aa1de6a8c0f6	2ea408e9-dc96-444c-a0dc-93901f9029b5	Pick one room and redesign it to make one good habit cue visible and one bad habit cue invisible	immediate	2	\N
976a104c-dbd7-4e0f-8925-5dde45005c88	2ea408e9-dc96-444c-a0dc-93901f9029b5	Create a Two-Minute version of a habit you've been procrastinating on and do it right now	immediate	3	\N
73bad765-c80b-4859-9462-8299a75615ea	2ea408e9-dc96-444c-a0dc-93901f9029b5	Track one keystone habit daily for 30 days using a habit tracker (paper or app)	long_term	4	\N
b45d644b-af79-4952-95b0-e1fa64af4567	2ea408e9-dc96-444c-a0dc-93901f9029b5	Conduct a monthly Habit Scorecard review: rate all habits and identify one to add and one to remove	long_term	5	\N
f7e07cf9-2012-4294-ac48-681d3c1d0a87	2ea408e9-dc96-444c-a0dc-93901f9029b5	Build a habit stack of 3 connected morning routines and practice for 60 days	long_term	6	\N
b09fdb12-f235-4446-ad39-21fba97f332e	7ba8d165-4195-43a3-9079-518dd4332439	Before your next big decision, write down 3 assumptions your gut is making and fact-check each one	immediate	1	\N
dd8c844c-c7e7-4e31-991e-7d7fba3299d9	7ba8d165-4195-43a3-9079-518dd4332439	In your next negotiation, research your number independently before hearing any anchors	immediate	2	\N
0f883ba6-5284-48d4-a26e-de23978b36e6	7ba8d165-4195-43a3-9079-518dd4332439	Keep a Decision Journal: log every major decision, your reasoning, and review outcomes monthly	long_term	3	\N
de32d542-9229-41dd-9d79-2d911ef0cacb	7ba8d165-4195-43a3-9079-518dd4332439	Practice the 'pre-mortem' technique before starting any new project: imagine it failed and list why	long_term	4	\N
f15c2485-076f-470e-948e-d2084d9867b1	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	Right now, take 3 conscious breaths and feel the sensation of air entering your body	immediate	1	\N
70abda19-9f27-4266-9e33-673654b09270	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	Choose one daily activity (washing dishes, walking) and do it with 100% attention today	immediate	2	\N
a10c30f9-84c3-48cd-8144-818f5a476b44	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	Practice 5 minutes of 'watching the thinker' meditation every morning for 30 days	long_term	3	\N
9ca9cc61-01d0-4f4d-8fbf-c127a6155a1b	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	Set 3 random daily alarms labeled 'Am I present?' as mindfulness triggers for 60 days	long_term	4	\N
d9085ae8-1e12-47b6-8a63-e91042e0fa10	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	Name your current emotion right now. Say it out loud: 'I am feeling ___.'	immediate	1	\N
48554977-acdc-4bf4-a322-bbbeaaeac6b8	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	In your next difficult conversation, pause for 6 seconds before responding (one full breath cycle)	immediate	2	\N
da38473f-cbe8-426c-82a8-a3036780d9b4	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	Keep an Emotion Log for 30 days: 3 check-ins per day noting emotion, trigger, and behavior	long_term	3	\N
29ea032f-fc87-4271-af2d-6b0e6bd11e22	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	Practice active listening in one conversation daily: reflect back what you heard before responding	long_term	4	\N
ffaac735-3117-489c-a71d-98ba73ef4212	23f2345b-6336-4573-a63f-8ee2cd34f56b	Write down one thing that gives your life meaning right now. Put it where you'll see it daily.	immediate	1	\N
d29c7629-6ec7-46c5-b0c6-b5328da676ee	23f2345b-6336-4573-a63f-8ee2cd34f56b	Think of a current struggle. Write down what lesson or growth it could be teaching you.	immediate	2	\N
84122276-02b0-431b-b049-8e48878851c4	23f2345b-6336-4573-a63f-8ee2cd34f56b	Create a personal mission statement using Frankl's three sources of meaning. Revisit it monthly.	long_term	3	\N
bbe48849-209e-4a6a-8cee-8edad3edf962	23f2345b-6336-4573-a63f-8ee2cd34f56b	Practice 'attitudinal values' by reframing one difficult situation each week as an opportunity for growth	long_term	4	\N
\.


--
-- Data for Name: analytics_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_events (id, user_id, event_type, event_data, page_url, session_id, created_at) FROM stdin;
70f9f7d7-ca77-4a8a-85c5-44d08c3d78b9	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:41:06.392327
06752810-4977-4c7b-80e0-f5dba9f6a858	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:42:22.579967
b404f3dc-d669-4c02-aa8c-dd0c0cb4397b	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 07:42:41.810171
560f4079-6cc8-44c7-811b-4df5560f9947	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:43:12.317289
8de07567-7d68-4207-945d-57ddccb7a607	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 07:43:12.521827
ec18ae74-21f9-46c2-8bd0-90f97fa65f75	35323958	book_open	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:43:41.159681
aabbd13e-2577-46ea-a807-0a5ae450887b	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:44:20.99742
94f58e26-c6cd-4351-8d0b-c0326511cfe7	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 07:44:24.541261
c4371ed6-a3d5-4c8f-ac7b-15d2954a6b11	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:44:39.106635
0d3d65ee-fbdd-45e7-8b98-af2c2e4c701b	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 07:44:41.538173
cfb4fae5-98e4-4393-bdcc-07e8e6d7cb54	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:45:30.643355
af6f9714-f6d3-4ed6-9a0c-05c39b361537	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 07:45:33.083122
ce8be361-156b-43d7-bfc6-06507adb06d9	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:46:03.620007
90828a60-7fad-4199-9f7d-9c1af4ef4eb0	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 07:46:06.035016
a088e670-13da-4a57-8dc6-4822f4589d4f	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:56:57.149494
ee409fef-f031-4229-8e60-75bf8e7b2df8	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 07:56:59.583336
e75713b6-cc3f-4cdf-8b5e-e445644af7fa	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:58:43.08821
54194324-bc86-453b-85d8-20d60a2afb89	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 07:58:43.252223
5dc5db6f-ad31-4bf8-ac9e-be6e24d0c23c	35323958	chapter_start	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "section": "chapter-summaries", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439/journey	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:58:43.994548
c49d0b99-42e7-40d7-bcf4-b9560b4fee87	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:59:10.925702
f761441d-4d06-4158-bf20-fa6a0e9e6bee	35323958	chapter_start	{"bookId": "23f2345b-6336-4573-a63f-8ee2cd34f56b", "section": "chapter-summaries", "bookTitle": "Man's Search for Meaning"}	/book/23f2345b-6336-4573-a63f-8ee2cd34f56b/journey	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:59:29.58264
9dcb0a21-4031-4d55-b18f-48478a1420e3	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 07:59:52.795156
d0282230-b26b-42eb-b21d-c3f67f9c4d85	35323958	chapter_start	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "section": "chapter-summaries", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439/journey	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:00:18.246023
4a5e49ae-2a0d-46f5-b66c-621aee2eede4	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:00:44.10917
ed57e832-cb28-4e87-9147-95ca1000ca7d	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:03:13.670581
a444781b-8368-4656-875b-15e302404fd1	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:03:15.883739
0342fdff-b6cb-4703-a0ec-aa8d2cd74b1d	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:04:13.449423
49f68fc3-0fd4-439e-8689-4b6aa9eb0c9e	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:04:14.38075
3796d484-dd2e-4a1e-bd72-b6df96a85415	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:04:35.080833
bd5e5e85-2ebb-48e2-adb4-887a7d33bd4a	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:04:37.368236
8b543e7a-54ec-453b-8e97-a5cf88475660	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:07:11.660188
ce3ff47b-e605-40bd-bc39-b5f63e011830	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:07:11.761284
ea245a79-faec-4ce7-a706-7a9a9dbac7ed	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:07:42.834289
8205157a-27bd-4aad-9c42-840774d40d2f	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:07:45.055886
031b6967-29c0-480b-808e-a41d5e2db159	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:08:47.164221
044f7ef0-af73-413f-9e47-6edf36c8879a	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:08:47.239844
78d64685-62c8-4f14-97eb-af56e0ee2e50	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:09:11.312069
79c97e45-184e-4170-b084-f162e00eaf7d	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:09:11.416175
35e0f7ad-c6b1-4376-bac7-56b233d77d31	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:10:23.791962
de8feb20-d70c-41c8-a17d-9adaae87b8c1	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:10:23.87505
6aeabf05-d956-4d88-af12-309c655db2ce	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:11:02.125329
a614a61b-77f0-4936-92e9-6e6de398f4cb	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:11:02.211704
adaa8431-2c32-47d7-b194-0e708f68c641	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:11:26.625762
2e7c38a1-345d-4b13-887e-cffe7ea997f7	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:11:29.301005
921d0938-2220-4586-8e1b-576c029cb9c8	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:11:43.46326
96417508-3067-46a8-b526-2bc41b7c72a7	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:11:45.974021
6d2e45d0-f3c5-4a46-b402-65dfe4decfb7	tcBg5V	page_view	{"page": "dashboard"}	/	1ed47247-73db-4d06-a81e-e45739589517	2026-02-27 08:12:46.088754
d3733772-06c5-4db2-990a-cc80ca905dae	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:13:22.403964
a47bd6bc-4d32-47bb-8ce2-6578315ab37b	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:13:24.586208
775657f8-b6dc-41af-bcc3-dfbbd1116273	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:16:53.068798
dd8d928e-61a0-4106-80c3-dc11da8775a8	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:16:53.256698
fa24730d-de59-4c24-93fc-f505db742af3	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:18:54.094285
a4791fdd-9942-4bcc-be12-b0f31d01294d	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:18:54.181647
5a56a6fe-7829-4ca8-af83-f1f533c78afa	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:19:01.404561
d39eb9ff-cdf8-4b19-b857-e0f5cbb41a14	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:19:01.418594
9a43c539-3808-4955-8175-a079227f79bc	X5bqd-	page_view	{"page": "dashboard"}	/	8b4284d6-d73b-48b5-9622-83b741149e34	2026-02-27 08:21:33.364368
65360e24-7dc8-45a2-9e17-23f5d415cd4a	b5yZvL	page_view	{"page": "dashboard"}	/	e5060fe9-ca1e-4e67-8152-aa2d55db40ca	2026-02-27 08:27:29.530946
ae95a38c-c110-4fc9-93ca-7483957720f5	35323958	page_view	{"page": "dashboard"}	/	c82e46fb-4539-418a-b143-145d8d48d526	2026-02-27 08:31:36.612882
15afe06d-56e2-481a-a3de-131041583758	35323958	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	c82e46fb-4539-418a-b143-145d8d48d526	2026-02-27 08:33:06.705566
c217529c-dda4-43f8-9630-f9cfdbd0e5af	35323958	chapter_start	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "section": "chapter-summaries", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5/journey	c82e46fb-4539-418a-b143-145d8d48d526	2026-02-27 08:33:10.343056
0bc6ec5c-806f-498b-89d3-10b40155c9ac	35323958	chapter_complete	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "section": "chapter-summaries", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5/journey	c82e46fb-4539-418a-b143-145d8d48d526	2026-02-27 08:33:18.28538
5f387fe9-ee0a-42f6-bf31-39987d9dd438	35323958	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	c82e46fb-4539-418a-b143-145d8d48d526	2026-02-27 08:33:18.514551
37c56526-0a03-4262-8a58-51be26634a78	35323958	page_view	{"page": "dashboard"}	/	c82e46fb-4539-418a-b143-145d8d48d526	2026-02-27 08:33:28.590301
43c857f1-3aad-4860-a2cd-d635a8d6829d	yuVB4U	page_view	{"page": "dashboard"}	/	3799f0cd-d6b4-4aa5-b126-63148af5d4a9	2026-02-27 08:39:19.706785
dfb7316b-8bdd-4807-a0f6-be45b0cd4273	yuVB4U	page_view	{"page": "dashboard"}	/	3799f0cd-d6b4-4aa5-b126-63148af5d4a9	2026-02-27 08:40:52.153356
834bd4d9-daaa-4ae0-a71d-02b8cd7fff8a	35323958	page_view	{"page": "dashboard"}	/	c82e46fb-4539-418a-b143-145d8d48d526	2026-02-27 08:43:24.5094
6ea9a2ab-08ae-4a68-b789-fb71b58d0614	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:48:42.225824
6a0b7e3d-9bf5-4b95-bee1-6ad4ae7dc960	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:48:42.4225
e3591433-f4ae-470c-bb9e-3429adaad496	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:50:08.45621
51a5b45c-fc78-4d6c-8d83-5aa70ad48e8c	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:50:08.744723
320db071-fee4-43aa-9d9d-8f8125c02e63	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:57:36.985523
0ff57d52-f32e-46ae-bebb-613b2a1c368c	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:57:37.183674
69251f47-e268-4197-977b-3c260516d9ce	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 08:59:02.141492
3c15d9a6-30b9-4571-9b17-6648bc1d79cb	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 08:59:02.379983
53bdfa61-de2f-4c82-810e-7699ef2081e1	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:01:40.122245
29208e5b-0929-435d-b0cb-01200b110072	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:01:40.218321
bc201e55-d685-4b87-a59b-a8eda80920ff	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:02:03.210422
617a5a45-3e5b-4323-879f-d79f388a387f	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:02:04.196016
8bb27461-1bc8-412b-b4ec-9389d444e8d5	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:02:38.757079
fe713763-137b-4551-8292-eb4646ea2ca6	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:02:39.039292
02042c5c-ec53-4200-a705-bcaa7ab91840	a8S2dP	page_view	{"page": "dashboard"}	/	0cce12a1-ccb1-4d24-8098-6bb258f10208	2026-02-27 09:03:06.550302
df64eb78-6017-45a2-a080-8f9067890f39	a8S2dP	page_view	{"page": "dashboard"}	/	0cce12a1-ccb1-4d24-8098-6bb258f10208	2026-02-27 09:04:19.792029
6ef67d72-7765-4005-8a56-4c5d9086ea29	a8S2dP	page_view	{"page": "dashboard"}	/	0cce12a1-ccb1-4d24-8098-6bb258f10208	2026-02-27 09:05:49.648883
3f1cb9a7-5c50-43c8-971b-7c037201d37c	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:07:42.436446
6d80cfbe-fa6c-4c8f-8149-6e5a7cd4b812	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:07:42.7336
860b3b5b-89c5-4376-a276-a0dbfae1a172	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:08:10.707669
5d9dc02b-ff1d-4f0e-a8f5-7e09441e36a4	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:08:10.925574
bf9a6588-ced0-4611-aef8-bfced50954d6	j69UEF	page_view	{"page": "dashboard"}	/	5ace6759-258c-4027-b010-f348785edc0d	2026-02-27 09:08:43.33804
6a75e0c4-e8fc-4d59-a6c9-e1433f0dbcf6	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:09:48.527465
ea150809-1513-4baa-9a19-91b17fff2828	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:09:48.697854
cbc5e47e-a12e-4660-accb-b0f6beed7d11	35323958	page_view	{"page": "dashboard"}	/	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 09:11:47.066709
3412b2a4-bff9-46c4-af69-3df43fd39827	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:12:14.664032
b02692c4-abb1-4609-8ba4-d404754c83b1	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:12:14.832978
03d46727-c9ef-4e3c-b4d0-549c5d01ad93	35323958	page_view	{"page": "dashboard"}	/	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 09:12:15.983272
bbf4116b-c03c-4e24-93e2-faa5ab849237	pIDdI2	page_view	{"page": "dashboard"}	/	c4fd2665-7e28-4db0-981f-a94564b04fc3	2026-02-27 09:12:33.761176
47f880d7-b2d1-4347-bcc8-6b89390f7e2d	pIDdI2	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	c4fd2665-7e28-4db0-981f-a94564b04fc3	2026-02-27 09:14:22.676592
e1df3f1a-c395-4ee3-926d-14dda606dfb6	pIDdI2	chapter_start	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "section": "chapter-summaries", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439/journey	c4fd2665-7e28-4db0-981f-a94564b04fc3	2026-02-27 09:14:29.250923
0177bebd-ec9b-4d4d-b7e2-c53d48a20d92	pIDdI2	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	c4fd2665-7e28-4db0-981f-a94564b04fc3	2026-02-27 09:14:51.708783
ef250a57-2cd8-4bfd-b3f5-0799399d4559	pIDdI2	audio_play	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/audio	c4fd2665-7e28-4db0-981f-a94564b04fc3	2026-02-27 09:15:04.106997
be7399cf-aef4-4f1f-b4c2-fe903a6c60f1	pIDdI2	page_view	{"page": "dashboard"}	/	c4fd2665-7e28-4db0-981f-a94564b04fc3	2026-02-27 09:15:49.322834
45c509bb-a7e1-4366-b96d-2c8d79cf617f	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:16:03.81774
b17d621a-5f73-4525-a33b-97e6b3df1f42	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:16:03.920655
4e14e09b-e3fe-4b08-aab8-2e14133e2f3d	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:17:32.500522
f39dd130-d817-4cb6-b5eb-9bbe56669d3e	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:17:32.616623
07d24cd8-1be8-4b60-bc05-70a4ee6688c9	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:18:19.078281
279903f2-2443-43e7-94cf-c6c278b3cd69	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:18:19.293781
257c584d-b869-43f2-a91d-a7e2b85370b7	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:19:19.70072
463dc7b2-1548-4a56-a917-766c8e4a0f6e	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:19:19.976475
40d80efd-4f97-4010-96b0-bed10e83e8b5	Jkp87u	page_view	{"page": "dashboard"}	/	3a2f9692-4dc2-4f86-9f1b-d6580d9c9470	2026-02-27 09:19:40.059173
06adfc67-e4e2-48d1-b369-75a6d3518f0b	Jkp87u	book_open	{"bookId": "23f2345b-6336-4573-a63f-8ee2cd34f56b", "bookTitle": "Man's Search for Meaning"}	/book/23f2345b-6336-4573-a63f-8ee2cd34f56b	3a2f9692-4dc2-4f86-9f1b-d6580d9c9470	2026-02-27 09:20:28.370659
65635799-19e8-424d-bb61-f0bf4ced11c2	Jkp87u	page_view	{"page": "dashboard"}	/	3a2f9692-4dc2-4f86-9f1b-d6580d9c9470	2026-02-27 09:20:37.252691
5bbcf4b2-6d2b-4f2e-b27d-18a8c885bebf	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:20:52.270909
18dedc89-d22c-454b-a97c-d8a6fa067831	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:20:52.443101
084ead4f-2e0f-450f-b910-ec78f7f1b74b	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:27:20.935851
9c3bcc9d-d7ea-49b6-a201-374c94f47a65	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:27:21.133081
eb316769-6b9b-4f13-b810-48c2df21b38a	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:29:04.786607
86eb6eca-eee4-453c-a9e6-9d07c63c4354	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:29:04.853771
5d43a16e-fa2c-45ce-ad5b-ee33e05d56b8	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:29:19.169858
bc61e39f-dddf-4fde-9079-6bc7bd9cf60c	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:29:19.265842
d404673d-901b-4ca9-9a8a-7c0d6899ebcc	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:30:02.17785
e091c118-12ae-4fc0-bcc8-f74bf21a7f31	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:30:02.294906
ab32d4d1-f797-4981-8af5-5c624bd84a98	tImpmS	page_view	{"page": "dashboard"}	/	6ba12c03-67ac-44d5-a2f6-92bf6a64ddb0	2026-02-27 09:30:25.063723
881686aa-c9bc-452f-8147-765469811999	tImpmS	page_view	{"page": "dashboard"}	/	6ba12c03-67ac-44d5-a2f6-92bf6a64ddb0	2026-02-27 09:32:09.499295
267d6985-8c79-4e4a-966e-ceb9a1f4e17c	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:32:19.470531
2bc0a680-e763-47b7-9e9b-3b64df5cda2e	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:32:19.666075
a2e72204-9605-444f-a7d2-48622fae2505	35323958	page_view	{"page": "dashboard"}	/	3716ec24-bfbb-4a66-96b2-2fdcebb86fbe	2026-02-27 09:36:02.653761
244719f0-8a28-4229-95b0-213ccb31b2b3	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:46:49.598806
e5d23797-85e6-4325-a4cf-6bf2af6a6cdb	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:47:13.505538
c91f7093-4d2a-4cd0-a893-9479e0eb3e60	35323958	page_view	{"page": "dashboard"}	/	24d5aa3b-037d-4262-a78b-cc7d5f5311e4	2026-02-27 09:47:27.235708
089cf483-6ccb-4bbb-806a-c18295b6afce	35323958	page_view	{"page": "dashboard"}	/	24d5aa3b-037d-4262-a78b-cc7d5f5311e4	2026-02-27 09:47:41.870039
59d8f122-24f9-4335-9fa1-c2d62cb80099	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:47:42.063175
d65981f1-2c69-4265-8480-28ca8c66284e	9BmmO0	page_view	{"page": "dashboard"}	/	b36d3d8d-4517-456b-be28-2e2a7ef6a249	2026-02-27 09:48:27.188281
616fc4b5-ff72-4229-9bfc-57acab89e1d4	9BmmO0	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	b36d3d8d-4517-456b-be28-2e2a7ef6a249	2026-02-27 09:49:22.562921
9118c130-86fd-4a1e-9456-7074f9d95d8b	9BmmO0	page_view	{"page": "dashboard"}	/	b36d3d8d-4517-456b-be28-2e2a7ef6a249	2026-02-27 09:49:53.830245
603730c9-66b2-4b95-960e-ec44c176c51c	9BmmO0	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	b36d3d8d-4517-456b-be28-2e2a7ef6a249	2026-02-27 09:50:01.459302
727a7fca-5d2c-469d-8368-83d4de1c2088	9BmmO0	page_view	{"page": "dashboard"}	/	b36d3d8d-4517-456b-be28-2e2a7ef6a249	2026-02-27 09:52:01.796128
4e49172e-de96-4b6b-b847-b857168ee58a	35323958	page_view	{"page": "dashboard"}	/	24d5aa3b-037d-4262-a78b-cc7d5f5311e4	2026-02-27 09:52:27.723876
f993605c-059e-48ef-8453-1f8dfda0273d	35323958	page_view	{"page": "dashboard"}	/	3223ce83-58f8-4f3a-bb55-70f90b9f048a	2026-02-27 09:52:27.927294
4ce4b82f-f49c-47b1-8846-1aae3f5d45ad	35323958	page_view	{"page": "dashboard"}	/	24d5aa3b-037d-4262-a78b-cc7d5f5311e4	2026-02-27 09:53:02.060849
e32adfaf-ad6a-4bcb-9049-ea0c283b297b	35323958	page_view	{"page": "dashboard"}	/	24d5aa3b-037d-4262-a78b-cc7d5f5311e4	2026-02-27 09:53:36.915201
2f0a9950-53b4-46f8-83db-e2f28c05023e	35323958	page_view	{"page": "dashboard"}	/	24d5aa3b-037d-4262-a78b-cc7d5f5311e4	2026-02-27 09:53:44.965651
5a81da94-a667-442b-a718-3e04f04a959d	35323958	page_view	{"page": "dashboard"}	/	24d5aa3b-037d-4262-a78b-cc7d5f5311e4	2026-02-27 10:08:58.110449
77bbd2c5-40c4-4e81-8fdd-4f04ee8a2b07	W46Jai	page_view	{"page": "dashboard"}	/	22bfbcf7-4a90-4ad4-8c5c-b778c5a67b6a	2026-02-27 10:13:38.440773
6459b20a-7018-42eb-a47d-9b60293ebecd	W46Jai	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	22bfbcf7-4a90-4ad4-8c5c-b778c5a67b6a	2026-02-27 10:14:19.359637
ddb46f2b-17dd-4b3b-8dcc-eebd082ac380	W46Jai	page_view	{"page": "dashboard"}	/	22bfbcf7-4a90-4ad4-8c5c-b778c5a67b6a	2026-02-27 10:15:24.021848
9819338c-b730-4e94-9373-ab546b3de2d6	35323958	page_view	{"page": "dashboard"}	/	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:27:20.428189
25afa516-2000-4ca5-a615-3c13e4c52cfd	35323958	book_open	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:27:33.335848
b3129936-9e51-4f9f-8b19-a880313581e3	35323958	chapter_start	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "section": "chapter-summaries", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0/journey	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:27:40.59253
471883b1-173a-4411-a786-e652f3a35650	35323958	chapter_complete	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "section": "chapter-summaries", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0/journey	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:27:49.72481
40b31444-eec3-4469-ac05-8a19a18f15f5	35323958	book_open	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:27:50.484043
380bc5d7-c7fa-4269-9504-fd77658c3376	35323958	chapter_start	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "section": "infographics", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0/journey	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:27:56.913437
74c9b88b-9c28-447c-b077-b01772256975	35323958	book_open	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:28:19.105866
8838699b-3e69-4204-b3f8-3b02aced1ea2	35323958	page_view	{"page": "dashboard"}	/	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:30:39.533024
2aaff772-e28b-4018-9c70-75823f7cf33d	35323958	page_view	{"page": "dashboard"}	/	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:31:16.400712
8b960a9c-481a-439c-bf16-2c9520251639	35323958	chapter_start	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "section": "chapter-summaries", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0/journey	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:31:56.725914
7da31d93-91fa-450b-8400-80101bb54ad6	35323958	page_view	{"page": "dashboard"}	/	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:32:00.569114
e5ad72d4-c482-470d-808f-60e069db8b72	35323958	chapter_start	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "section": "chapter-summaries", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0/journey	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:32:04.764683
60c5d0c8-3b74-411c-940f-b6bef7cb7d95	35323958	book_open	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:32:07.602898
ed2808b1-0e97-44a8-aab6-c245aa270c03	35323958	page_view	{"page": "dashboard"}	/	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:52:48.187589
8f848d1d-4544-4706-8e40-20f5ea0503ba	35323958	book_open	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	07771d31-2af1-4ff6-a0eb-8a741fbfe759	2026-02-27 12:53:15.737829
450223f6-fd73-4341-a96b-dd107b0ec31e	oU-UWK	page_view	{"page": "dashboard"}	/	53dd4dc9-c27b-459f-acb2-70024b5ba79f	2026-02-27 14:59:41.238481
e32e7481-4899-4474-b90a-a7b1f187ea94	oU-UWK	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	53dd4dc9-c27b-459f-acb2-70024b5ba79f	2026-02-27 15:00:02.105701
2344957c-59b1-4389-802a-6c8171b58664	oU-UWK	page_view	{"page": "dashboard"}	/	53dd4dc9-c27b-459f-acb2-70024b5ba79f	2026-02-27 15:01:48.721989
e6c505c8-2988-42e7-b21f-57590804d9bb	oU-UWK	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	53dd4dc9-c27b-459f-acb2-70024b5ba79f	2026-02-27 15:02:16.85091
860c10f1-ec4d-45f9-aabb-32a956e08ed5	a_rJjy	page_view	{"page": "dashboard"}	/	db62ae2f-ef96-4a07-979f-657d81da9fdb	2026-02-27 15:05:16.314494
7ac37005-8798-43c3-9794-397e384453cb	a_rJjy	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	db62ae2f-ef96-4a07-979f-657d81da9fdb	2026-02-27 15:06:00.290945
3e34cff9-b4b6-4164-a8c3-3c9b037894c0	a_rJjy	page_view	{"page": "dashboard"}	/	db62ae2f-ef96-4a07-979f-657d81da9fdb	2026-02-27 15:07:16.0597
d743fa94-92a5-4f01-abe9-9c3a83c75d14	35323958	page_view	{"page": "dashboard"}	/	d0faed7d-3869-4830-a368-640b16311f60	2026-02-27 16:02:27.323121
fef98f19-b351-4167-a422-979e6f46a5c1	35323958	page_view	{"page": "dashboard"}	/	d0faed7d-3869-4830-a368-640b16311f60	2026-02-27 16:04:26.021528
9c044cdb-3aeb-4d76-a549-5fc201ce1a26	35323958	page_view	{"page": "dashboard"}	/	d0faed7d-3869-4830-a368-640b16311f60	2026-02-27 16:05:49.497168
7942b742-7bd6-4bca-b2bf-23f743950964	35323958	page_view	{"page": "dashboard"}	/	3475f3ec-77dd-41bd-8552-a25d88f76a38	2026-02-28 03:45:48.030261
e0ac9efa-e267-45b1-9013-b75ceaf67b0e	Wc93iB	page_view	{"page": "dashboard"}	/	d772043f-c4bb-433e-84ee-febca09bba48	2026-02-28 05:35:23.763859
e10b070f-e819-471b-9b16-a717c2925c9d	Wc93iB	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	d772043f-c4bb-433e-84ee-febca09bba48	2026-02-28 05:36:20.342212
cb99c446-0191-4ff4-9f40-703f30be13b8	Wc93iB	chapter_start	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "section": "infographics", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5/journey	d772043f-c4bb-433e-84ee-febca09bba48	2026-02-28 05:36:27.371789
cd290902-ba70-4f07-9b0b-269eb90233e2	Wc93iB	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	d772043f-c4bb-433e-84ee-febca09bba48	2026-02-28 05:36:37.47301
a610a186-597c-447c-b271-f23d09de0c1c	Wc93iB	page_view	{"page": "dashboard"}	/	d772043f-c4bb-433e-84ee-febca09bba48	2026-02-28 05:37:08.212996
e64b1ff2-7528-4e22-b4bf-1a89c0c4ad6e	Wc93iB	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	d772043f-c4bb-433e-84ee-febca09bba48	2026-02-28 05:37:22.93197
95566eee-db8c-490c-9a09-f69f38589050	8wB_v6	page_view	{"page": "dashboard"}	/	91366a41-655a-4194-9260-05d68eb8112c	2026-02-28 05:53:05.935902
c0d34dc9-c12c-4fad-b100-b8391bdd7e23	8wB_v6	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	91366a41-655a-4194-9260-05d68eb8112c	2026-02-28 05:53:41.975425
0253b5c2-fb2a-4bf2-8446-0e5bd5809fbf	8wB_v6	page_view	{"page": "dashboard"}	/	91366a41-655a-4194-9260-05d68eb8112c	2026-02-28 05:54:18.896993
8add6820-b4ac-446e-9312-acc5ce5c8a0b	8wB_v6	chapter_start	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "section": "chapter-summaries", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5/journey	91366a41-655a-4194-9260-05d68eb8112c	2026-02-28 05:54:32.326528
ab7fbec8-9350-4f75-8bfb-cf3694a7e6a8	8wB_v6	page_view	{"page": "dashboard"}	/	91366a41-655a-4194-9260-05d68eb8112c	2026-02-28 05:55:06.127552
75dbea49-a624-45a5-b701-24ba842f623a	35323958	page_view	{"page": "dashboard"}	/	71da6049-e282-46af-950a-db24a4a19433	2026-02-28 06:50:57.65809
438a3947-811f-4268-9fef-1590e6178fde	35323958	page_view	{"page": "dashboard"}	/	71da6049-e282-46af-950a-db24a4a19433	2026-02-28 06:51:28.008117
9a3a6785-7061-4b13-8ca7-91870c47e57a	35323958	page_view	{"page": "dashboard"}	/	71da6049-e282-46af-950a-db24a4a19433	2026-02-28 06:53:03.467353
f65605ac-f6e4-40c7-a26a-12fd6a8996c1	35323958	chapter_start	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "section": "chapter-summaries", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5/journey	71da6049-e282-46af-950a-db24a4a19433	2026-02-28 06:53:09.469059
656d57a0-d856-49a5-bff1-c4841197e511	35323958	page_view	{"page": "dashboard"}	/	71da6049-e282-46af-950a-db24a4a19433	2026-02-28 06:53:49.753092
418b82a4-6aea-4755-a6af-5a9c64316826	35323958	page_view	{"page": "dashboard"}	/	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:07:24.850867
12967e7f-5af6-458b-b5a2-b20c2db6bd95	35323958	page_view	{"page": "dashboard"}	/	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:07:26.783765
0a4411d2-eb47-4334-9980-33dd44ea4e1e	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:07:46.205233
b9fa58d7-9697-4bef-8eaf-8859135076a2	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:08:10.488583
292984cf-713e-4a22-989d-ed3956ce7c1c	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:10:29.07327
8948d7b0-6e3c-4271-b0c6-820642282b2a	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:10:57.564688
42685506-2e79-4a7c-b1e7-5a19019f821e	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:11:02.12432
e7dda05e-0acc-43f1-a8e6-d938767ea0fd	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:11:13.436267
7c7243a8-e7e8-4620-8b09-27ba6ed93b6d	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:11:18.08191
7bde153d-5ae6-45c2-bd57-e389e4ab3233	35323958	page_view	{"page": "dashboard"}	/	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:11:40.423207
a604fbd4-6d13-42d5-8837-539e0f22867f	35323958	page_view	{"page": "dashboard"}	/	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:12:17.451612
632799bd-d74e-48f1-a449-c8dc7dde6dea	35323958	page_view	{"page": "dashboard"}	/	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:12:57.748259
ccb43b4e-5863-4207-822b-6b684d66ea87	35323958	page_view	{"page": "dashboard"}	/	84d0ba6e-23e6-464e-bd40-b25bedb233e2	2026-02-28 07:13:09.958809
0fc09d30-3f32-47a7-8afa-2e36a4da5305	z5Axnh	page_view	{"page": "dashboard"}	/	d25dc01e-4b7d-41d5-a956-631c1e9b0e49	2026-02-28 07:13:30.415954
741c7c08-39e5-4f48-950b-bd14c5eda198	z5Axnh	page_view	{"page": "dashboard"}	/	d25dc01e-4b7d-41d5-a956-631c1e9b0e49	2026-02-28 07:14:23.954176
bf9ed1f9-24f9-40ce-a990-ae8814709a0a	z5Axnh	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	d25dc01e-4b7d-41d5-a956-631c1e9b0e49	2026-02-28 07:14:38.940195
8b8940d9-87db-4021-b795-db22f7968966	z5Axnh	page_view	{"page": "dashboard"}	/	d25dc01e-4b7d-41d5-a956-631c1e9b0e49	2026-02-28 07:15:22.032404
f380d06f-6cb0-4ee1-be02-1da35dca78ca	z5Axnh	page_view	{"page": "dashboard"}	/	d25dc01e-4b7d-41d5-a956-631c1e9b0e49	2026-02-28 07:16:04.80904
64f3a228-0ead-4c5c-a0fa-a7588131cea4	z5Axnh	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	d25dc01e-4b7d-41d5-a956-631c1e9b0e49	2026-02-28 07:16:18.833968
367b1337-262d-4eab-a7fd-3d7bc3d5daaf	35323958	page_view	{"page": "dashboard"}	/	a2e3000b-1a80-47d2-bccc-33649172593f	2026-02-28 07:22:31.045778
a10f5ffe-9372-4b86-a324-f67bbe45c004	35323958	chapter_start	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "section": "chapter-summaries", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5/journey	a2e3000b-1a80-47d2-bccc-33649172593f	2026-02-28 07:22:36.358475
278c4667-6424-4d65-b228-057d9c5a1d75	35323958	chapter_start	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "section": "chapter-summaries", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5/journey	a2e3000b-1a80-47d2-bccc-33649172593f	2026-02-28 07:22:53.539823
9da3b98f-c892-4505-9c38-76c37d50e72a	35323958	page_view	{"page": "dashboard"}	/	d886bdac-6b28-42dd-bf90-151270ac9d34	2026-02-28 16:46:00.301598
9d8166d9-8d5f-475e-8846-d64e7fed57fc	aZw-6w	page_view	{"page": "dashboard"}	/	f57aae04-727d-4c68-9600-b804bef6c133	2026-02-28 18:58:33.389856
4a0b066e-ed1b-46b5-95a4-2c253e57cf0f	aZw-6w	page_view	{"page": "dashboard"}	/	f57aae04-727d-4c68-9600-b804bef6c133	2026-02-28 19:00:21.778995
82abdce7-d3c6-4d21-9e77-5cea53a1722c	1udX-Q	page_view	{"page": "dashboard"}	/	ded7c059-92dd-4b3e-b923-f6f43403182a	2026-02-28 19:19:03.483843
60a28e07-9040-4035-842e-58b675f44f25	BQ7kP2	page_view	{"page": "dashboard"}	/	2682e715-609a-4099-96a6-8c331c9a240f	2026-02-28 20:48:03.116602
a32c572a-8f00-4fc5-b315-9da748d9fbe7	test-user-999	page_view	{"page": "dashboard"}	/	b0c40823-80b2-4c0d-b42b-6a6cb0f0d03e	2026-02-28 21:33:56.876478
c3e6a934-a1ab-4029-a370-6691f8b1523d	test-sweep-001	page_view	{"page": "dashboard"}	/	9e562b11-8c90-463c-898d-706975e1194b	2026-02-28 21:42:26.70886
c54f59a5-b6c8-4b6b-9fed-c06d59618a91	test-fix-007	page_view	{"page": "dashboard"}	/	2fe9f431-c29c-4ac0-b695-b1ee748995f1	2026-02-28 22:08:14.849024
d4283776-7585-4386-9822-a785fdde0804	test-fix-007	book_open	{"bookId": "23f2345b-6336-4573-a63f-8ee2cd34f56b", "bookTitle": "Man's Search for Meaning"}	/book/23f2345b-6336-4573-a63f-8ee2cd34f56b	2fe9f431-c29c-4ac0-b695-b1ee748995f1	2026-02-28 22:08:57.392225
8fbaf4d3-96c4-4191-b7ef-36f98591d4ea	admin-check-001	page_view	{"page": "dashboard"}	/	7147d41f-d3cc-41a6-82fd-c78d0011095b	2026-02-28 22:29:29.171134
08c0116b-8975-4879-b926-2d99ef2ca9f7	admin-check-001	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	7147d41f-d3cc-41a6-82fd-c78d0011095b	2026-02-28 22:29:38.511596
3a7d4019-72cf-4c85-af0b-a45c63799503	test-buttons-001	page_view	{"page": "dashboard"}	/	9bba290c-e953-4f88-8c28-16159325cc65	2026-02-28 22:31:24.850707
c572ca98-e632-4a27-8e68-3495877530b3	test-buttons-001	book_open	{"bookId": "69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0", "bookTitle": "Emotional Intelligence"}	/book/69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	9bba290c-e953-4f88-8c28-16159325cc65	2026-02-28 22:32:28.312905
dc8df7b8-9b06-4c25-b545-c85696301877	35323958	page_view	{"page": "dashboard"}	/	bab99c7c-70bf-4a79-ba64-ebaa310543ed	2026-02-28 23:16:01.58857
12c6ea47-d7fd-4584-9b62-b49ddf419574	35323958	page_view	{"page": "dashboard"}	/	bab99c7c-70bf-4a79-ba64-ebaa310543ed	2026-02-28 23:18:34.785646
1ef1b540-d3d3-41ee-9e2f-30a02f30178e	35323958	page_view	{"page": "dashboard"}	/	bab99c7c-70bf-4a79-ba64-ebaa310543ed	2026-02-28 23:18:50.108116
0dc5feb2-f57e-451a-b813-9893047376f4	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:19:23.426339
f5cdaf24-59d8-481c-8490-9ff9f8d61572	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:19:40.456683
af7aee7f-27cf-46e9-bbc0-89fe5489389f	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:20:08.234754
0aac2f4b-0862-4bd2-9c6b-a07c100c49e8	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:20:36.417927
5e261a97-cf8b-4bbc-afdd-8699f6a02d00	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:21:05.602275
4a26f60b-577d-4a7b-af80-b732235908f2	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:22:22.6359
35aa5eef-763c-40e7-93e2-c66c1aee1298	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:22:31.544563
310de0e2-3391-4dc6-85b0-8b521f50d86b	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:22:46.455041
20a752ec-8419-4b9f-be66-24f9441146f2	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:23:05.030225
dea5f350-6336-487e-912f-e23f29a0e8ae	35323958	book_open	{"bookId": "2ea408e9-dc96-444c-a0dc-93901f9029b5", "bookTitle": "Atomic Habits"}	/book/2ea408e9-dc96-444c-a0dc-93901f9029b5	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:23:23.100073
e1ea1bc2-55f2-4f15-8461-530ac09f378b	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:23:35.607951
0b30e65b-d758-4dbf-879b-cc9ea9011b63	35323958	page_view	{"page": "dashboard"}	/	9e439eb7-3a0d-4b85-b347-00eec381006a	2026-02-28 23:23:36.556943
e553583d-de9d-4c27-8ef5-d50529462f79	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:23:45.334828
58b553a8-4d3b-4fdc-abc2-f79901a1b025	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:24:30.542035
3e581d6e-30ea-4bce-ba71-5afa2114545e	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:25:33.247584
252c6b6f-a9e0-421a-b2ec-85c76b046112	35323958	page_view	{"page": "dashboard"}	/	b5e12b0b-4019-42d5-83b1-3fd0b974ff48	2026-02-28 23:25:41.639393
ad39960f-e5cd-4586-973c-d4fd39a91245	35323958	page_view	{"page": "dashboard"}	/	71efcea1-17f5-49a1-bbb2-5f37b41a1209	2026-02-28 23:26:35.915432
89753a49-51f4-49e7-b373-54bac20a53c1	35323958	page_view	{"page": "dashboard"}	/	aaf1656d-0579-4be4-b43d-8ec0c02f6be2	2026-03-01 01:18:04.371697
e6943f24-f854-44a9-b770-0aa0532d7ea0	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	aaf1656d-0579-4be4-b43d-8ec0c02f6be2	2026-03-01 01:18:27.615921
b1315304-f53e-4133-a1be-56bd16be487c	35323958	chapter_start	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "section": "shorts", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439/journey	aaf1656d-0579-4be4-b43d-8ec0c02f6be2	2026-03-01 01:18:50.840462
c7b461eb-5a09-4539-a59e-49b213f43289	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	aaf1656d-0579-4be4-b43d-8ec0c02f6be2	2026-03-01 01:18:54.169107
25238735-3c73-4589-9bb7-083afed28bcc	35323958	chapter_start	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "section": "mental-models", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439/journey	aaf1656d-0579-4be4-b43d-8ec0c02f6be2	2026-03-01 01:18:59.432475
6119c373-20c1-44fa-b7e5-59e3807e72b5	35323958	chapter_complete	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "section": "mental-models", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439/journey	aaf1656d-0579-4be4-b43d-8ec0c02f6be2	2026-03-01 01:19:04.456025
ea15464c-5e16-4d37-bace-ed2988f72782	35323958	book_open	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439	aaf1656d-0579-4be4-b43d-8ec0c02f6be2	2026-03-01 01:19:05.066602
1f87aa95-1348-4547-841f-d3bbfe10e8a0	35323958	page_view	{"page": "dashboard"}	/	1368e3f4-a6b0-419d-98a7-8ad1589b38c2	2026-03-01 02:29:48.346592
3817a5b8-472c-436c-b5e2-b50014e8557b	35323958	page_view	{"page": "dashboard"}	/	1368e3f4-a6b0-419d-98a7-8ad1589b38c2	2026-03-01 02:30:35.533005
4ad2c8a3-daaa-402d-b0a6-130729325790	35323958	page_view	{"page": "dashboard"}	/	1368e3f4-a6b0-419d-98a7-8ad1589b38c2	2026-03-01 02:36:23.62244
5082df98-6c8f-4485-abc5-9d4ae1b432ac	35323958	chapter_start	{"bookId": "7ba8d165-4195-43a3-9079-518dd4332439", "section": "chapter-summaries", "bookTitle": "Thinking, Fast and Slow"}	/book/7ba8d165-4195-43a3-9079-518dd4332439/journey	1368e3f4-a6b0-419d-98a7-8ad1589b38c2	2026-03-01 02:37:25.850932
\.


--
-- Data for Name: book_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.book_versions (id, book_id, version_type, content, created_at, created_by, published_at) FROM stdin;
\.


--
-- Data for Name: books; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.books (id, title, author, cover_image, description, category_id, read_time, listen_time, audio_url, featured, principle_count, story_count, exercise_count, core_thesis, status, updated_at, primary_chakra, secondary_chakra, current_draft_version_id, current_published_version_id, affiliate_url, audio_duration, premium_only, free_preview_cards) FROM stdin;
23f2345b-6336-4573-a63f-8ee2cd34f56b	Man's Search for Meaning	Viktor E. Frankl	/images/book-mans-search.png	A psychiatrist's experience in Nazi death camps and its lessons for spiritual survival. Finding meaning in suffering.	92ce161a-985c-43ee-9448-fe686fb5d312	8	7	placeholder	f	3	1	1	Everything can be taken from a person except the last human freedom — to choose one's attitude in any given set of circumstances. Those who find meaning in their suffering can endure almost anything.	published	2026-02-24 00:02:22.879032	crown	\N	\N	\N	\N	\N	f	5
7ba8d165-4195-43a3-9079-518dd4332439	Thinking, Fast and Slow	Daniel Kahneman	/images/book-thinking-fast-slow.png	A groundbreaking tour of the mind that explains the two systems that drive the way we think and make choices.	a6b4bfa5-b571-47d3-8b2f-fd4dab69d731	15	12	placeholder	t	4	2	2	Human judgment is driven by two mental systems: fast, intuitive System 1 and slow, deliberate System 2. Most errors in thinking happen when System 1 hijacks decisions that require System 2's careful analysis.	published	2026-02-24 00:02:22.879032	third_eye	\N	\N	\N	\N	\N	f	5
83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	The Power of Now	Eckhart Tolle	/images/book-power-of-now.png	A guide to spiritual enlightenment that teaches you to live in the present moment and find inner peace.	4f6ff107-44de-4a6e-b29e-bc3f1c9e5ae3	10	8	placeholder	t	3	1	2	The present moment is all you ever have. Suffering is created by the mind's attachment to past and future. True peace comes when you stop identifying with your thoughts and become the awareness behind them.	published	2026-02-24 00:02:22.879032	crown	\N	\N	\N	\N	\N	f	5
69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	Emotional Intelligence	Daniel Goleman	/images/book-emotional-intelligence.png	Why emotional intelligence can matter more than IQ. A revolutionary framework for understanding human behavior.	eb62a63f-dcb3-4341-b435-cc4f72f3ed52	14	11	placeholder	f	3	1	2	IQ accounts for only 20% of life success. The remaining 80% is determined by emotional intelligence — your ability to recognize, understand, and manage your own emotions and those of others.	published	2026-02-24 00:02:22.879032	throat	heart	\N	\N	\N	\N	f	5
2ea408e9-dc96-444c-a0dc-93901f9029b5	Atomic Habits	James Clear	/images/book-atomic-habits.png	An easy and proven way to build good habits and break bad ones. Tiny changes, remarkable results.	cda1b7d3-4089-499e-b7f7-2e41295155e6	12	10	placeholder	t	5	2	3	You do not rise to the level of your goals. You fall to the level of your systems. Small habits compound into extraordinary results when you focus on becoming 1% better every day.	published	2026-02-27 09:07:04.964	solar_plexus	root	\N	\N	https://www.amazon.com/dp/0735211299	\N	f	5
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, slug, icon, color) FROM stdin;
cda1b7d3-4089-499e-b7f7-2e41295155e6	Habits	habits	target	amber
a6b4bfa5-b571-47d3-8b2f-fd4dab69d731	Mindset	mindset	brain	purple
4f6ff107-44de-4a6e-b29e-bc3f1c9e5ae3	Mindfulness	mindfulness	eye	teal
eb62a63f-dcb3-4341-b435-cc4f72f3ed52	Emotions	emotions	lightbulb	rose
92ce161a-985c-43ee-9448-fe686fb5d312	Purpose	meaning	sparkles	indigo
\.


--
-- Data for Name: chakra_progress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chakra_progress (id, user_id, chakra, points, exercises_completed, updated_at) FROM stdin;
\.


--
-- Data for Name: chapter_summaries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chapter_summaries (id, book_id, chapter_number, chapter_title, cards) FROM stdin;
aef2f75d-3416-4e8a-883a-e54478b75dcd	2ea408e9-dc96-444c-a0dc-93901f9029b5	1	The Surprising Power of Atomic Habits	[{"text": "Habits are the compound interest of self-improvement. Getting 1% better every day seems small, but it adds up fast."}, {"text": "If you get 1% better each day for one year, you'll end up 37 times better. 1% worse each day, and you'll decline to nearly zero."}, {"text": "Your outcomes are a lagging measure of your habits. Your weight is a lagging measure of your eating. Your knowledge is a lagging measure of your learning."}, {"text": "Forget about goals. Focus on systems instead. Goals are about results. Systems are about the processes that lead to results."}, {"text": "You don't rise to the level of your goals. You fall to the level of your systems."}]
1b0f687a-64c4-4558-8722-9ed9691fd449	2ea408e9-dc96-444c-a0dc-93901f9029b5	2	How Your Habits Shape Your Identity	[{"text": "There are three layers of behavior change: outcomes (what you get), processes (what you do), and identity (what you believe)."}, {"text": "The most effective way to change isn't to focus on goals, but on who you wish to become."}, {"text": "Every action you take is a vote for the type of person you wish to become."}, {"text": "Instead of 'I want to run a marathon,' think 'I am a runner.' The behavior then becomes obvious."}]
8b80aa64-2eac-4458-aa90-96feb5e1faa2	2ea408e9-dc96-444c-a0dc-93901f9029b5	3	The Four Laws of Behavior Change	[{"text": "Every habit follows a 4-step loop: Cue, Craving, Response, Reward."}, {"text": "To build good habits, use the Four Laws: Make it Obvious, Make it Attractive, Make it Easy, Make it Satisfying."}, {"text": "To break bad habits, invert them: Make it Invisible, Make it Unattractive, Make it Difficult, Make it Unsatisfying."}, {"text": "This simple framework gives you a practical playbook for any behavior you want to change."}]
e0565757-7089-4d57-abba-4c27dd0bb0f7	7ba8d165-4195-43a3-9079-518dd4332439	1	The Characters of the Story	[{"text": "Your brain uses two systems: System 1 (fast, automatic, emotional) and System 2 (slow, deliberate, logical)."}, {"text": "System 1 operates automatically with little effort. It's the voice that says 'that person looks angry' or solves 2+2 instantly."}, {"text": "System 2 allocates attention to effortful mental tasks. It's needed for complex math, comparing options, or checking your logic."}, {"text": "Most of the time, System 1 runs the show. System 2 is lazy and only kicks in when System 1 can't handle something."}]
7143fa4c-9068-439e-aedc-29fc5a0c1d0c	7ba8d165-4195-43a3-9079-518dd4332439	2	Heuristics and Biases	[{"text": "System 1 takes mental shortcuts called heuristics. They're usually helpful but sometimes create systematic errors (biases)."}, {"text": "The Anchoring Effect: the first number you see in a negotiation disproportionately influences where you end up."}, {"text": "The Availability Heuristic: you judge how likely something is based on how easily an example comes to mind, not actual statistics."}, {"text": "These biases aren't flaws — they're features of a brain designed for speed over accuracy in a dangerous world."}]
0f80735a-60ba-426e-9229-b46845803bc1	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	1	You Are Not Your Mind	[{"text": "The greatest obstacle to enlightenment is identification with the mind. You think you ARE your thoughts."}, {"text": "Start listening to the voice in your head as often as you can. Pay attention to repetitive thought patterns."}, {"text": "When you listen to a thought, you become the awareness behind the thought. The thought then loses its power over you."}, {"text": "The moment you realize you are not present, you ARE present. Awareness is the beginning of transformation."}]
4897ed61-0363-455f-a4fa-c0be1fe720ac	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	2	Consciousness: The Way Out of Pain	[{"text": "Emotional pain is created by resistance to what is. The more you resist the present moment, the more you suffer."}, {"text": "The 'pain-body' is an accumulation of old emotional pain. It feeds on negative thinking and drama."}, {"text": "When the pain-body is activated, observe it. Say: 'There is the pain-body.' This simple act of recognition weakens it."}, {"text": "Accept the present moment as if you had chosen it. Work with it, not against it. This removes suffering instantly."}]
a07ed59e-3637-4926-9db3-3691a7792222	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	1	What Are Emotions For?	[{"text": "Emotions evolved as survival signals. Fear triggers the fight-or-flight response. Anger prepares you to confront threats."}, {"text": "The problem: our emotional brain was designed for prehistoric threats, not modern stressors like emails and traffic."}, {"text": "The amygdala — our emotional alarm system — can hijack rational thinking in milliseconds, before the thinking brain even has a chance."}, {"text": "Understanding this hijack is the first step to emotional intelligence: creating space between stimulus and response."}]
458a9a09-f8a5-43d4-97dd-60ded03b9df3	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	2	The Five Pillars of EQ	[{"text": "Pillar 1: Self-Awareness — knowing what you're feeling as you feel it."}, {"text": "Pillar 2: Self-Regulation — managing impulses and distressing emotions effectively."}, {"text": "Pillar 3: Motivation — using emotions to drive you toward goals despite setbacks."}, {"text": "Pillars 4 & 5: Empathy and Social Skills — reading others' emotions and managing relationships successfully."}]
c38563a8-f2b9-41d5-8b34-2ec7c78cc716	23f2345b-6336-4573-a63f-8ee2cd34f56b	1	Experiences in a Concentration Camp	[{"text": "Frankl observed three psychological phases among prisoners: shock on arrival, apathy during imprisonment, and disorientation after liberation."}, {"text": "Those who survived were not the physically strongest, but those who found something to live for — a loved one, a task, a purpose."}, {"text": "Even in the most degrading conditions, prisoners who maintained an inner life and sense of meaning were more resilient."}, {"text": "Frankl realized: suffering ceases to be suffering the moment it finds a meaning — such as a sacrifice for a loved one."}]
f88036ab-e9c0-4913-afdb-210045f18186	23f2345b-6336-4573-a63f-8ee2cd34f56b	2	Logotherapy in a Nutshell	[{"text": "Logotherapy is Frankl's therapeutic approach. 'Logos' means 'meaning.' The primary drive in humans is not pleasure or power, but meaning."}, {"text": "There are three ways to find meaning: through creative work, through experiencing beauty or love, and through the attitude we take toward unavoidable suffering."}, {"text": "The 'existential vacuum' — a feeling of inner emptiness and meaninglessness — is the mass neurosis of our time."}, {"text": "Freedom without responsibility is empty. True fulfillment comes when you take responsibility for creating meaning in your life."}]
1b7f5aa2-64d2-4d60-9a63-a69afaee191c	2ea408e9-dc96-444c-a0dc-93901f9029b5	4	Chapter 4	[{"text": "Enter the first insight..."}]
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comments (id, book_id, block_type, block_id, user_id, content, resolved, created_at) FROM stdin;
\.


--
-- Data for Name: common_mistakes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.common_mistakes (id, book_id, mistake, correction, order_index) FROM stdin;
5cde40dd-242e-48f2-b2e6-2be76cbe03f6	2ea408e9-dc96-444c-a0dc-93901f9029b5	Setting ambitious goals without building systems to support them. 'I'll run a marathon this year' with no daily running habit.	Focus on the system, not the goal. Build a daily identity: 'I am a runner who shows up every day, even if it's just for 2 minutes.'	1
431d86ed-6e01-45a0-9157-dc63a4a249b7	2ea408e9-dc96-444c-a0dc-93901f9029b5	Trying to make massive changes overnight. Going from zero exercise to an hour every day.	Use the Two-Minute Rule. Start so small it's impossible to fail: put on your running shoes, do 2 push-ups, meditate for 60 seconds.	2
57147c58-cf06-4df6-b91f-fe0095ca84f4	2ea408e9-dc96-444c-a0dc-93901f9029b5	Relying on motivation and willpower instead of designing your environment.	Redesign your surroundings. Put the book on the pillow, the fruit on the counter, the gym clothes by the door. Make good cues obvious.	3
69bbe56e-132a-484f-acd1-bb4ddce97c54	7ba8d165-4195-43a3-9079-518dd4332439	Trusting your gut feeling for complex financial decisions, job changes, or relationship choices.	Slow down. Engage System 2 deliberately: write out pros and cons, assign probabilities, and ask 'what information am I missing?'	1
1144569b-997b-41e0-9902-5c8f1d107291	7ba8d165-4195-43a3-9079-518dd4332439	Letting the first number in a negotiation (the anchor) dictate the entire outcome without questioning it.	Recognize the anchor and deliberately counter it. Research your own independent baseline before entering any negotiation.	2
b1d08fbb-31fb-4b20-9197-a47255323b55	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	Using meditation or mindfulness as another goal to achieve, another thing to 'get right.'	Presence isn't something you accomplish. It's what remains when you stop doing. Simply notice you're thinking — that IS the practice.	1
4767f218-ba46-4738-b925-c44ada3cba57	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	Believing you need to stop all thoughts to be 'present.' Getting frustrated when thoughts keep coming.	You can't stop thoughts. But you can stop identifying with them. Watch them pass like clouds — you are the sky, not the weather.	2
f29f9386-ce56-465c-9607-95ee01e8f941	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	Suppressing emotions and pretending everything is fine. 'I don't get angry' is usually a red flag, not a strength.	Acknowledge the emotion without acting on it. Say 'I notice I'm feeling angry right now' — naming the emotion reduces its intensity by up to 50%.	1
22865b10-6db8-4ea6-a4b5-8e58a2408011	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	Confusing empathy with agreement. Thinking that understanding someone's perspective means you endorse their behavior.	Empathy is about understanding, not agreeing. You can fully understand why someone is angry AND still disagree with their actions.	2
f67c4165-e27a-4a49-8910-7eacfd5e4fca	23f2345b-6336-4573-a63f-8ee2cd34f56b	Pursuing happiness directly. Making 'being happy' the goal of your life.	Happiness cannot be pursued; it must ensue. It comes as a side effect of dedicating yourself to a cause greater than yourself or loving another person.	1
a05a6f09-f83b-40c9-baf4-051791d3b976	23f2345b-6336-4573-a63f-8ee2cd34f56b	Believing suffering is always meaningless and should be avoided at all costs.	Unavoidable suffering can become meaningful when you choose your response to it. This doesn't mean seeking suffering — but when it comes, find the lesson.	2
\.


--
-- Data for Name: daily_sparks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.daily_sparks (id, quote, author, book_id, category) FROM stdin;
fed10093-e41c-4377-951b-558eba55385b	We are what we repeatedly do. Excellence, then, is not an act, but a habit.	Aristotle	2ea408e9-dc96-444c-a0dc-93901f9029b5	habits
5272b598-ead7-41d8-9d6d-0c49b9cbee05	The happiness of your life depends upon the quality of your thoughts.	Marcus Aurelius	7ba8d165-4195-43a3-9079-518dd4332439	mindset
4234fe1d-183c-46bb-89ac-86b7f99c470d	Realize deeply that the present moment is all you have.	Eckhart Tolle	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	mindfulness
912fd99c-7e14-49e3-a63c-9a6395edec04	In a very real sense we have two minds, one that thinks and one that feels.	Daniel Goleman	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	emotions
23f01ea5-ab06-4edf-bc63-9be8057e822e	When we are no longer able to change a situation, we are challenged to change ourselves.	Viktor E. Frankl	23f2345b-6336-4573-a63f-8ee2cd34f56b	meaning
7badd41e-7ba8-43ce-86ab-fa41a1cc96c7	Between stimulus and response there is a space. In that space is our power to choose our response.	Viktor E. Frankl	23f2345b-6336-4573-a63f-8ee2cd34f56b	meaning
17356489-0a18-44b2-a7ce-154140b88ccd	You do not rise to the level of your goals. You fall to the level of your systems.	James Clear	2ea408e9-dc96-444c-a0dc-93901f9029b5	habits
27931d8d-43ae-4200-aa60-90880a849919	Nothing in life is as important as you think it is, while you are thinking about it.	Daniel Kahneman	7ba8d165-4195-43a3-9079-518dd4332439	mindset
31d5a531-940b-410e-a761-64123f4e4cdc	Life is not primarily a quest for pleasure or a quest for power, but a quest for meaning.	Viktor E. Frankl	23f2345b-6336-4573-a63f-8ee2cd34f56b	meaning
e8e9a3fb-9521-4e29-a755-dbd7b9db8794	The mind is everything. What you think you become.	Buddha	\N	mindfulness
b8f512bd-0029-43aa-943e-1765e36d19b6	Every action you take is a vote for the type of person you wish to become.	James Clear	2ea408e9-dc96-444c-a0dc-93901f9029b5	habits
ddb07402-80f9-4c55-a03d-c726eac5064c	The ability to observe without evaluating is the highest form of intelligence.	Jiddu Krishnamurti	\N	mindfulness
\.


--
-- Data for Name: exercises; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exercises (id, book_id, title, description, type, content, order_index, impact, powers_up_chakra) FROM stdin;
d8f707af-0e29-4a8b-b25e-12680e2b165b	2ea408e9-dc96-444c-a0dc-93901f9029b5	Habit Scorecard	Create awareness of your daily habits by scoring each one.	reflection	{"prompt": "Write down your complete daily routine from waking up to going to bed. Next to each habit, write +, -, or = to rate whether it's positive, negative, or neutral for the person you want to become."}	1	high	\N
d48e36e5-05b0-4709-b52a-9be1b1c7687a	2ea408e9-dc96-444c-a0dc-93901f9029b5	The Four Laws Quiz	Test your understanding of the four laws of behavior change.	quiz	{"questions": [{"correct": 1, "options": ["Make it attractive", "Make it obvious", "Make it easy", "Make it satisfying"], "question": "What is the first law of behavior change?"}, {"correct": 2, "options": ["Set a big goal", "Find an accountability partner", "Link it to a specific time and location", "Reward yourself immediately"], "question": "According to James Clear, the best way to start a new habit is to:"}, {"correct": 1, "options": ["Doing many habits at once", "Linking a new habit to an existing one", "Building habits in sequence", "Removing bad habits one by one"], "question": "What is 'habit stacking'?"}]}	2	medium	\N
bdfbc6e9-7c20-4e97-ad01-7eb63ec5383b	2ea408e9-dc96-444c-a0dc-93901f9029b5	Implementation Intention	Create a specific plan for when and where you will perform a new habit.	action_plan	{"steps": ["Choose one habit you want to build this week", "Decide the exact time you will do it", "Decide the exact location where you will do it", "Write it down: 'I will [BEHAVIOR] at [TIME] in [LOCATION]'", "Set a reminder on your phone for the chosen time", "Track your completion for 7 days straight"]}	3	high	\N
1a69b8b6-dd09-4798-8ca4-ed92dc3530f0	7ba8d165-4195-43a3-9079-518dd4332439	Spot Your System 1 Biases	Reflect on recent decisions where your fast-thinking System 1 may have led you astray.	reflection	{"prompt": "Think about the last important decision you made quickly. What assumptions did your 'gut feeling' make? Looking back, what information did you overlook? How might the outcome have been different if you had slowed down?"}	1	high	\N
5be1ff8a-969c-4163-a77b-2bc867c01598	7ba8d165-4195-43a3-9079-518dd4332439	Cognitive Bias Quiz	Test your understanding of common cognitive biases.	quiz	{"questions": [{"correct": 1, "options": ["Being stuck in one viewpoint", "Initial values disproportionately influencing estimates", "Fear of change", "Repeating past mistakes"], "question": "What is the anchoring effect?"}, {"correct": 1, "options": ["We're naturally pessimistic", "Evolution wired us to avoid threats more than seek rewards", "We have bad memory for gains", "Social conditioning"], "question": "Why do losses feel more powerful than equivalent gains?"}]}	2	medium	\N
f55e69c5-91c0-46bd-a5ea-beff010558ac	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	One-Minute Presence	Practice being fully present for 60 seconds.	action_plan	{"steps": ["Close your eyes and take three deep breaths", "Focus your attention on the sensations in your body", "Notice sounds around you without labeling them", "Feel the aliveness in your hands", "When thoughts arise, simply observe them without engaging", "Open your eyes and notice how you feel"]}	1	high	\N
23c1cb6e-8d22-425a-b5ac-290def2ffb57	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	Watching the Thinker	Practice observing your thoughts without attachment.	reflection	{"prompt": "Set a timer for 5 minutes. Sit quietly and observe the stream of thoughts that passes through your mind. Don't judge or try to stop any thoughts. After the exercise, write about what you noticed."}	2	high	\N
e9d22d61-cfdc-4e87-bab0-43af92292248	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	Emotion Log	Track your emotions throughout the day to build self-awareness.	reflection	{"prompt": "For the next 24 hours, pause three times and ask yourself: What am I feeling right now? What triggered this feeling? How is this emotion affecting my behavior?"}	1	high	\N
870ab977-badf-4bfc-a4e0-1bfefe1b3aa5	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	EQ Fundamentals Quiz	Test your understanding of emotional intelligence concepts.	quiz	{"questions": [{"correct": 1, "options": ["Social skills", "Self-awareness", "Motivation", "Empathy"], "question": "What is the foundation of emotional intelligence?"}, {"correct": 1, "options": ["A memory loss event", "An emotional response before rational processing", "A manipulation technique", "A learning disability"], "question": "What is an 'amygdala hijack'?"}]}	2	low	\N
258bf2b5-e83c-45c1-864e-d51abb547a62	23f2345b-6336-4573-a63f-8ee2cd34f56b	Finding Your 'Why'	Reflect on what gives your life meaning and purpose.	reflection	{"prompt": "Frankl believed there are three sources of meaning: (1) creating a work or doing a deed, (2) experiencing something or encountering someone, and (3) the attitude we take toward unavoidable suffering. Reflect on your life through these three lenses."}	1	high	\N
7529cc68-095e-4d57-9f38-0e27ec9de76c	2ea408e9-dc96-444c-a0dc-93901f9029b5	New Exercise	Describe the exercise...	reflection	{"prompt": "What did you learn?"}	3	medium	\N
\.


--
-- Data for Name: flashcard_progress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flashcard_progress (id, user_id, book_id, principle_id, status, next_review_date, ease_factor, "interval", repetitions, created_at, updated_at) FROM stdin;
1f6ccf67-de30-4c35-a0c6-00670762b0e4	oU-UWK	2ea408e9-dc96-444c-a0dc-93901f9029b5	ebfb77ff-1dee-419b-bb14-18d7648cd42b	learning	2026-02-28 15:00:46.56	2.6	1	1	2026-02-27 15:00:46.560991	2026-02-27 15:00:46.560991
d04a5171-6805-4e52-a110-18018401b9e9	a_rJjy	2ea408e9-dc96-444c-a0dc-93901f9029b5	ebfb77ff-1dee-419b-bb14-18d7648cd42b	learning	2026-02-28 15:07:07.495	2.36	1	1	2026-02-27 15:07:07.495739	2026-02-27 15:07:07.495739
\.


--
-- Data for Name: infographics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.infographics (id, book_id, title, description, image_url, steps, order_index) FROM stdin;
092947da-de2f-488f-8159-82d6b364d1af	2ea408e9-dc96-444c-a0dc-93901f9029b5	The Habit Loop	How every habit works in 4 steps	\N	[{"label": "1. Cue", "explanation": "A trigger that tells your brain to initiate a behavior. It could be a time, location, emotion, or preceding action."}, {"label": "2. Craving", "explanation": "The motivational force behind every habit. You don't crave the habit itself—you crave the change in state it delivers."}, {"label": "3. Response", "explanation": "The actual habit you perform—a thought or action. It depends on how motivated you are and how much friction is involved."}, {"label": "4. Reward", "explanation": "The end goal of every habit. Rewards satisfy your craving and teach your brain which actions are worth remembering."}]	1
8da34c78-ca70-4b47-897d-e287ee55c69e	2ea408e9-dc96-444c-a0dc-93901f9029b5	1% Better Every Day	The power of tiny gains compounding over time	\N	[{"label": "Day 1", "explanation": "Start with a habit so small it takes less than 2 minutes. Read one page. Do one push-up."}, {"label": "Day 30", "explanation": "Consistency builds identity. You've cast 30 votes for the person you want to become."}, {"label": "Day 180", "explanation": "The plateau of latent potential is behind you. Results become visible as the compound effect kicks in."}, {"label": "Day 365", "explanation": "1% daily improvement = 37x better in a year. Your system is now automatic and self-reinforcing."}]	2
e2cc8e4a-7497-4ff4-8b5c-8ecab1aa650a	7ba8d165-4195-43a3-9079-518dd4332439	System 1 vs System 2	Two modes of thinking that drive every decision	\N	[{"label": "System 1: Fast", "explanation": "Automatic, effortless, emotional. Handles routine decisions in milliseconds. Prone to biases and shortcuts."}, {"label": "System 2: Slow", "explanation": "Deliberate, effortful, logical. Activated for complex problems. Requires focus and mental energy."}, {"label": "The Conflict", "explanation": "System 1 makes quick judgments. System 2 is supposed to check them — but it's lazy and often just endorses System 1's answer."}, {"label": "The Fix", "explanation": "Recognize when System 1 is driving. For important decisions, deliberately activate System 2 by slowing down and questioning assumptions."}]	1
93bfbefe-7a27-456b-a76f-459a69ecb5bb	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	The Layers of Presence	Moving from thought to awareness in 3 levels	\N	[{"label": "Level 1: Thinking", "explanation": "Lost in the stream of thoughts. Past regrets and future anxieties dominate. You identify completely with your mind."}, {"label": "Level 2: Observing", "explanation": "You notice you're thinking. A gap opens between you and your thoughts. This is the beginning of presence."}, {"label": "Level 3: Being", "explanation": "Pure awareness without labels. You experience life directly — sounds, sensations, aliveness — without the filter of mental commentary."}]	1
a1494dd4-d991-4f17-aa85-7340e087c5c5	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	The 5 Pillars of EQ	Five skills that define emotional intelligence	\N	[{"label": "1. Self-Awareness", "explanation": "Recognize your emotions as they happen. Know your strengths, weaknesses, and emotional triggers."}, {"label": "2. Self-Regulation", "explanation": "Manage disruptive emotions. Pause before reacting. Choose your response instead of being controlled by impulse."}, {"label": "3. Motivation", "explanation": "Drive yourself toward goals with optimism and resilience, even when facing setbacks."}, {"label": "4. Empathy", "explanation": "Sense and understand other people's emotions. See situations from their perspective."}, {"label": "5. Social Skills", "explanation": "Build relationships, manage conflict, inspire and influence others through effective communication."}]	1
0b30fa38-94ec-4f73-94d6-29bbf4fe2449	23f2345b-6336-4573-a63f-8ee2cd34f56b	Three Sources of Meaning	Frankl's framework for finding purpose in any circumstance	\N	[{"label": "1. Creative Values", "explanation": "Find meaning through what you give to the world — your work, art, ideas, or deeds. What can you create or contribute?"}, {"label": "2. Experiential Values", "explanation": "Find meaning through what you receive from the world — love, beauty, truth, nature. What moments take your breath away?"}, {"label": "3. Attitudinal Values", "explanation": "Find meaning through the stance you take toward unavoidable suffering. When you can't change the situation, you can still choose your response."}]	1
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.journal_entries (id, user_id, exercise_id, content, created_at) FROM stdin;
\.


--
-- Data for Name: mental_models; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mental_models (id, book_id, title, description, steps, order_index) FROM stdin;
18f88ce2-24bc-4a67-b9c9-bfbc398cd47e	2ea408e9-dc96-444c-a0dc-93901f9029b5	The Habit Loop	The four-step neurological pattern behind every habit.	[{"label": "Cue", "explanation": "A trigger that tells your brain to initiate a behavior. It predicts a reward."}, {"label": "Craving", "explanation": "The motivational force. You don't crave the habit itself, but the change in state it delivers."}, {"label": "Response", "explanation": "The actual habit you perform. It can be a thought or an action."}, {"label": "Reward", "explanation": "The end goal. Rewards satisfy your craving and teach your brain which actions are worth remembering."}]	1
91a8c9bb-6b05-47bf-92d6-22c5150a9f15	2ea408e9-dc96-444c-a0dc-93901f9029b5	The Plateau of Latent Potential	Why results seem to take forever, then arrive all at once.	[{"label": "The Valley of Disappointment", "explanation": "In the early days, your efforts seem to produce no visible results. This is where most people give up."}, {"label": "The Breakthrough", "explanation": "At a certain point, previous efforts unlock a breakthrough and results seem to arrive overnight."}, {"label": "The Ice Cube Analogy", "explanation": "Imagine heating an ice cube from 25 to 31 degrees. Nothing visible happens. At 32 degrees, it begins to melt. The work wasn't wasted — it was being stored."}]	2
1422322d-0174-4d0a-80d2-57ea5d1d252f	7ba8d165-4195-43a3-9079-518dd4332439	System 1 vs System 2	The dual-process model of human cognition.	[{"label": "System 1: The Automatic Pilot", "explanation": "Handles pattern recognition, emotional reactions, and well-practiced responses instantly without conscious effort."}, {"label": "System 2: The Careful Analyst", "explanation": "Engages for complex reasoning, self-control, and deliberate choices. Requires attention and energy."}, {"label": "The Handoff Problem", "explanation": "System 1 generates impressions and feelings that System 2 often endorses without checking. This is where biases slip in."}, {"label": "When System 2 Fails", "explanation": "Under cognitive load, time pressure, or fatigue, System 2 can't override System 1's mistakes. This is when we make our worst decisions."}]	1
52304cb8-897f-48d8-9d47-9c66a9af0b50	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	The Timeline of Suffering	How the mind creates pain through time-based thinking.	[{"label": "Past = Guilt & Regret", "explanation": "The mind replays past events, creating guilt, resentment, and 'if only' stories that have no power to change anything."}, {"label": "Future = Anxiety & Fear", "explanation": "The mind projects worst-case scenarios forward, generating anxiety about things that haven't happened and may never happen."}, {"label": "The Present = Peace", "explanation": "In the actual present moment, stripped of mental stories, there is usually no problem. There is only what IS."}, {"label": "The Practice", "explanation": "Ask yourself: 'Am I at ease in this moment?' If not, what are you resisting? Accept what is, then act from clarity, not fear."}]	1
0d1b9711-4807-45f5-9921-805a04c99982	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	The EQ Framework	Daniel Goleman's five components of emotional intelligence.	[{"label": "Self-Awareness", "explanation": "Recognizing your emotions in real-time. This is the foundation — you can't manage what you don't notice."}, {"label": "Self-Regulation", "explanation": "The ability to pause before reacting. Managing impulses, anxiety, and anger constructively."}, {"label": "Motivation", "explanation": "Using emotional energy to pursue goals with persistence. Delaying gratification for long-term rewards."}, {"label": "Empathy", "explanation": "Sensing what others feel without them telling you. Reading body language, tone, and unspoken signals."}, {"label": "Social Skills", "explanation": "Managing relationships effectively. Influence, conflict resolution, collaboration, and leadership."}]	1
b8bf9a20-03d4-4d4f-aecc-8510093ae8b9	23f2345b-6336-4573-a63f-8ee2cd34f56b	The Three Sources of Meaning	Frankl's framework for finding purpose in any circumstance.	[{"label": "Creative Values", "explanation": "Meaning through what you give to the world: your work, your art, your contributions. Creating something larger than yourself."}, {"label": "Experiential Values", "explanation": "Meaning through what you receive from the world: love, beauty, truth, nature. The richness of fully experiencing life."}, {"label": "Attitudinal Values", "explanation": "Meaning through the stance you take toward unavoidable suffering. The highest form of meaning — turning tragedy into triumph."}]	1
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_preferences (id, user_id, daily_reminder, streak_alerts, new_content, weekly_summary, reminder_time, push_subscription, permission_status, last_prompt_dismissed, updated_at) FROM stdin;
f61e82d9-63ab-4554-b02b-ef2ad03c3784	tcBg5V	t	t	t	t	09:00	\N	dismissed	2026-02-27 08:13:10.038	2026-02-27 08:13:10.038
b9eb1f72-bae9-4a2e-8aff-e722e78c8b15	X5bqd-	t	t	t	t	09:00	\N	dismissed	2026-02-27 08:21:52.633	2026-02-27 08:21:52.633
9eedc182-a525-4914-b967-792753b50b64	b5yZvL	t	t	t	t	09:00	\N	dismissed	2026-02-27 08:28:14.398	2026-02-27 08:28:14.398
dbe9f9fb-8b57-41b0-82c4-9b1133645462	yuVB4U	t	t	t	t	09:00	\N	dismissed	2026-02-27 08:39:45.874	2026-02-27 08:39:45.874
0d612860-b97d-4354-9782-636a38a86e99	a8S2dP	t	t	t	t	09:00	\N	default	\N	2026-02-27 09:03:06.609014
95344c17-6a79-474d-bbe0-198d91d1b36a	j69UEF	t	t	t	t	09:00	\N	dismissed	2026-02-27 09:09:04.848	2026-02-27 09:09:04.848
ce4c7a86-031a-4660-b067-b65464c1df6b	pIDdI2	t	t	t	t	09:00	\N	dismissed	2026-02-27 09:13:38.278	2026-02-27 09:13:38.278
87b965ba-4c75-4428-b647-16885bfb5dc0	Jkp87u	t	t	t	t	09:00	\N	dismissed	2026-02-27 09:20:02.193	2026-02-27 09:20:02.193
c7b6b867-3e42-40f0-b71a-44c5381f856f	tImpmS	t	t	t	t	09:00	\N	dismissed	2026-02-27 09:30:50.534	2026-02-27 09:30:50.534
24495acd-651a-45c6-b3e5-9c6db3701e14	9BmmO0	t	t	t	t	09:00	\N	dismissed	2026-02-27 09:49:15.224	2026-02-27 09:49:15.224
7cece49b-0614-4b10-8d8e-089083212557	W46Jai	t	t	t	t	09:00	\N	dismissed	2026-02-27 10:14:10.903	2026-02-27 10:14:10.903
ee4152da-3c70-4da1-b8d8-bc44dc6df55c	oU-UWK	t	t	t	t	09:00	\N	dismissed	2026-02-27 15:00:01.219	2026-02-27 15:00:01.219
a1621a66-1e59-46c6-baf5-2f293cd8f287	a_rJjy	t	t	t	t	09:00	\N	dismissed	2026-02-27 15:05:52.235	2026-02-27 15:05:52.235
4d9e8e57-5c61-496a-98bc-d7152d07980a	Wc93iB	t	t	t	t	09:00	\N	dismissed	2026-02-28 05:36:14.554	2026-02-28 05:36:14.554
99ce2acd-42cc-40ee-9159-dd6bf85ef35b	8wB_v6	t	t	t	t	09:00	\N	dismissed	2026-02-28 05:53:35.577	2026-02-28 05:53:35.577
04b1fdb8-0ace-42a5-9f91-c5e486f31804	z5Axnh	t	t	t	t	09:00	\N	dismissed	2026-02-28 07:13:54.094	2026-02-28 07:13:54.094
31d0f3d3-d9cc-4c17-ad88-d2958f513b55	aZw-6w	t	t	t	t	09:00	\N	dismissed	2026-02-28 18:59:03.202	2026-02-28 18:59:03.202
e2df7729-2322-40b8-8519-858ebe0f0022	1udX-Q	t	t	t	t	09:00	\N	default	\N	2026-02-28 19:19:03.578119
a62b5619-94c0-4f42-81ed-3c3ba133f436	BQ7kP2	t	t	t	t	09:00	\N	dismissed	2026-02-28 20:49:05.62	2026-02-28 20:49:05.62
ac880192-91d4-4679-ba5a-549ea63c6efa	test-user-999	t	t	t	t	09:00	\N	dismissed	2026-02-28 21:34:16.693	2026-02-28 21:34:16.693
021e201d-1d05-4d58-8e0f-500133d5a077	test-sweep-001	t	t	t	t	09:00	\N	dismissed	2026-02-28 21:43:07.975	2026-02-28 21:43:07.975
2c07c2de-5076-4fea-b0d9-2262109c21a4	test-fix-007	t	t	t	t	09:00	\N	dismissed	2026-02-28 22:08:42.779	2026-02-28 22:08:42.779
ad0f9461-563d-4bac-b5f8-db61e2143a59	admin-check-001	t	t	t	t	09:00	\N	default	\N	2026-02-28 22:29:29.246974
7167ea74-9573-4a7d-b4cf-dc2489de6fac	test-buttons-001	t	t	t	t	09:00	\N	dismissed	2026-02-28 22:32:22.77	2026-02-28 22:32:22.77
79405222-3f1e-43ac-bf66-53600a7ee3fc	35323958	t	t	t	t	09:00	{"keys": {"auth": "_p2a3GmMSf--Are0QqmA5g", "p256dh": "BPSSAzatFgKYJ9mZOqpVATxstr3ePp81BU7yx05nAc0quVLTzFWHVSe2Yz7kcsV9abJ0l10TL9zopb0_HNpzkuc"}, "endpoint": "https://fcm.googleapis.com/fcm/send/cKW6bllMAp8:APA91bER5qUDJ99-O3TA_0Ha8M44gQPndccIBZzn9rO3cyPyU3TchNyhe8e2e6D9_4tmQZduohqN5zbSYkF63imDSa31XIKXt4qiI5TRv-u25mH5f5hK3n8otQdQH5ieoos09peZV4cB", "expirationTime": null}	dismissed	2026-02-28 23:24:00.064	2026-02-28 23:24:00.064
\.


--
-- Data for Name: principles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.principles (id, book_id, title, content, order_index, icon, visual_type, visual_data) FROM stdin;
ebfb77ff-1dee-419b-bb14-18d7648cd42b	2ea408e9-dc96-444c-a0dc-93901f9029b5	The 1% Rule	Habits are the compound interest of self-improvement. Getting 1% better every day counts for a lot in the long-run. If you get 1% better each day for one year, you'll end up 37 times better by the time you're done.	1	trending_up	\N	\N
41dcfb17-21dc-4c9c-ad86-664f6ab48e9e	2ea408e9-dc96-444c-a0dc-93901f9029b5	Identity-Based Habits	The most effective way to change your habits is to focus not on what you want to achieve, but on who you wish to become. Your identity emerges from your habits. Every action is a vote for the type of person you wish to become.	2	person	\N	\N
4c97e27e-0079-4c73-85aa-c2f59083b1d9	2ea408e9-dc96-444c-a0dc-93901f9029b5	The Four Laws of Behavior Change	Make it obvious. Make it attractive. Make it easy. Make it satisfying. These four laws are a simple set of rules for creating good habits and breaking bad ones.	3	list	\N	\N
a01a7109-6e1f-4b0d-8372-f60b0cf43303	2ea408e9-dc96-444c-a0dc-93901f9029b5	Environment Design	Environment is the invisible hand that shapes human behavior. Many people think they lack motivation when they actually lack clarity. Make the cues of good habits obvious in your environment.	4	home	\N	\N
6fbbbbcc-1c95-40dc-9394-9c5868fb06fc	2ea408e9-dc96-444c-a0dc-93901f9029b5	The Two-Minute Rule	When you start a new habit, it should take less than two minutes to do. A new habit should not feel like a challenge. The actions that follow can be challenging, but the first two minutes should be easy.	5	timer	\N	\N
ae54bb94-fb76-45e9-9c9d-ac123229cf94	7ba8d165-4195-43a3-9079-518dd4332439	System 1 and System 2	Your mind operates with two systems. System 1 is fast, automatic, and intuitive — it handles everyday decisions effortlessly. System 2 is slow, deliberate, and logical — it engages when you face complex problems. Most errors in judgment occur when System 1 takes over tasks that require System 2.	1	brain	\N	\N
c7cb13a2-dea8-4c2f-859f-56185dbf5664	7ba8d165-4195-43a3-9079-518dd4332439	Anchoring Effect	People's estimates are heavily influenced by initial values or 'anchors,' even when those anchors are random. When making judgments, the first piece of information we receive has an outsized effect on our final decision.	2	anchor	\N	\N
406e77bb-c567-4427-a6ff-d47ea1e5c761	7ba8d165-4195-43a3-9079-518dd4332439	Loss Aversion	Losses loom larger than gains. The pain of losing $100 is about twice as powerful as the pleasure of gaining $100. This asymmetry between the power of positive and negative expectations explains many patterns of human behavior.	3	shield	\N	\N
67d85b9d-000c-459a-9e2b-8ec268d536de	7ba8d165-4195-43a3-9079-518dd4332439	The Planning Fallacy	People tend to underestimate the time, costs, and risks of future actions and overestimate their benefits. This bias explains why projects run over budget, why we're always late, and why optimism often defeats realism.	4	calendar	\N	\N
821e3382-8c8b-4342-a315-45a3759e0bf8	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	The Present Moment Is All You Have	Nothing has happened in the past; it happened in the Now. Nothing will ever happen in the future; it will happen in the Now. The present moment is the only thing you ever have.	1	circle	\N	\N
5a81cea2-ec9a-4c2b-b3a6-975ebedbbcce	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	You Are Not Your Mind	The beginning of freedom is the realization that you are not the possessing entity — the thinker. The moment you start watching the thinker, a higher level of consciousness becomes activated.	2	eye	\N	\N
d80c82fa-ea64-4434-9674-2762182ab698	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	The Pain-Body	The pain-body is a semi-autonomous energy form that lives within most human beings. It is the accumulated emotional pain from the past. It can be dormant or active.	3	heart	\N	\N
b1f80612-e762-444b-90b7-31e9b31cf7f8	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	Self-Awareness Is the Foundation	Emotional intelligence begins with self-awareness — the ability to recognize and understand your own emotions as they occur.	1	mirror	\N	\N
154b9ce1-0226-4af1-a070-76f3c327cebf	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	Emotional Hijacking	The amygdala can trigger an emotional response before the rational brain has time to process the situation. This 'amygdala hijack' explains why we sometimes say or do things in anger that we later regret.	2	zap	\N	\N
f1985c47-e324-43f1-a3a3-b79cf8333d18	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	Empathy Drives Connection	Empathy — the ability to sense other people's emotions — is the most important people skill. It is built on self-awareness; the more open we are to our own emotions, the more skilled we become at reading others.	3	users	\N	\N
6af8c02a-9a53-4ab6-a14c-4d4daef118f6	23f2345b-6336-4573-a63f-8ee2cd34f56b	The Last Human Freedom	Everything can be taken from a man but one thing: the last of the human freedoms — to choose one's attitude in any given set of circumstances.	1	key	\N	\N
27768284-d259-488a-8547-4eaedf41f068	23f2345b-6336-4573-a63f-8ee2cd34f56b	Meaning Through Suffering	If there is meaning in life at all, then there must be meaning in suffering. The way in which a person takes up their cross gives them ample opportunity to add a deeper meaning to life.	2	mountain	\N	\N
dc054137-0464-4922-8750-777b4d915b44	23f2345b-6336-4573-a63f-8ee2cd34f56b	Logotherapy: The Will to Meaning	Frankl's therapeutic approach, logotherapy, is based on the premise that the primary motivational force of an individual is to find meaning in life.	3	compass	\N	\N
\.


--
-- Data for Name: quiz_results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quiz_results (id, user_id, book_id, chapter_id, score, total_questions, answers, completed_at) FROM stdin;
073ca218-6eca-4331-bd42-747fd14cb408	a_rJjy	2ea408e9-dc96-444c-a0dc-93901f9029b5	aef2f75d-3416-4e8a-883a-e54478b75dcd	1	4	[{"correct": false, "selected": 0, "questionId": "ch-aef2f75d-3416-4e8a-883a-e54478b75dcd"}, {"correct": true, "selected": 0, "questionId": "ch-1b0f687a-64c4-4558-8722-9ed9691fd449"}, {"correct": false, "selected": 0, "questionId": "ch-1b7f5aa2-64d2-4d60-9a63-a69afaee191c"}, {"correct": false, "selected": 0, "questionId": "ch-8b80aa64-2eac-4458-aa90-96feb5e1faa2"}]	2026-02-27 15:06:41.745873
\.


--
-- Data for Name: saved_highlights; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.saved_highlights (id, user_id, book_id, principle_id, content, type, created_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (sid, sess, expire) FROM stdin;
uZglG0k2QtES-NV3WS4aAmglf7ND_izj	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-05T22:35:33.487Z", "httpOnly": true, "originalMaxAge": 604800000}, "returnTo": "/admin", "replit.com": {"code_verifier": "SXIiktvZQ8RwTVMl2M16Mrl0XeVwXxvM_9LAKwKdgZ8"}}	2026-03-05 22:35:34
4VMEfKrssqiFWfyVlB9BpHUYP14fW2wt	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-05T01:34:00.515Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772073240, "iat": 1772069640, "iss": "https://test-mock-oidc.replit.app/", "jti": "aedbd6457a125cfe35711d45fa4e61a1", "sub": "35323958", "email": "35323958@example.com", "auth_time": 1772069640, "last_name": "User", "first_name": "Admin"}, "expires_at": 1772073240, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMDY5NjQwLCJleHAiOjE3NzIwNzMyNDAsInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiIzNTMyMzk1OEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJBZG1pbiIsImxhc3RfbmFtZSI6IlVzZXIifQ.twC-RnBHWgdpaN4HNMwZ5wvWNYYV_ECWZGiqwd7ZOGLntwX1xuhtu8Jl32e4cTpxIrr0dhU6fOCPALYlxPxYAMjnqva79LcESTf12xDcY1rbYIRSgOX_o2YhqiiGvBAfOUMpVhmikCna1wVlBcZhLS6HUFmQAnsS9yPE3nWg-qEA1-j58fXho8MCJ0zkc1YnKz5I1tDTHrhm1NIJHzGdHEypAGnkwLdV6gVSJWiKXWRGZlr1NAglc2TfuGN2kFYiU02x7sYsEbmmC4vVXQAbL55L_3pap7ZESOtwDfsZSmQ_YBIMxdlOmyr0oGsqIVcNggIPw39CkrrRFchHjZMAEQ", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiMzUzMjM5NThAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiQWRtaW4iLCJsYXN0X25hbWUiOiJVc2VyIn0"}}}	2026-03-05 01:35:24
9VZHVp0hb1IZpu4MuUSxA-omW5FePt3U	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T05:49:28.735Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772174968, "iat": 1772171368, "iss": "https://test-mock-oidc.replit.app/", "jti": "392414bd212c9f7c235796f2812bc001", "sub": "test-user-123", "email": "test@example.com", "auth_time": 1772171368, "last_name": "User", "first_name": "Test"}, "expires_at": 1772174968, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTcxMzY4LCJleHAiOjE3NzIxNzQ5NjgsInN1YiI6InRlc3QtdXNlci0xMjMiLCJlbWFpbCI6InRlc3RAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiVGVzdCIsImxhc3RfbmFtZSI6IlVzZXIifQ.ZfswRhtG4f7_5x2A6QylOsDUJy6QfbiqI2pfar2zys_F5QQbpZrjpoU7BAcoOhMTFanYikDfePkenO4v32PuL1v-t1Pmv2CcJ0ClPYZ3lWO66dA0BiW6OJpabUV_XrPYQW6ubuUICavLqVB6omkKLFjZh9f69r-UptUXJfsq72MYzEgGBmtamNokUW0S363ljf9g9ATFkYn8VHVM7vU-Sn864I5vtfOrLVRCuL0ldRRkkaVdiktQQY97cQrV2hcuMy49UqSGJIdhyDglSpRO4kUxe6Kcr1oSRgL9sQ4nplmiehCYJNbwVKGRwZ2NIuf7WtE_8xjc1JlIbEFfUte1oA", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItMTIzIiwiZW1haWwiOiJ0ZXN0QGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IlRlc3QiLCJsYXN0X25hbWUiOiJVc2VyIn0"}}}	2026-03-06 05:49:30
rKJiZsHdK5_JdlYPAxYY-6_YOAn7omO5	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T08:09:15.498Z", "httpOnly": true, "originalMaxAge": 604799999}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772183355, "iat": 1772179755, "iss": "https://test-mock-oidc.replit.app/", "jti": "bce7fb3dd57aa5ac73597e0dfbc4aeea", "sub": "Z1JoTp", "email": "Z1JoTp@example.com", "auth_time": 1772179755, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772183355, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTc5NzU1LCJleHAiOjE3NzIxODMzNTUsInN1YiI6IloxSm9UcCIsImVtYWlsIjoiWjFKb1RwQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.CiFkMTH-sJOgEfw-nfI2FeMJsujMjhVsod2yDzCdRe2dsI1_FEYQhN-OEFyrNTaVqmOOwGMgVg0myZNnfrXaO4poksB3nNdODe7TZvWJjAyszJRwZsR3tgvF59WcFEz-NyGr5wlj3FKtjH1sAN6DewsQKwhPShdBQrBK1-dPRAsP8oEKRjukrqyJIdyufYw2VIc18pi5cO_m7byO5wycvdO3Llz-pQZrkKBS1utXmGQWfHFlqNu7Fj_52MQVUr3pZNfqp82U4SnF8850BX2QUluiFtUVPUdq-n0T5-umP-FNw0Xu1Lr9GQISq4xI_bn4p7ib-ESYcMWJJydf31XLlg", "refresh_token": "eyJzdWIiOiJaMUpvVHAiLCJlbWFpbCI6IloxSm9UcEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-06 08:09:47
Wwutp4jtx0AA284X7035y4-n8wRJVxew	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-05T01:24:00.737Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772072640, "iat": 1772069040, "iss": "https://test-mock-oidc.replit.app/", "jti": "af81bd0c51b36573e8ef26bd3252e512", "sub": "35323958", "email": "35323958@example.com", "auth_time": 1772069040, "last_name": "User", "first_name": "Admin"}, "expires_at": 1772072640, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMDY5MDQwLCJleHAiOjE3NzIwNzI2NDAsInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiIzNTMyMzk1OEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJBZG1pbiIsImxhc3RfbmFtZSI6IlVzZXIifQ.nlE-0gWP43mtFQTcoWxFJynEWDqrzoaGk9FaLh6w6DicLzShlnVH42pUZxyhq9TJig64a0fGKO-VgANuZfak8PskICvAPdDvM_9enk1OBM8V5IYbwjI9O2LiQuFQsrXASNZ6BYVl2yGMiglUi2kMcIW-zSpqawlv3fDQkczLcEGLXv57XGiHSCdu1RT9ECYDlsvUN7nNLvcdkyhe6uE2BYiXknlJzwuaaEMk6WaV6cPbkDJu2pgmuhTkm3ue8UasrB-Ro5AHD1822kOJpX8N3HcLWFNVSk6_0AmEmdNcIEK68hSObcHWRcMbWPR-p1XcfB25QLPBardAH6Sa3ybWUg", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiMzUzMjM5NThAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiQWRtaW4iLCJsYXN0X25hbWUiOiJVc2VyIn0"}}}	2026-03-05 01:24:08
9oGt8VPTDI8Ic0qJuA3jxA32kfqdiIrd	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T09:12:21.515Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772187141, "iat": 1772183541, "iss": "https://test-mock-oidc.replit.app/", "jti": "d9ddfb448c94472a8a22b04a326a87d9", "sub": "pIDdI2", "email": "pIDdI2@example.com", "auth_time": 1772183541, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772187141, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTgzNTQxLCJleHAiOjE3NzIxODcxNDEsInN1YiI6InBJRGRJMiIsImVtYWlsIjoicElEZEkyQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.YmmclbSF5omY6PZgSEtJe9GcLFHbXaeQizbyN10KGSM86qtiaYgAYTYJ334kuMmuIUVAb_nzna6Fy3-x3ryxOnbdvDIKopvPgkIRsZ03xiQPjg-SwT24RryBTY1lQCTP69Hj6gXjn9gyEV2qMkqX6cadtDzSab_9NHszQ_KtMnGgfHY-NfCXkajkZFnQFybxDng-JzMwOJvoPk9oOin2LcC9HYaK9OtIKt6bTLTHREda6GWAyCq2-jH37OcO8QcbNDTu0jVcdufvp4WoPoH2wzBejYSDppe8QN29KoF4G9s6FUBRtiY6e771fq52zlfyrk8_UWY8YqMv9IXQ2nQ3yQ", "refresh_token": "eyJzdWIiOiJwSURkSTIiLCJlbWFpbCI6InBJRGRJMkBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-06 09:16:02
qCZoyhGfcCVqTZol8AeoBBtT1G3a2wkr	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T09:08:18.560Z", "httpOnly": true, "originalMaxAge": 604799999}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772186898, "iat": 1772183298, "iss": "https://test-mock-oidc.replit.app/", "jti": "eaccb6bb8477b93885a9f55bc7bbdc43", "sub": "j69UEF", "email": "j69UEF@example.com", "auth_time": 1772183298, "last_name": "User", "first_name": "Admin"}, "expires_at": 1772186898, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTgzMjk4LCJleHAiOjE3NzIxODY4OTgsInN1YiI6Imo2OVVFRiIsImVtYWlsIjoiajY5VUVGQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkFkbWluIiwibGFzdF9uYW1lIjoiVXNlciJ9.tp73b7vk8rj-fL0OkiGpiQXo1j-p6TwfeM4HMgXpJdaXqRCe0GfOOs_xkoLAVy8CgUq4QvX9MbZCgVU4tssmZthGGr6uZaBvWNrZYDL-54aRguyOFalVVjyoz8-qbRO_olVpgwlF12UyMJ1VZuSqu6FTFHPa7PWoKzptIfZfWnqfTn8vus5HDrVaiI73vA9fmP4xL_m4evWTkQg-ogA0WL8nbZxhvs-CfhJElpaSsl_ZhTD32ZrYLIEeshOgACppiRMIE_hfJnZM20di-sOz8aAjI_ljOav_sTtpUnTNcSXeDronqlubCR7-ImmsIfKVBN1__TuPigvupjDZDRW15g", "refresh_token": "eyJzdWIiOiJqNjlVRUYiLCJlbWFpbCI6Imo2OVVFRkBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJBZG1pbiIsImxhc3RfbmFtZSI6IlVzZXIifQ"}}}	2026-03-06 09:09:38
pU8cpiRfEyjq8F-VAReJ3nfnSZG_i-E6	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T07:04:42.064Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772179482, "iat": 1772175882, "iss": "https://test-mock-oidc.replit.app/", "jti": "c440bae52e58245e27c1e81e2b67613f", "sub": "test-user-42", "name": "Maya Johnson", "email": "maya@example.com", "teams": "", "auth_time": 1772175881, "last_name": "Johnson", "first_name": "Maya", "profile_image_url": ""}, "expires_at": 1772179482, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTc1ODgyLCJleHAiOjE3NzIxNzk0ODIsInN1YiI6InRlc3QtdXNlci00MiIsIm5hbWUiOiJNYXlhIEpvaG5zb24iLCJmaXJzdF9uYW1lIjoiTWF5YSIsImxhc3RfbmFtZSI6IkpvaG5zb24iLCJwcm9maWxlX2ltYWdlX3VybCI6IiIsImVtYWlsIjoibWF5YUBleGFtcGxlLmNvbSIsInRlYW1zIjoiIn0.tKcChV_5-VM19cforMaCt63OcsG5XDTdW3fKKI4BjKY_296h1_h_cwPuvKnbAAnQi1LWoSv9I6-ppg_czzx7O3Oehp827jQJBFdYV-RR7CWu_TDK5EPa7KTJmF9Ys50nTyqqkhC4bWZNxaBLK7capKX6TsxVKzbueIHFEMbwFWkO5ZYvt438Lfv2wTWqCD6UrMrHuoxAT55krlbOMtCqKBv5qwPD6urcCyHmWlyKZXNL-hjV71wvK0Lg9R36XaPgNEc5jv84ybAa4y1Nxi3EiQdr83uUheOXB7GXT9g26t9UA-WxEQf09DpPZaIedz9l1meqcc1cD-jYqjDoVSjEDw", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItNDIiLCJuYW1lIjoiTWF5YSBKb2huc29uIiwiZmlyc3RfbmFtZSI6Ik1heWEiLCJsYXN0X25hbWUiOiJKb2huc29uIiwicHJvZmlsZV9pbWFnZV91cmwiOiIiLCJlbWFpbCI6Im1heWFAZXhhbXBsZS5jb20iLCJ0ZWFtcyI6IiJ9"}}}	2026-03-06 07:04:59
97w5ErYDBTGdZtXEOWNMhuDBpp-heKKW	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T09:19:27.233Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772187567, "iat": 1772183967, "iss": "https://test-mock-oidc.replit.app/", "jti": "10f0de73f60ea35ba7bb9d32f466f24d", "sub": "Jkp87u", "email": "Jkp87u@example.com", "auth_time": 1772183967, "last_name": "User", "first_name": "Customer"}, "expires_at": 1772187567, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTgzOTY3LCJleHAiOjE3NzIxODc1NjcsInN1YiI6IkprcDg3dSIsImVtYWlsIjoiSmtwODd1QGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkN1c3RvbWVyIiwibGFzdF9uYW1lIjoiVXNlciJ9.pyY4to0yz1PZyvssxHWFSkKDj3GR8KCLz4ViWegsncjPeGGXux8yYNkpaSOnohypIDUKsdg0ji3DS6Ps7XKJRMtMYm8v_qwupH3jJXK4VX1iEzM3ReEsr-zTxiQlVeE8YNP0Mk-A5LhAJ_g3Cr3fnyEOOOJTnL9SDLBhUjYEQMNTCidHM9RWrzQXjGtg0xAqt4aapoo5nJfHi4qZDq1Vj09SF4p0j3X2lvVQ_P9AHw3Yh5Fhn-tsIUi9wnBOIDyb73xzwusYRRa-uuxuV8cSSbhO6Tq9_mQkZP6xUAEDw50O6LlgD3q8qK9ZYmRqOOeuAXeO9nyh64vdTdZSgMIsRA", "refresh_token": "eyJzdWIiOiJKa3A4N3UiLCJlbWFpbCI6IkprcDg3dUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJDdXN0b21lciIsImxhc3RfbmFtZSI6IlVzZXIifQ"}}}	2026-03-06 09:20:38
mww7vzTFRFvnr826RGsaY2DiPLLnoW7y	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T07:02:47.925Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772179367, "iat": 1772175767, "iss": "https://test-mock-oidc.replit.app/", "jti": "cfe1c63814fc61fd9d9a34228f81cee6", "sub": "test-user-42", "name": "Maya Johnson", "email": "maya@example.com", "auth_time": 1772175767, "last_name": "Johnson", "first_name": "Maya"}, "expires_at": 1772179367, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTc1NzY3LCJleHAiOjE3NzIxNzkzNjcsInN1YiI6InRlc3QtdXNlci00MiIsIm5hbWUiOiJNYXlhIEpvaG5zb24iLCJmaXJzdF9uYW1lIjoiTWF5YSIsImxhc3RfbmFtZSI6IkpvaG5zb24iLCJlbWFpbCI6Im1heWFAZXhhbXBsZS5jb20ifQ.lNPBRq-TN5OAY9eto8mu5-iUmzqtmaZRCnVV8zwlBGhuoleu3CA7r5u8G2D-MBu5tWms-g4DsC3RyWfxnpqO0MsZjrodVdQrFJS2QGgQ275VVS46gIyi1rdqRX5jTvTl84gmXAzdOSgcOEYnBmSZHNUn55DDe1kT90CeQz1sm6rxgB5zBqfVEX1Sq41Qcq2YMqns3dPUqWVGpgzwj8iqaLmflLdLZMXTAiman1aU96227hox1-b8DCAFYcdIJtV52NtZQnzlvRf58W3O-a9JYxNBFPiBpc4bgDlWqBgpFp8TI0SSe5TFeftekjX9oGDEC-IJh3FDDCs0kjWIXQJ6YQ", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItNDIiLCJuYW1lIjoiTWF5YSBKb2huc29uIiwiZmlyc3RfbmFtZSI6Ik1heWEiLCJsYXN0X25hbWUiOiJKb2huc29uIiwiZW1haWwiOiJtYXlhQGV4YW1wbGUuY29tIn0"}}}	2026-03-06 07:03:04
rQN6ALUs21mnL24i7DfYzLELXAY4hOLv	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-05T05:50:34.067Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772088633, "iat": 1772085033, "iss": "https://test-mock-oidc.replit.app/", "jti": "581b1840a556c9ef31ba16db3f3ed5ca", "sub": "35323958", "email": "pete@example.com", "auth_time": 1772085033, "last_name": "Doe", "first_name": "Pete"}, "expires_at": 1772088633, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMDg1MDMzLCJleHAiOjE3NzIwODg2MzMsInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiJwZXRlQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IlBldGUiLCJsYXN0X25hbWUiOiJEb2UifQ.IcqepyHSnJTiQ3BJhI_bu2AcBW-fWdZK8iIKK8N_MZCNh1U3dNVXvw7G1uEDWxeqIZZInl5Iq1QHtuLTBdB5waiWV2liTLLnBwFeivOXECxpT6rCOFnfrO_l4o9VFjpEfnsHOcodqNuHVtlgVdCfSFw7L7rJ7OCwh-xx1Y-SZBt9QtJTW8mEZQraLEVxJ-5GEoPQN3WMNTx1rNcJx7g9EOUoYMmIm8yYWG3gfPI1JMEWiDPSyQC86giRH-glSxY-nVzgWfFFstq3RmmY0tAtd7RHOUi9_K1PDEMUUzSs0Pzhwl9wD-lwisS8wI1yxXwNd5HUvVBENCnTQoNLEWVI2A", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoicGV0ZUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJQZXRlIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-05 05:50:35
haytNZv3h5lKbed5QyzA0SjwcYeRWkxt	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T06:10:29.814Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772176229, "iat": 1772172629, "iss": "https://test-mock-oidc.replit.app/", "jti": "080e4fbfab3b25903e9ff46d94af17bd", "sub": "test-user-42", "name": "Maya Johnson", "email": "maya@example.com", "auth_time": 1772172629, "last_name": "Johnson", "first_name": "Maya"}, "expires_at": 1772176229, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTcyNjI5LCJleHAiOjE3NzIxNzYyMjksInN1YiI6InRlc3QtdXNlci00MiIsIm5hbWUiOiJNYXlhIEpvaG5zb24iLCJmaXJzdF9uYW1lIjoiTWF5YSIsImxhc3RfbmFtZSI6IkpvaG5zb24iLCJlbWFpbCI6Im1heWFAZXhhbXBsZS5jb20ifQ.DO0WNMvgwQ-sCyBdSlpQ07VdCZ3-Upv9zxUPNiGyrosejjPbc6uCqWqvnHT-oayyRZE1A7gQc2kjsKJDHUk2RkcAPOa9SrAPlnng58fCThY3GVQOrev4be9H2YLBWGjFPj94TwsuzX_NPSwb81sPC-452vAhGCrmKxrDB39gQ8ZM7WvDlXyMilsr_LXYhqyL5zVtPjP9gDTRTbybjC_Yy74uGjh7_k2Ak6KPTCOeeZxehzg-XpY-664nkQ7YTYR13wHYSawp92dt6DnGoJoVMAYhV3vjvUS6D4wqSszrioTPbsSPWaPNTDPwSHp0JTSFKfYK5SoIqXuCUh-0B_YbiQ", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItNDIiLCJuYW1lIjoiTWF5YSBKb2huc29uIiwiZmlyc3RfbmFtZSI6Ik1heWEiLCJsYXN0X25hbWUiOiJKb2huc29uIiwiZW1haWwiOiJtYXlhQGV4YW1wbGUuY29tIn0"}}}	2026-03-06 06:11:29
7utUyzJ9BYNC0vTM_0FXVmEMWmTIwgw2	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T05:35:03.683Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772260503, "iat": 1772256903, "iss": "https://test-mock-oidc.replit.app/", "jti": "d32302b05535b0ac3dc0320d9ab2710e", "sub": "Wc93iB", "email": "Wc93iB@example.com", "auth_time": 1772256903, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772260503, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMjU2OTAzLCJleHAiOjE3NzIyNjA1MDMsInN1YiI6IldjOTNpQiIsImVtYWlsIjoiV2M5M2lCQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.DlH5f_aCrrfxC8zquKux_GOtYq4OWXruxyOOBP1R6wDzuVlBn2buKdLbmnNELdN7jIdJ2HnklSz-buv0yiJm8M0PDv5uYxLGymkBmUL1FNfOBOH5sbjmjXbF-a1OMf8-k9O6gCX-avBD-j3zG253Kx0-OuOxq7_xm96b0E5tPioujmZMxgveSKZLQgTmHTA-V5Ly1JYeLKMoOInuFAJzZUIo5BAc6sLRBT_TJu1mHMakMG5hEtEiU5qtAetqg6FpbDGBVCZEa7E3NBAjEaxMHW82JlYKHXKSC6e1EpsqqTR8JJBE0TmaadNzqwzj6fPtvocPMwv47_78jJ0rTM218w", "refresh_token": "eyJzdWIiOiJXYzkzaUIiLCJlbWFpbCI6IldjOTNpQkBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-07 05:37:23
B9pKyO8iuq2P_ZbtbU7rEAv8ZkbrfmbH	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T06:37:22.589Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772264242, "iat": 1772260642, "iss": "https://test-mock-oidc.replit.app/", "jti": "cdee4b94156d6cee0b38cc09fdf909d2", "sub": "admin_SyQ1", "email": "admin_SyQ1@example.com", "auth_time": 1772260642, "last_name": "User", "first_name": "Admin"}, "expires_at": 1772264242, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMjYwNjQyLCJleHAiOjE3NzIyNjQyNDIsInN1YiI6ImFkbWluX1N5UTEiLCJlbWFpbCI6ImFkbWluX1N5UTFAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiQWRtaW4iLCJsYXN0X25hbWUiOiJVc2VyIn0.HRT_UWkL0FkyGKzqJqqB_u6RbMe0aIy-lla2p9cludtEYxdREO907oN5f5W8WkWOZlt_Oez8bKqWN_7CUwQpJWac6r3BBsh5Cc_KNLO5iBWwkkhKTABzkAFJOPhTuwiEu35g5QCkh_ppVy6XiJbzKoJU7TAVkxAocPmK3ZwiqoD9bqi24BWiFlp3h8p6ZXKgT8NuW79PP7KXaptoPpCLmYDMrvv8CckGdyjS9KNSrPimzK3OExIHKWZtOzFbx1Y7I3CWnFKMPVm2r_JAgCo7GxSQZwDi_czPRQkx9R575kEI9rvsAotljM3himOCAolqLhzMM3Bp6FeKO-wLn1uzEw", "refresh_token": "eyJzdWIiOiJhZG1pbl9TeVExIiwiZW1haWwiOiJhZG1pbl9TeVExQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkFkbWluIiwibGFzdF9uYW1lIjoiVXNlciJ9"}}}	2026-03-07 06:38:15
0Wg0drLAipXkjV12w1gxO3nM_cxz_l_E	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T19:18:50.495Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772309930, "iat": 1772306330, "iss": "https://test-mock-oidc.replit.app/", "jti": "9741678cbf40b7e5edd9859dff7ba2a2", "sub": "1udX-Q", "email": "1udX-Q@example.com", "auth_time": 1772306330, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772309930, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzA2MzMwLCJleHAiOjE3NzIzMDk5MzAsInN1YiI6IjF1ZFgtUSIsImVtYWlsIjoiMXVkWC1RQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.Hmt3E6vm4FoTktgE8WQZCLq7o6GCGLRjxEcQnzSp1xhIuQngbO9F2zSkJKaT2qRCXqGgz4iKP7fSXwSYAIMWETg9_4mhFhznr4LN6_MRSgS92NSDQCcoCwOLXBBtztar_9zfrabFSqTp7WDrFWT6jeILqgm7PLaDcMV6odl-UsIXNyuhhRNbGRbQAisFhczQgaSUVZCG3TS2S4YcnYAXdgXmTH-dupOG717hoWYtHDtuFM_QUxxgZgH8d4Rdl-EDvon8_RTu1Dfp70N9mgxcjTKKpaE6j0HbNWHtSMvGtE6FxgIjJpplHQj2s2r8TVew6_cfbvEI4kXhCG6kRuFgPg", "refresh_token": "eyJzdWIiOiIxdWRYLVEiLCJlbWFpbCI6IjF1ZFgtUUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-07 19:19:43
ZXl7IqPnq30V3y2OkTEhKT3wo550KQKv	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T06:14:10.137Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772176450, "iat": 1772172850, "iss": "https://test-mock-oidc.replit.app/", "jti": "973053853d941e6edd3760110e5640c0", "sub": "test-user-42", "email": "admin@example.com", "auth_time": 1772172850, "last_name": "User", "first_name": "Admin"}, "expires_at": 1772176450, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTcyODUwLCJleHAiOjE3NzIxNzY0NTAsInN1YiI6InRlc3QtdXNlci00MiIsImVtYWlsIjoiYWRtaW5AZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiQWRtaW4iLCJsYXN0X25hbWUiOiJVc2VyIn0.LpMHIsbDF7WXX36RD46Y6q865F_GZxdR9a6eUtQDcCqIPu3Bf6-snK6wLoKJRDoEht4upGq93MpjkGz3yoX1-F0dHAC6NsxUh4JA35rXBNmOcD9a-Zs8Hd6Cjv2B8iQt4EIKXIWyc6Rlmg9L4igVg-UCvdbrLeI5vXVFf3Op_n1yKQrOw6v3nMZkUQFsXT-b1Pg3UPr3gqOc4cADq8YXhS2fbnynA5b0tmCVyORU_15Czf_ev2073_1I6i7VraL9RhpOp1RpptMtfN9hpLBYMIJJKFWT6RTfJvgHFeOeTFqBu6LtVHtDjB88LogRmmIduS9PFdAfL8l9uO0ApgYgyQ", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItNDIiLCJlbWFpbCI6ImFkbWluQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkFkbWluIiwibGFzdF9uYW1lIjoiVXNlciJ9"}}}	2026-03-06 06:14:11
9lko0Vs3TWEiK3UjsZgAtFyuOIVLY65c	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T09:30:08.893Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772188208, "iat": 1772184608, "iss": "https://test-mock-oidc.replit.app/", "jti": "0e11f436bcfe40cd3deba544553f7a90", "sub": "tImpmS", "email": "tImpmS@example.com", "auth_time": 1772184608, "last_name": "User", "first_name": "Replit"}, "expires_at": 1772188208, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTg0NjA4LCJleHAiOjE3NzIxODgyMDgsInN1YiI6InRJbXBtUyIsImVtYWlsIjoidEltcG1TQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IlJlcGxpdCIsImxhc3RfbmFtZSI6IlVzZXIifQ.hBm9wwTUlyALyYkM3T-WPFU9neCBcMpFH-3Nd0UctXis0Z3N_NlOTAF8uIO3xPxIrL-KEgTSFHs9BfzS3syLR52G7tAprkHP4M2PJuOrk1o55GIrKv4xsyXf-JmMsnTtdgOjmAiGWMBFxFsuPNzqHFcedEClwCDsF3DLmsojGa3wrnusz-NJQJC16e4_3XvgQ-_PBQhAfnEkYJgIxILTR-mIVbT-jqQ4uYkjbUBTDvKG3O16o7RCdoiM-C3YMlO_PnUwBT7oThcPER0eTa5-RE_TpLdSHjs-5s93osQn0cY3ovkfDjNJvD0rPMnQ7cX1oPUgQ0qq9_jIr0mlkGzbvg", "refresh_token": "eyJzdWIiOiJ0SW1wbVMiLCJlbWFpbCI6InRJbXBtU0BleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJSZXBsaXQiLCJsYXN0X25hbWUiOiJVc2VyIn0"}}}	2026-03-06 09:32:10
crAR_MKfgR3VVB1J5p6EJndU5F85_qUL	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-05T05:41:10.269Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772088070, "iat": 1772084470, "iss": "https://test-mock-oidc.replit.app/", "jti": "2e6ae3145ac021374e856b8bec758448", "sub": "35323958", "email": "35323958@example.com", "auth_time": 1772084470, "first_name": "Pete"}, "expires_at": 1772088070, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMDg0NDcwLCJleHAiOjE3NzIwODgwNzAsInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiIzNTMyMzk1OEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJQZXRlIn0.ZMDJMWMprz-QHiQgWw1GTjWYJfRflo2UfhBOuaH4m6OTM3N5XfiHXp1hIY0wRK5ONINjEe2mYTfSuWKGeglyDs95q_AO3t4jxwCK4mG_P-smiUlgEGScGUTtASUeQVYxW6So-nn__wrSB002F7j4ixsA4ud3EzexuhuXPehcHILrAWTKO-fFNnV291_jL976rgHWRQ-d3mGzPLkI8BWQ4wFkQFIQ0AWG2tLnac6-8qqEYej3iNSUVu14WUYv-FNLMSdUSDMHZWzX1YpavhVgCAiod2jJ26AnjSWHl0IxkO21q1kuIx6ncU-4ojRiYQjquvYuEjp96mmROaVjA58QGQ", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiMzUzMjM5NThAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiUGV0ZSJ9"}}}	2026-03-05 05:41:28
6neV59T2LsEsF0rccNHGllupQMthOmuL	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T06:58:57.992Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772179137, "iat": 1772175537, "iss": "https://test-mock-oidc.replit.app/", "jti": "f2f2fc82fbb7bb3e27c8b24d2f83dcf6", "sub": "39646895", "name": "Admin Boss", "email": "admin@mindprism.com", "auth_time": 1772175537, "last_name": "Boss", "first_name": "Admin"}, "expires_at": 1772179137, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTc1NTM3LCJleHAiOjE3NzIxNzkxMzcsInN1YiI6IjM5NjQ2ODk1IiwibmFtZSI6IkFkbWluIEJvc3MiLCJmaXJzdF9uYW1lIjoiQWRtaW4iLCJsYXN0X25hbWUiOiJCb3NzIiwiZW1haWwiOiJhZG1pbkBtaW5kcHJpc20uY29tIn0.cigoAS12KlC--EYavB6jSF8sl8IfUAgbuq8967ofRW3NJWh40s0tGD00j2k21Ch1kQ8ToRbz3YBDNna1O-s6dqeaomXuFTEkM7YpO2eqBmT2sV9L4mAUfXja5Hs-G4PvQh2Jw40uibL-7WVzBWSHFFu1l6QBYpELFXfmNVhsRmy7JwcD1_LZnF9IisZUR6jUIh7dRDjMTNdT6CNah-nJdA0n-r6zJrbEqwEUQjNiZr-NcO9Tk6CzPB4qRtMjdMzY8Ub35WmHGy7LFS5NUrRtMtVHknbrP7VzlkcgAAW4u4iQGVRi2FGJF8nnduIl4uJJBDUzwzmP1yoJO2yuJPOWgA", "refresh_token": "eyJzdWIiOiIzOTY0Njg5NSIsIm5hbWUiOiJBZG1pbiBCb3NzIiwiZmlyc3RfbmFtZSI6IkFkbWluIiwibGFzdF9uYW1lIjoiQm9zcyIsImVtYWlsIjoiYWRtaW5AbWluZHByaXNtLmNvbSJ9"}}}	2026-03-06 06:58:59
owPzNVFKi4oh3HvWkKjx-Sk0KdN3NIhn	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T18:48:20.976Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772308100, "iat": 1772304500, "iss": "https://test-mock-oidc.replit.app/", "jti": "7d4d5c8fb3aba48ea974281773eca5b5", "sub": "xVhSzI", "email": "xVhSzI@example.com", "auth_time": 1772304500, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772308100, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzA0NTAwLCJleHAiOjE3NzIzMDgxMDAsInN1YiI6InhWaFN6SSIsImVtYWlsIjoieFZoU3pJQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.SXhPRkFavrbh4auPcxesyaASMKSbgM9E_mUsbgED2C6XzQD_fqfCR7dusBoezaHaiEYYnRlU4nfSVU6TK-PxAtZlKM1bPfJ7lj7dC_AMhCWl160lApPvzb3WMc0Yq0wtdjRY11S_0h0xWI3Itl81KDnM2OYZk0-ubUBDpNmXizySvLAUVh53IdhQiG7izrHyIYMSCIK8xaWvRF3B25PVQPTW6aBjUZtWB4ZM6QObPR8D7hT-FS4uICGjRs2KNQMVk4_cyWC8lZg59HLGBRS3UjeDt26w97XiTbCJPiun6e2CZ3hNWKJ3DtUa7-RQbIkneMMxuiCxJo2GAMgvcpX5iw", "refresh_token": "eyJzdWIiOiJ4VmhTekkiLCJlbWFpbCI6InhWaFN6SUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-07 18:48:23
SZWcttNIw-WoWUSjONC5K14ZaidrQRXl	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T15:04:53.492Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772208293, "iat": 1772204693, "iss": "https://test-mock-oidc.replit.app/", "jti": "8e336b7b0cf3f102048eb5c3fd726a11", "sub": "a_rJjy", "email": "a_rJjy@example.com", "auth_time": 1772204693, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772208293, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMjA0NjkzLCJleHAiOjE3NzIyMDgyOTMsInN1YiI6ImFfckpqeSIsImVtYWlsIjoiYV9ySmp5QGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.B4WFNRd5uIZgNxP44nTkj8o2ZJUvF0L5ya5JkvG0eILWZRvHRA4dXAY7oJgPhPW70VWdzUU8b_PdzAvq6je9JvxwG3GSYdfnGJcveKkZ7sviOIvDTzgzRFRJ02r-mvgx6oi-4-F_zjCyg0iP6TW6vYcjGzYAUXxgd9W1aZwgL52rwFQOqenOI-7xHiGiEwlK_k5r96rmHsWt2Dq_jtcOqoIaQAF1YOHxnNNlJYb_TlVgZaCMsbDNswxn231CaT2EY3EOh67G7r9OCUsQcWYrIFfkLZWf9XOKwUBBINKhC5LzJYdvD9ldLLsHrfeaAsq_imYp3Vw8A1ye6q9mvp2ObQ", "refresh_token": "eyJzdWIiOiJhX3JKankiLCJlbWFpbCI6ImFfckpqeUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-06 15:07:34
hZKM47oDgaWp5n5kJ02sUypM32wKANTx	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T09:47:49.224Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772189269, "iat": 1772185669, "iss": "https://test-mock-oidc.replit.app/", "jti": "1b3c07f80e9c0709ef3772157e7565c9", "sub": "9BmmO0", "email": "9BmmO0@example.com", "auth_time": 1772185669, "last_name": "User", "first_name": "Replit"}, "expires_at": 1772189269, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTg1NjY5LCJleHAiOjE3NzIxODkyNjksInN1YiI6IjlCbW1PMCIsImVtYWlsIjoiOUJtbU8wQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IlJlcGxpdCIsImxhc3RfbmFtZSI6IlVzZXIifQ.G3et2D1HH4N3HvZxkdA3fdcPxQoXCGijFME8fm1yIf8PfWswzEHbQLtMj8IiEXN--GXfEk7magTasIP6XcgW8XLN0l9hgYYkaA0IktOrCbl8uMqw6vE4rovZSaaoQauevVafV463T4dhEZGdv5EiXbYh0Q4LE2OTIzNK5vsohamAX9I3xoGleTLFl2xcYHCbwQ4QaerqxpT6UbpKMw2TjCwAk1_kwid1U1ChvS5p94MtNTzGzzti_L6avhQl3il2qJbg1bFCUoMpllRe-10oat7Dy_YC7QwxpBdu5BbHNPqfVfhJn57AjVMefPFIYBvdjo6KEVELamj4F4ujlu0qwg", "refresh_token": "eyJzdWIiOiI5Qm1tTzAiLCJlbWFpbCI6IjlCbW1PMEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJSZXBsaXQiLCJsYXN0X25hbWUiOiJVc2VyIn0"}}}	2026-03-06 09:52:02
MQ0REH2320pWgJ0GBTl0AJeGpgtwzD4L	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-05T05:25:02.602Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772087102, "iat": 1772083502, "iss": "https://test-mock-oidc.replit.app/", "jti": "3ba599c0ca8394d8ef7e84074c747238", "sub": "35323958", "email": "35323958@example.com", "auth_time": 1772083502, "last_name": "", "first_name": "AdminUser"}, "expires_at": 1772087102, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMDgzNTAyLCJleHAiOjE3NzIwODcxMDIsInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiIzNTMyMzk1OEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJBZG1pblVzZXIiLCJsYXN0X25hbWUiOiIifQ.o3nfUshsqBwPsoDSleq2_lma85nwJ6JYN4ytbxi7uGZd8nIS5-_fgVaIBTMJBHSRp8ZiaRJVWM5t3RPPc_GSnSaq1ikXCrDxixz6Su3c3VoRQPtcplBwf2xeDydadJoLxvCP3N6l3y79vPjSZSKtfSXdevJyG5h-lat9jNEQqrloqBTFSo-xILYPL-gy7IbgSs4fZTG7MWaeiQ8qo6cZVtFdgQn4zOQv7c5HEJV-Un7Sc9M2YaO3Iv0wsPfcuYuH3zTO3phYg_eLfjmaBn7htWN10J1NAYTk1nEiABe7VItVRumpbqeVvw1tZkTvd0hM1kiFVNfR0kl-6SnsdwKULA", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiMzUzMjM5NThAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiQWRtaW5Vc2VyIiwibGFzdF9uYW1lIjoiIn0"}}}	2026-03-05 05:25:04
DQh9padhAks1CKuZxmvyBDX7DSv1rZjQ	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T08:20:00.121Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772184000, "iat": 1772180400, "iss": "https://test-mock-oidc.replit.app/", "jti": "5811955abbe3124297b44553309ca388", "sub": "X5bqd-", "email": "X5bqd-@example.com", "auth_time": 1772180400, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772184000, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTgwNDAwLCJleHAiOjE3NzIxODQwMDAsInN1YiI6Ilg1YnFkLSIsImVtYWlsIjoiWDVicWQtQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.GHn1K47XQPKjpassEkA18Rx1JZKFwhEL0mRvFjPlk7c0YW5RSH9xMrwmpuGFCOoyGMrVKMuKOyLmYJPYW9LZGKdFTKRer-OIseXP-daw7CVeBHEMwdSVljnGOqsH9xZ_tWOz6GeFekyF7RVf2viRjN5Ca1DqoDzUCWskZOzEAIDYdgySCG4TckV5I71wdTZP3mERwQdT_witnPBL60fFWQ49ICFJnR3I041v2PMwlAK0mJpKo03O4tTj2FsdEdEjPeKRNIJiPdaBObRbhibUs3CUzYgi6CIb4VsZm35ZFzaFpzT6RcUSSSGhol3W16FkyeoExXaP1hv-ikwebb0J0w", "refresh_token": "eyJzdWIiOiJYNWJxZC0iLCJlbWFpbCI6Ilg1YnFkLUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-06 08:21:59
0hlISUX26aPthkmSazFxuBjKFSRfX6Rj	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T14:59:28.559Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772207968, "iat": 1772204368, "iss": "https://test-mock-oidc.replit.app/", "jti": "9bbca9947c1c241c8a2acc68e43663fb", "sub": "oU-UWK", "email": "oU-UWK@example.com", "auth_time": 1772204368, "last_name": "User", "first_name": "Test"}, "expires_at": 1772207968, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMjA0MzY4LCJleHAiOjE3NzIyMDc5NjgsInN1YiI6Im9VLVVXSyIsImVtYWlsIjoib1UtVVdLQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IlRlc3QiLCJsYXN0X25hbWUiOiJVc2VyIn0.xDd5QZVoG7VUKIRahhtGqu_3SE56Xd4drhGm1Fdj4dO0QtdbC7eRpSHq_2nHmdGbgxNAA_KfSv4HV4B97PClbOWeJvk56deSC0BtvGldvcb3-QuRQxUqz-PhtNmFLQji-U2v6NJh5dgd8mvCVo8oCAHtg50ddOsvq2dZz5KLvaXMo_6XGwH1h3QpR3eIG3JhDoOiy2LQ-QwY4X9M86BsktBKl4ZZPQ5aka2DCV3OAiiSoN349hu-Ykcs_HIIALBbiRlIl1lnTFHp2FjQbx7FkB3JItbd84uU_MB5Ma7qw0xTJMg4-QbFAk2QSybGqN-j0p6vA99sAGAUD3vUIVcT6Q", "refresh_token": "eyJzdWIiOiJvVS1VV0siLCJlbWFpbCI6Im9VLVVXS0BleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJUZXN0IiwibGFzdF9uYW1lIjoiVXNlciJ9"}}}	2026-03-06 15:02:17
BvNL9WGqLUnIjjssZv-R6nvUDhLNN1XC	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-04T13:37:43.042Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772030263, "iat": 1772026663, "iss": "https://test-mock-oidc.replit.app/", "jti": "064b27e7c7861642b64fcdf89ec83ad1", "sub": "U1mC5u", "email": "U1mC5u@example.com", "auth_time": 1772026662, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772030263, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMDI2NjYzLCJleHAiOjE3NzIwMzAyNjMsInN1YiI6IlUxbUM1dSIsImVtYWlsIjoiVTFtQzV1QGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.e00gN4IzcjAWTYHxwSVv-qmyuYwMJVRKsESaiglsc8N5zsDmQN5gjTupg4PVYqKjP6qE7ck5Kh02lDAYuonP5y31PaQGxF7j5xNtLP6s9TlSjmIri0Rj2dDiCeKdMaqsksk_UqprzRQy3QYWRsz3KW9vaWX_rfeF7SO-lsaySfADSC5MkY_kpsqJeK_WGuuWxcXcWjzQKhKotmfYoeAimfCT3poMMAbek1QPI5E8TA05sX_a1W-nKAMogyTzGHnyJVfuZMRbflbEgrN_lNAbibSD9Nb7LklaKo3Ekx2Y33zXaF3QYS5bKJUNGRp4lrKmmrB35q7uNok33lWxzfRfRA", "refresh_token": "eyJzdWIiOiJVMW1DNXUiLCJlbWFpbCI6IlUxbUM1dUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-04 13:38:21
TCfoHuEEsttSppMD91spHbVWz9BY11fo	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-02T04:00:45.575Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1771822845, "iat": 1771819245, "iss": "https://test-mock-oidc.replit.app/", "jti": "a7f7e8f5894901b859f38809d56a8f6c", "sub": "test-user-123", "email": "testuser@example.com", "auth_time": 1771819245, "last_name": "Thompson", "first_name": "Alex"}, "expires_at": 1771822845, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcxODE5MjQ1LCJleHAiOjE3NzE4MjI4NDUsInN1YiI6InRlc3QtdXNlci0xMjMiLCJlbWFpbCI6InRlc3R1c2VyQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkFsZXgiLCJsYXN0X25hbWUiOiJUaG9tcHNvbiJ9.WCMJQhBgawCh4CrgVo2ZLVgX3AuYlF43UD-gErVwOCiCxtVO5lHyDWxclmUeMyI9GpLpP-Vc75mjKirSmZ19ck_jDtJp6-vonEUnSGHbgs7BYxb_0Nz6CtL__T0B1iQpG-npKm_dhcymLQVhDgdejVogIelBvbaECnCZ9BpnMv-gzt7XipVW-QOSEzp091O2lwNqfHfe1_9PIOsoORKptKhStjQSs54X-M6LPscEglqxnTXwP5rHM_0tj2wt9ltFNjdcmCgcAIdNzdj8xNmsV-bIqYhKXNgaDJjRI4nJNx0ilosYCyQDwqXxWgqZUzexJjR12NL9Uck1JXn2VNK_Rg", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItMTIzIiwiZW1haWwiOiJ0ZXN0dXNlckBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJBbGV4IiwibGFzdF9uYW1lIjoiVGhvbXBzb24ifQ"}}}	2026-03-02 04:01:49
XB6mGmMfGdWxQxQmspA_YxdDa3c-HLPH	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-05T06:21:51.108Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772090511, "iat": 1772086911, "iss": "https://test-mock-oidc.replit.app/", "jti": "44024acf5ed3cec7fbaa749ec557a628", "sub": "35323958", "email": "35323958@example.com", "auth_time": 1772086911, "last_name": null, "first_name": "Pete"}, "expires_at": 1772090511, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMDg2OTExLCJleHAiOjE3NzIwOTA1MTEsInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiIzNTMyMzk1OEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJQZXRlIiwibGFzdF9uYW1lIjpudWxsfQ.jFbrxzr_y_KtpqICEHJPj2H6TK9gg4GxuNzJXdd3wqMjOI_xM0PZu9Tmc19hzE6CH5gZhh7Bz8hFX3M7V41ZbM9ixCgXxH3E7ekWtU98SZ-SaGXTmW_YGUY9BlN1-Y79lkvYfK_b0PWUgMC9GBBnIo8yYD3CUEDPPmSE89UE0pA1UtP4izTzstT1-AqP5f7OKE-BsdSO4o3oOeKzASlgsCWV6C-edOZ35oFcnL_J7EKnuWt94CJ0NI_oEDpoiUPz2i0nGQmnPCMmrnx_NxwYkkJxtelGRoQAPK2L6rsnpDwCDVHApkaxUFfcsGcVteCfScQH1YjVjizud-reez_Y_w", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiMzUzMjM5NThAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiUGV0ZSIsImxhc3RfbmFtZSI6bnVsbH0"}}}	2026-03-05 06:21:52
2ILyQioaL24R4FRySlkohy9f_RpFImcC	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-05T06:24:08.703Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772090648, "iat": 1772087048, "iss": "https://test-mock-oidc.replit.app/", "jti": "717401280fdc72ffd14129d93bc41dbd", "sub": "35323958", "email": "pete@example.com", "auth_time": 1772087048, "last_name": "", "first_name": "Pete"}, "expires_at": 1772090648, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMDg3MDQ4LCJleHAiOjE3NzIwOTA2NDgsInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiJwZXRlQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IlBldGUiLCJsYXN0X25hbWUiOiIifQ.T2HlbTti5QK0r7JpFxBmbz1lI9EWAMCODbOR46toeJS47pt-EWYUQJOkcfe7soLVD6GVYU9j3IxtKwzmnMGPhXzyAdkZeG0qGeEAKC5W5AvzV0e0aqviuuWTTyaHPH2XW3fVEg0dG5QrCb_pkva1QPIurkjhcukOxbYE009cgHbGRoFiR413DVKH3mwm_SptM6KcLrb8GCQvQAR9plsAZ0qiZyq3EO6az8mApCxy_IzGhWQk9q0BY2Bhm4SCAs7d_h8aFim18aydVz0JQNAzOhCT-rSBj-i54nxxNoFP57554nDUFgFB1It8JRzqgfHywPPX2qigOLMDABi9KqQomA", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoicGV0ZUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJQZXRlIiwibGFzdF9uYW1lIjoiIn0"}}}	2026-03-05 06:24:43
cBcIH9p2ExpSh76sRIs0Boy9EISWpHoD	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-05T06:04:50.017Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772089489, "iat": 1772085889, "iss": "https://test-mock-oidc.replit.app/", "jti": "4d19831de5441fbd31f60ebdadd1994e", "sub": "35323958", "roles": "", "auth_time": 1772085889, "first_name": "Pete"}, "expires_at": 1772089489, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMDg1ODg5LCJleHAiOjE3NzIwODk0ODksInN1YiI6IjM1MzIzOTU4IiwiZmlyc3RfbmFtZSI6IlBldGUiLCJyb2xlcyI6IiJ9.mOsNdw8IramSitHRLM3uPb-ItwN0h9mi6mzoP23G7zaUQ_JP5QEwdJvO8_yiplyTu3JuiE-SQ3-3_rR-zxq0dbWdk3jETAguv--frZCU8WCfQ-RCVBzbCQBwurMN_yOVdnGg35-hZvRMSIxbim4ImzCSgP3ZoLCvmGJwVH6WTxYLS-r-qL98IxlJfCaZU7MH1sATYsWoPRNprOwb4l3afQ18G-SSoi2Ju6s5H-h2drepvwXxZijw8nFr0UQmgBWtb536UBpAMBKYj9oJxLvRivUByCY2mKM7W8v-6bAe_6kl6VJ-OrHNH_t_x1E_L-bC_ZZFTJlXWMfPoagKh7YpDQ", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImZpcnN0X25hbWUiOiJQZXRlIiwicm9sZXMiOiIifQ"}}}	2026-03-05 06:04:51
X3-B1THJ69gtt4lF-fa65tWHDNQvaoJq	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-05T22:52:08.846Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772149928, "iat": 1772146328, "iss": "https://test-mock-oidc.replit.app/", "jti": "42cd11051894bafb607e5cf4b5ec6674", "sub": "35323958", "name": "Pete", "picture": "", "auth_time": 1772146328, "http://localhost:3000/roles": ""}, "expires_at": 1772149928, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTQ2MzI4LCJleHAiOjE3NzIxNDk5MjgsInN1YiI6IjM1MzIzOTU4IiwibmFtZSI6IlBldGUiLCJwaWN0dXJlIjoiIiwiaHR0cDovL2xvY2FsaG9zdDozMDAwL3JvbGVzIjoiIn0.xUbWTi5BQLMXKW8Zf6G4ey8_dPviida9AQoLZ71SxNTDrIGZMU8ZPT23J-ycKFihzYrS4YoevRdm2muYA0wthtl1wO9xWmYqtGD3b8AvqSzs8BkWYHGIvTKHjzxMVWqX9NoH4jAIEs_cjlF8GixY1kpS6L4pxv0mFl57bw1WsI6w9kNys6-yPLoAoHr3LdifZflX8INRRpSHqbC3LnMdeS5JaMN7CmDyYi6PVLSZ9uH_ONlPd2xeOSBJd7vbjR_eYxQcuEqyCs-A5VeNofVuaISQTHIDft6SCCk9J3deZX-ZTakd0Yyrf4qfgK4QydwQEbIe4iwjvW29CjAEcwcE8Q", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsIm5hbWUiOiJQZXRlIiwicGljdHVyZSI6IiIsImh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9yb2xlcyI6IiJ9"}}}	2026-03-05 22:52:10
FW3y0M5eliX9nIOb90FbVsp4UEngVKOM	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T09:13:52.957Z", "httpOnly": true, "originalMaxAge": 604799999}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772143800, "iat": 1772140200, "iss": "https://replit.com/oidc", "sub": "35323958", "email": "4980005@gmail.com", "at_hash": "knaCs3-F8L6qP4BNS8W7WA", "username": "4980005", "auth_time": 1771991262, "last_name": "Rej", "first_name": "Pete", "email_verified": true}, "expires_at": 1772143800, "access_token": "CAlsAYgLvzT_tgwrbVZT8eVhr2ORfB1ydW5nR87o8JZ", "refresh_token": "mjCUHs1LZEqNR1A80OKrr3FPWlnB43mRS6V-Ydp8y1g"}}, "test-mock-oidc.replit.app": {"code_verifier": "jIxU0vfmTLzEudEj3jPUn_1dgeQzy4S7IIM9u4kyV7Y"}}	2026-03-06 09:14:07
n0GdAecnqv0WkfaEclTQc6RqiaNanIy8	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-05T16:38:42.401Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772127522, "iat": 1772123922, "iss": "https://test-mock-oidc.replit.app/", "jti": "45aa6fa76496e96ecc40e404606ffba6", "sub": "35323958", "email": "35323958@example.com", "roles": "", "auth_time": 1772123922, "last_name": "Admin", "first_name": "Pete", "profile_image": ""}, "expires_at": 1772127522, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTIzOTIyLCJleHAiOjE3NzIxMjc1MjIsInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiIzNTMyMzk1OEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJQZXRlIiwibGFzdF9uYW1lIjoiQWRtaW4iLCJwcm9maWxlX2ltYWdlIjoiIiwicm9sZXMiOiIifQ.V8w_85OtkBOnWf-5IRhiTkBpw0r5CfF3ygJu-cRDKsv3PBx8bllwE7WCNy5XgKfymuj1MXOC6gDqJZFa-mwdYFioGaEPXpmXGyjWUZeJECc4RLGOTKg3NWHDbqlqHPxdPkLAlOCcudM8ehQjoaQ1wviBst8FSFLhRwSw38EBq-gIezD9_VoJtO7iXrplMLxXykawuGIEgwpHLoYxPIxfni0BSLgIXB1huFVY8WpGOxPPEZJQ6c31DJkdsYD6ZIluVGcqDaVIT-pGtH7I_GnWYZvwYy37ZkCMSY1rcZQXxBR_zKzBRS33MLqYh7C2kpsy1L--uuYFMnKWZVOpiD67cQ", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiMzUzMjM5NThAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiUGV0ZSIsImxhc3RfbmFtZSI6IkFkbWluIiwicHJvZmlsZV9pbWFnZSI6IiIsInJvbGVzIjoiIn0"}}}	2026-03-05 16:38:43
5BlFAtWVj2t_STXP3DZDg5NFOwdBgdUM	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-04T13:57:07.738Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772031427, "iat": 1772027827, "iss": "https://test-mock-oidc.replit.app/", "jti": "38fdab7401c5839287d5dc3573bc6d8c", "sub": "VaoZ0a", "email": "VaoZ0a@example.com", "auth_time": 1772027827, "last_name": "User", "first_name": "Admin"}, "expires_at": 1772031427, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMDI3ODI3LCJleHAiOjE3NzIwMzE0MjcsInN1YiI6IlZhb1owYSIsImVtYWlsIjoiVmFvWjBhQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkFkbWluIiwibGFzdF9uYW1lIjoiVXNlciJ9.iNhhQPdmXxHm8vxAxLwlrw3XEBHhmyV1zx_RqYkEAoyWgeFDBUrAYstS9dtFDQ0WefoajbocEZzc0XClcGttyNiknX5_koaQoc5VjQJu6IbqV-FrJLWAifPYvUZNWos7xeU6wdebWaiFQW96Sq1TycAyxcvWBv9QJwgxkNxjwTiE1JJPYE7R1_LOf5RMrRkbm0kpJO6srpVDmMwBHdsAV0I-0QkDxX61zDMgD4STOUo_zLztS6R5HrwwMG8lv9HGocw9e2VMJzGGbsh-KZrr5cybkhKBUhnurDvxzpfSstpHkVz7GS2LI9_1UFziWXw1WGtDGWe3oF0kXqlpAaa9Zw", "refresh_token": "eyJzdWIiOiJWYW9aMGEiLCJlbWFpbCI6IlZhb1owYUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJBZG1pbiIsImxhc3RfbmFtZSI6IlVzZXIifQ"}}}	2026-03-04 14:00:05
p42cbXj0eEIdf3h3vc4WUKwh0TmPcTsc	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T21:42:14.956Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772318534, "iat": 1772314934, "iss": "https://test-mock-oidc.replit.app/", "jti": "6b73a99f55cb2cc9947300b1a046130b", "sub": "test-sweep-001", "email": "test-sweep-001@example.com", "auth_time": 1772314934, "last_name": "Tester", "first_name": "Sweep"}, "expires_at": 1772318534, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzE0OTM0LCJleHAiOjE3NzIzMTg1MzQsInN1YiI6InRlc3Qtc3dlZXAtMDAxIiwiZW1haWwiOiJ0ZXN0LXN3ZWVwLTAwMUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJTd2VlcCIsImxhc3RfbmFtZSI6IlRlc3RlciJ9.tyjxQLzXZUasAplI2ZlMJdpamnqfM00vhc7Zs1KkHHNTuPGt19_dmo7h0QGB_5gTrwJSV6tCqDWQPxkt6V-fQsSJFKNuG_z5NVTVqupwFM6se7Nd3mAGnkCXIsHywdcnjlMHtHTi_iwwe9TwxyHgNbq5yVfl8-iCipT2us7lNOcQnHPMzfckHqMTbajY0PUYK4SStkM90rPrOv0-TsH71OyQGigaLxIx6dJ5Jz5IXCrr_QnXCmmBKALlc4TJwf9aR6aNpmUhgkF4GITHTKheWDRroZXEJ8BSUNCLZq-xbVz8g-ee1iivgJZcwFoWFCupwI2rTEPJ9deITmgnI6TCeg", "refresh_token": "eyJzdWIiOiJ0ZXN0LXN3ZWVwLTAwMSIsImVtYWlsIjoidGVzdC1zd2VlcC0wMDFAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiU3dlZXAiLCJsYXN0X25hbWUiOiJUZXN0ZXIifQ"}}}	2026-03-07 21:44:33
k1d4i9w19votvHim5J9BHMdgJAzOff4R	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T10:08:57.944Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772190537, "iat": 1772186937, "iss": "https://replit.com/oidc", "sub": "35323958", "email": "4980005@gmail.com", "at_hash": "j6vss1JJhUPCMPfvGsnW-g", "username": "4980005", "auth_time": 1772172195, "last_name": "Rej", "first_name": "Pete", "email_verified": true}, "expires_at": 1772190537, "access_token": "FypBl_SitptVUPb8bnq9ROTf5tWjC-n7S_5vi2vKMaM", "refresh_token": "qpZJn-TISYoXl9C2C8vPnaf8tXFL7hyaZjFkp6kYpjY"}}}	2026-03-07 23:12:07
h97UVAYQAuZs2LCAhTERpeefb_Uen71u	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T06:08:49.974Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772176129, "iat": 1772172529, "iss": "https://test-mock-oidc.replit.app/", "jti": "dbe8e0cacb703f8ea60973d3be27b786", "sub": "test-user-42", "email": "maya@example.com", "auth_time": 1772172529, "last_name": "Johnson", "first_name": "Maya"}, "expires_at": 1772176129, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTcyNTI5LCJleHAiOjE3NzIxNzYxMjksInN1YiI6InRlc3QtdXNlci00MiIsImVtYWlsIjoibWF5YUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJNYXlhIiwibGFzdF9uYW1lIjoiSm9obnNvbiJ9.k4trf3af_kfdLtE9gT_sWjpQFTkG8GmXGKDOSrcyXBO7c88PsvyQkwYHcV8BYSRXxdBFYS3ofhLuNgpxOeot4JHb6eEr4XxX6GvyyO0dQ8BqAzfdqoKw3sqhxFOjYneX2tDh0ktOsX6Adh4wIqEokDbAxAS4M6V8uG48kU9jkVbklJ7Sk0tM3otx6_fvhuH66Dri1YqhBXfcxQ5_Jeho3H9j87N7nkgXZIPAK0peqSX_1YiUZait1QFGWZ_U3Opf5WIkmnmUE8H7yoCzE0Ojpv6sk2UeJTYpSDxbBzK08gfIYqo-fZADRWoWM0j7yFD5aMg2hhR9FuTqu_WfQnYh0A", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItNDIiLCJlbWFpbCI6Im1heWFAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiTWF5YSIsImxhc3RfbmFtZSI6IkpvaG5zb24ifQ"}}}	2026-03-06 06:08:59
cJ9LR_q6gktmJop_8kXSiQWFpEIfFNC7	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T22:28:27.917Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772321307, "iat": 1772317707, "iss": "https://test-mock-oidc.replit.app/", "jti": "15ab0ccef11f76b23206cfdd94a2fcd5", "sub": "admin-check-001", "email": "admin-check-001@example.com", "auth_time": 1772317707, "last_name": "User", "first_name": "AdminCheck"}, "expires_at": 1772321307, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzE3NzA3LCJleHAiOjE3NzIzMjEzMDcsInN1YiI6ImFkbWluLWNoZWNrLTAwMSIsImVtYWlsIjoiYWRtaW4tY2hlY2stMDAxQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkFkbWluQ2hlY2siLCJsYXN0X25hbWUiOiJVc2VyIn0.j-7wR2s9AmlQ662SoGk5NW20WNIQ1T6TyqjrhY17X9Xf4SOcEoJcudM-Xrdfg2C94sQpJhRh5aNmgdXODnWHBay2p45S-eLS_RqwQPS8NKJXUTzgA80LwPk6D3oWk4coFXllplIpW0aiOc9gsackRFNbHKB4xpKUFapkMKrdCU4vD-23_xyX8ijmjJkFEKO7dnnrgq_NK-M5-DjeVZP7FLqLgull6yck91RhyUZLRoCytzTRfc2xmbI092Dyz9VVOMDiQ3HIW3qagzwRA5129GZIixBuHnM7NgMyUcILAYrIQz2ncndPVfwvmQBzbNuZiVWdOspg9zkWOQUMl59X0A", "refresh_token": "eyJzdWIiOiJhZG1pbi1jaGVjay0wMDEiLCJlbWFpbCI6ImFkbWluLWNoZWNrLTAwMUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJBZG1pbkNoZWNrIiwibGFzdF9uYW1lIjoiVXNlciJ9"}}}	2026-03-07 22:29:41
lpu3tRNu9zIpiR_JVBHyYnzEjKlRGmoQ	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-05T05:00:46.213Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772085646, "iat": 1772082046, "iss": "https://test-mock-oidc.replit.app/", "jti": "ce2ab7fffe073a1d48135bb055ab2136", "sub": "35323958", "email": "35323958@example.com", "auth_time": 1772082046, "last_name": "User", "first_name": "Admin"}, "expires_at": 1772085646, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMDgyMDQ2LCJleHAiOjE3NzIwODU2NDYsInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiIzNTMyMzk1OEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJBZG1pbiIsImxhc3RfbmFtZSI6IlVzZXIifQ.TSTImTftuez-w-s3vq-51Q2fwF2ADxiSIVKiiHmSRh1rQq310yLc4f03kFApD3no2XHBo14GauIn3nPYs0YGlotUk2gdfWQKavM02TOhZPI37wcIoT1QCOBfMS_IbN8a7IPtyylZl9gHXawK1UVrZCqKaEJG3RPjJwdNxY2K1oBJC-kFA4kftXhmdE8LGoIqO4nDKkw7WP_kXxOixCGK_L8XpB_Ool-i1xdmspOMuvBX0fB0LL1ybfTlMkn5NcKXzlxhEurrlomvix1q33nQ4zRHM82SLUzPArLVqmrY3AaKbLiUrgBI2UjtInQfom67QE28i0elWOh3Unchntzw3A", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiMzUzMjM5NThAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiQWRtaW4iLCJsYXN0X25hbWUiOiJVc2VyIn0"}}}	2026-03-05 05:01:02
xIb6uSUamKzntJIIuy0Nx9k28-FCYb53	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T06:18:24.880Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772176704, "iat": 1772173104, "iss": "https://test-mock-oidc.replit.app/", "jti": "c7a637dc4a36c008b19424951f0b1f12", "sub": "brand-new-user-999", "email": "newuser@example.com", "auth_time": 1772173104, "last_name": "User", "first_name": "New"}, "expires_at": 1772176704, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTczMTA0LCJleHAiOjE3NzIxNzY3MDQsInN1YiI6ImJyYW5kLW5ldy11c2VyLTk5OSIsImVtYWlsIjoibmV3dXNlckBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJOZXciLCJsYXN0X25hbWUiOiJVc2VyIn0.ky6T1COFbyh6hZauEEybRt1EVOjlL1ndW0X6QbiUXZisjSmD2H7stKI_kcBByGSFhmts7JkYGs54lESaS8568sSggKx9Hq3hxayC0A2L0dGTS5qFCQ6oLYuCo9P5uOzHa3AnrziF1FjY2PByaPRCmG7iwqaHESp0yt3oHUMN0gWlAiMkdMiQbYIiXpL3M6hHxOvkPU7H3RYEjWNE8Dn6sbZObm0pk4dTlqaVF8jandQ4jOUcupxRB8zvZhsW67Z8lfaGzzpKOef2dqtG33msFGW37iHiWlGd_BeKLUuFqX8hW73ypHO4fkawZLNGfPxUXyuyNTVCP63Ysu93bcfuew", "refresh_token": "eyJzdWIiOiJicmFuZC1uZXctdXNlci05OTkiLCJlbWFpbCI6Im5ld3VzZXJAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiTmV3IiwibGFzdF9uYW1lIjoiVXNlciJ9"}}}	2026-03-06 06:18:26
6PnLSwwHrlOW8EqORsKdXfC6HnYP_ysa	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T07:10:53.252Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772179853, "iat": 1772176253, "iss": "https://test-mock-oidc.replit.app/", "jti": "dcd95ee6b7e0a5f4926c5f7c5642d413", "sub": "39646895", "name": "Admin Boss", "email": "admin@mindprism.com", "auth_time": 1772176253, "last_name": "Boss", "first_name": "Admin"}, "expires_at": 1772179853, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTc2MjUzLCJleHAiOjE3NzIxNzk4NTMsInN1YiI6IjM5NjQ2ODk1IiwibmFtZSI6IkFkbWluIEJvc3MiLCJmaXJzdF9uYW1lIjoiQWRtaW4iLCJsYXN0X25hbWUiOiJCb3NzIiwiZW1haWwiOiJhZG1pbkBtaW5kcHJpc20uY29tIn0.UIp3TA0j_iYtMN6xVHZK9cyd7jPm3UxnsS5I9eVkQhvUvPeYzJTxlTy_D9CM0-4rqIUmpYOi-k2_-7cDYf2HhYAYc6W4cB9Mq7D0SDO8YT2GaD0ZRcZtFu8iY9KYPYH2ZC1-47ZVGgUz4nF1qLiZ4CAGxkECW6QF54LJJIzqDm0xoHrB7LxZABov6S66eZyY_K7pud2cve9R_s6HgnZG53vTaJoN1OnBEucRxSMsXMQAEbPdYnHlZ0HWeTZadTyWJtvpbtXBz0ODrsGf9cQA47H00lY3dKuhXbHjOFXJmmGSpA_T8_AWZagX_dk8ByygrB6Z3QTT_tq2QkQLvhodiA", "refresh_token": "eyJzdWIiOiIzOTY0Njg5NSIsIm5hbWUiOiJBZG1pbiBCb3NzIiwiZmlyc3RfbmFtZSI6IkFkbWluIiwibGFzdF9uYW1lIjoiQm9zcyIsImVtYWlsIjoiYWRtaW5AbWluZHByaXNtLmNvbSJ9"}}}	2026-03-06 07:10:54
LXRQrkzA2JjZVS9kd2EZaT-rOaiuP9kY	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T21:33:25.148Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772318005, "iat": 1772314405, "iss": "https://test-mock-oidc.replit.app/", "jti": "112b7b574583fd496162a68c2b52dacc", "sub": "test-user-999", "email": "test-user-999@example.com", "auth_time": 1772314405, "last_name": "Runner", "first_name": "TestUser", "profile_image": ""}, "expires_at": 1772318005, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzE0NDA1LCJleHAiOjE3NzIzMTgwMDUsInN1YiI6InRlc3QtdXNlci05OTkiLCJlbWFpbCI6InRlc3QtdXNlci05OTlAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiVGVzdFVzZXIiLCJsYXN0X25hbWUiOiJSdW5uZXIiLCJwcm9maWxlX2ltYWdlIjoiIn0.gXR2K6p8bnvTNV1urwbDjYtBAQr2lKnicldEjWJpDt9oy0zVUZA4GeRGtTF9vnhUpIZIUHfzyhzTWbVY0Xdj0gsiRm1NrsMcJq9jwQ73ofcslLQNJgti8wrEgBTJVAx3E6FAxi_wa-eOr2_wMjwExGCOEzrXhAAqd_kkr8mUzNSCajoUZRwkmdhoV-j118gmRY4-tzgVtD2ZjejXyrvy1NL5o5oJzDVONxZlbMMIuePcWHVADrGS-_sgtSfFYAAjxJ026fE80ICWdSCoGUKLRub4jDrnm30CFm0VZX8S_IH5nTUQSms29MGaj06udlvjR6RCybHz6SKQKQdtIpX9_g", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItOTk5IiwiZW1haWwiOiJ0ZXN0LXVzZXItOTk5QGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IlRlc3RVc2VyIiwibGFzdF9uYW1lIjoiUnVubmVyIiwicHJvZmlsZV9pbWFnZSI6IiJ9"}}}	2026-03-07 21:34:17
_fnzmU1kzARjMjm5uHaXSqQkUZpcnKuA	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T23:25:40.928Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772324740, "iat": 1772321140, "iss": "https://test-mock-oidc.replit.app/", "jti": "3925f61eefa45d4ae5f8e7598e141222", "sub": "35323958", "email": "35323958@example.com", "auth_time": 1772321140, "last_name": "Rej", "first_name": "Pete", "profile_image": ""}, "expires_at": 1772324740, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzIxMTQwLCJleHAiOjE3NzIzMjQ3NDAsInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiIzNTMyMzk1OEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJQZXRlIiwibGFzdF9uYW1lIjoiUmVqIiwicHJvZmlsZV9pbWFnZSI6IiJ9.khJwTocXYGfViz7roEOhGelMGha68c5Usk-iRIzfon1dt2KcuGJVkcws-ZtJjzPVYCiJ5FIFsKhG65rZAgKqcKkzGiIfeENUoMS2AzVB1eeMPv7kqBPOM74W9GyIfOawmvJPkkxqDECN0OmyeK9re7BW547QIf82z05TugLgk4EO53gP08aOBjI8MV55zQMfMxkC4_DYPY_qcYuLGMSyITNvA453xGigvbngDvEHIm_YjyK40z-mBeSoskbCF5OqdE0IfXbiaAlggaUCTfHxunPznDOT1gQdT-xsf9KmkgrzYaOXKMufhld0WnJW5l_NvbJycWpA45IDRNY3hCWr8g", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiMzUzMjM5NThAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiUGV0ZSIsImxhc3RfbmFtZSI6IlJlaiIsInByb2ZpbGVfaW1hZ2UiOiIifQ"}}}	2026-03-07 23:26:09
NhhlFSDl1DLLiSIkqKXwDv119wSFFxv-	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T07:19:17.716Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772180357, "iat": 1772176757, "iss": "https://test-mock-oidc.replit.app/", "jti": "4fd4e589231564bbb9f0fa96e998699d", "sub": "test-user-42", "name": "Maya Johnson", "email": "maya@example.com", "teams": "", "auth_time": 1772176757, "last_name": "Johnson", "first_name": "Maya", "profile_image_url": ""}, "expires_at": 1772180357, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTc2NzU3LCJleHAiOjE3NzIxODAzNTcsInN1YiI6InRlc3QtdXNlci00MiIsIm5hbWUiOiJNYXlhIEpvaG5zb24iLCJmaXJzdF9uYW1lIjoiTWF5YSIsImxhc3RfbmFtZSI6IkpvaG5zb24iLCJwcm9maWxlX2ltYWdlX3VybCI6IiIsImVtYWlsIjoibWF5YUBleGFtcGxlLmNvbSIsInRlYW1zIjoiIn0.oA0y2LChfvzGeH4b1Klp9H3TfldvzteGXdJ48-9cXF9Yan7j2ABQJbGLWs7GI0kSui1h_bk_n_r4ZCUl2gNLqx3vsSvloJ27qjrI3N-9Pjpa9KVZxV73N1TCFJAT98-FzjvEWxXDOL9pfUOGmiuNesyjW-ECfb0yWUfhLNJX7Qi1Fnir4pboJrPuBh6UCnp_nJpbh6WOswIX5eQ_ELnIHGw25LxMfyDC9cOInwGTuxEZUbX99Mhfu4u_S8-sjAIn1Xvof3rLbYftOUyPcJ1QCjffk2s4lIqHTdY1HFvH-KGF-ma5QvMinmCNCtMru9ScfgfDPhilu9ucfO6-2bdWGg", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItNDIiLCJuYW1lIjoiTWF5YSBKb2huc29uIiwiZmlyc3RfbmFtZSI6Ik1heWEiLCJsYXN0X25hbWUiOiJKb2huc29uIiwicHJvZmlsZV9pbWFnZV91cmwiOiIiLCJlbWFpbCI6Im1heWFAZXhhbXBsZS5jb20iLCJ0ZWFtcyI6IiJ9"}}}	2026-03-06 07:20:12
Kt-lV4bjy-vhn79K56F7lQ7ZC4N-LcIN	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T09:02:45.795Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772186565, "iat": 1772182965, "iss": "https://test-mock-oidc.replit.app/", "jti": "f2a1901d579167894454128d238a868d", "sub": "a8S2dP", "email": "a8S2dP@example.com", "auth_time": 1772182965, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772186565, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTgyOTY1LCJleHAiOjE3NzIxODY1NjUsInN1YiI6ImE4UzJkUCIsImVtYWlsIjoiYThTMmRQQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.ly_IChA-TBU4ahreNJ0_PrVVXqRZ9wrvl9OIltp10Sc1kua_wJ_G9gCZeypVtUPlj4M5L-Ae8uWM8r5cSktAU-Y0Kk95DuQiIS3I0X9EzAiGhc0roxvfJIIQbpx72QyBpp1b8xvTsrvOxRzQo21MQtndV2V2F1q3iXt3XwTTlusfs6Gn5xaV4-RqGZoyAa3BFykKAeIV26wZO7ICwhsjy6WL5ZVm1hnh0GAc-l-zq5UOQdT3d012fHbHbDZ96lkwHZGZoY8FEJ62iuQx1EMPPnbliCvcs1h-_v-2Eu-HNjwC-jH7-q4YrVCCiY78d8nbxuVcZIp33nBxhHDTGZHMjg", "refresh_token": "eyJzdWIiOiJhOFMyZFAiLCJlbWFpbCI6ImE4UzJkUEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-06 09:07:31
D5BRfG1jrxc6Ye-ayuvynLmXm4ghAWgf	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T18:58:17.683Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772308697, "iat": 1772305097, "iss": "https://test-mock-oidc.replit.app/", "jti": "88bc7ffd0bb01ccbd16b2ef61942941e", "sub": "aZw-6w", "email": "aZw-6w@example.com", "auth_time": 1772305097, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772308697, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzA1MDk3LCJleHAiOjE3NzIzMDg2OTcsInN1YiI6ImFady02dyIsImVtYWlsIjoiYVp3LTZ3QGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.Nnq11-oJpNPxcod4JGzSRhA4cbnylza6YkwqOFpsqNQW2GNXYnbrAE7oKsSPyS7xjpE0jleusnR8uLTPOvATi8KGAnt1ubDbsyhNe0ZX3wLuOXVFtYIT4Zkoc26kdeEPkTlVovj_mes1B90wEn-9v6TmH927OZr71SHwVH7CFivjVJuEuUn55IzSYSEV-vK5bzH2r8KyiYQ4-ESJklec05Vgepw22QvZ8HebLGIMrdKAtgRr1MPpF3jBY2pILTXIyJRe7NjGsWVpkSeH1OwKSsx8CQFyH0TNKwPSSsSwt90_OqRUCBtnJ6kJMDf79Rw5a0-fPqRk3AYOtPocvKcZ8Q", "refresh_token": "eyJzdWIiOiJhWnctNnciLCJlbWFpbCI6ImFady02d0BleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-07 19:00:24
kjJXtB3hbbgLNBMulHIWuZ7GBKRYXPog	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-05T06:16:22.703Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772090182, "iat": 1772086582, "iss": "https://test-mock-oidc.replit.app/", "jti": "3e5d976c6051ef456061254983d88000", "sub": "35323958", "email": "35323958@example.com", "auth_time": 1772086582, "last_name": "", "first_name": "Pete"}, "expires_at": 1772090182, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMDg2NTgyLCJleHAiOjE3NzIwOTAxODIsInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiIzNTMyMzk1OEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJQZXRlIiwibGFzdF9uYW1lIjoiIn0.icjzGRBdUyzOTW-fYuOtB_SHXeONtkDYB85jwSweQ4P5dw5lpSBa9scF2pP3M9H9rgb_HsyZWMs1HEnT9F7hek2twBCONIvL6DABpTa17Q_lCYv8xu63YqSBaQXl0hfK43HMhDAFT28nU5nk4cTHKct-d6wlet4OpHY9Mkl6d0ehkUpkvJFZt3r_jgk_49AkSxpP6qfNjzdjxD343Tgm6VNCK5lleXm_i1vpkjf3AtZ1jBw3fl58KRTPVgCyGDopYnZ5mBdVk18pzn-YTu1rCRjsjhfTSV3-lj7Db9IQVdTVDM411UHaLBJPEtxurjsKTWClzYbm7_jjF2R8zbCRDQ", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiMzUzMjM5NThAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiUGV0ZSIsImxhc3RfbmFtZSI6IiJ9"}}}	2026-03-05 06:16:24
f3B9ax-riwlNc-Wu3CsLOVhH3ghXOVcm	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T06:54:50.555Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772178890, "iat": 1772175290, "iss": "https://test-mock-oidc.replit.app/", "jti": "93cdeb123fc48d7125ce59b36b1a07db", "sub": "test-user-42", "email": "maya@example.com", "auth_time": 1772175290, "last_name": "Johnson", "first_name": "Maya"}, "expires_at": 1772178890, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTc1MjkwLCJleHAiOjE3NzIxNzg4OTAsInN1YiI6InRlc3QtdXNlci00MiIsImVtYWlsIjoibWF5YUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJNYXlhIiwibGFzdF9uYW1lIjoiSm9obnNvbiJ9.yjpS1a4kdYExD2XrIEy5cs15gvfdancdcqO0e1Nh2Zf2BlEszxzAr7ecfXSS_5s-Nsht-MH55x83cHJ9XdtODqWT8tdX0sD2tCIUewUmjiIKy54ERQApbF7F6OJUhqySM-ajR39QvxOqqeeyNjX5TuAkQ2WcfkimrDpbJrfZ_h9Fk-5uZMRB-fB9gSIxeaLsfWo889ku3NFKZgbNPlPcJW4CcKuAHFpv0kdDsePitPwfcOYWTm_gvQUBPMOhnz-3Gb6wV0yceT2k0koVHPOxd7xPtC9Ls-KRKIdnU3lqFSgmDXJHCMF5vzJ5xWuFvTT-9O3zYvXGNmx1mCPnZdo_qg", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItNDIiLCJlbWFpbCI6Im1heWFAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiTWF5YSIsImxhc3RfbmFtZSI6IkpvaG5zb24ifQ"}}}	2026-03-06 06:55:36
WAPwBiAWjKJC2UwcmiTy02Bz0F4ZMGvP	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-05T06:26:59.899Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772090819, "iat": 1772087219, "iss": "https://test-mock-oidc.replit.app/", "jti": "c451249e447c4c352f4c7531746d1154", "sub": "35323958", "email": "35323958@example.com", "auth_time": 1772087219, "first_name": "Pete"}, "expires_at": 1772090819, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMDg3MjE5LCJleHAiOjE3NzIwOTA4MTksInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiIzNTMyMzk1OEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJQZXRlIn0.HeiFNkmNjBYuzcocpoLEcKFBf-FLUsyw_jkCk6HfxtjCLKuPx7Sz1zXbqaiVGqJfFyyzoTKXTTRjNqzZuqHAcgEZB_RYxKQ13xyH9zXMmQ7ZghR1k72l7kfZhlZykfXBl2-sX0QaggFz7Zt5nWH_yrjMel3-VouPFL8voOk2olLvYmSLepYI092EYmmfX-_BzprlUNoxUUyqIAk5l7hmrQcUIR2v4zNRe-tADQStSDNhcTsYUSyWorGd55h2semz_BLgih-lt9uC2q6SIA22Io2yGjZxvWkxvrGxm2hrm3Vt-kdpGma_BzJgiI_GaPQDgibXjUEt7kw5zcXxPfZDfQ", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiMzUzMjM5NThAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiUGV0ZSJ9"}}}	2026-03-05 06:27:17
Hd-zJfoE5aGh-tOKAxvMHng05RgRf8sD	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-05T16:39:46.966Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772127586, "iat": 1772123986, "iss": "https://test-mock-oidc.replit.app/", "jti": "0ed764137594a34a465b9e6d96b15c45", "sub": "35323958", "email": "35323958@example.com", "auth_time": 1772123986, "last_name": "", "first_name": "Pete"}, "expires_at": 1772127586, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTIzOTg2LCJleHAiOjE3NzIxMjc1ODYsInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiIzNTMyMzk1OEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJQZXRlIiwibGFzdF9uYW1lIjoiIn0.EyuwFAeO0oOftyLIqHPa1Ttb2MsFOXdDzr1vl-tFc_EJoVzEr7jto79CbroEk92bwvwgcgK4bJflaMkxXvJHyjZTakSKBGdJhN-4LMQfm2xjIOUb8VzPXvOtmC8xTu-cI_hSqeIfe7LMRTAvHzxn_pV5fsxCWCdOiFuY9wvcXtF8nYxIQbGNr6tjnvfPEa7teQ1s9rtt3GST6p0QsFp1zGVcPRlLu4minWiaDIWUjsHHiaMdUSwUYqlx43Se3RDrWpBgc2dxLd8Ax1E5Xrtd_BmXxEgNjL_88fGrWmrVwryT_XytjR-TsMLplZDIrTPnGZJxejYhdkd_AfCYMgRUUw", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiMzUzMjM5NThAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiUGV0ZSIsImxhc3RfbmFtZSI6IiJ9"}}}	2026-03-05 16:39:59
Ya4SqgWkfwIem-vnn93tqOJ4bagE-Qdg	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T03:45:26.850Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772167526, "iat": 1772163926, "iss": "https://test-mock-oidc.replit.app/", "jti": "a2e01160eab895c4e2d8464dcd891d38", "sub": "test-user-123", "email": "test@example.com", "auth_time": 1772163926, "last_name": "User", "first_name": "Test"}, "expires_at": 1772167526, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTYzOTI2LCJleHAiOjE3NzIxNjc1MjYsInN1YiI6InRlc3QtdXNlci0xMjMiLCJlbWFpbCI6InRlc3RAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiVGVzdCIsImxhc3RfbmFtZSI6IlVzZXIifQ.ipD_Rk9iqWWvdhqJBR4-mnX08ilyfqJ0C6gwkUXsWF8nhUW33iCbSrLxJCM2PSnxP2ShhGecgAsctlTfkr4bOK_82KXDyokQWvs7BCaSlHHdCFj_FYsEnfroUPfX3WUoLkKehSXUE-rLhJKZakHTKW54TavWDm8rBKp53y7ZXokQqzLz8Y6MMg8-GG1ZR-NXIViHdti3b0z4-YlrnpbkplrTVIafVKSl0V5Cwwmh4QKA2tt8SjAJhR57V5kFgOoPp2oClbOgjZ5fk45D03__LFCRiZ9F2Xi7vc4ihXrwk7wkqRKpcN6zGJ2AZfQwSfa7ZCIYHg2R1oo6unQmFlBnbg", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItMTIzIiwiZW1haWwiOiJ0ZXN0QGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IlRlc3QiLCJsYXN0X25hbWUiOiJVc2VyIn0"}}}	2026-03-06 03:45:35
8U4VL3I8KbecOdqO1lTqQ8fe5fFr12xz	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-04T13:44:46.534Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772030686, "iat": 1772027086, "iss": "https://test-mock-oidc.replit.app/", "jti": "4331245f516680fda188724aee155743", "sub": "nH8jar", "email": "nH8jar@example.com", "auth_time": 1772027086, "last_name": "User", "first_name": "Admin"}, "expires_at": 1772030686, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMDI3MDg2LCJleHAiOjE3NzIwMzA2ODYsInN1YiI6Im5IOGphciIsImVtYWlsIjoibkg4amFyQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkFkbWluIiwibGFzdF9uYW1lIjoiVXNlciJ9.s0pW3xLLMfLzgZvGtyzpZpeRwqjlDU74Szt0JUE3M4H82tbF5_4psoxWpORQusx4nYWzxR3wWH7EXG_gCraGCdpeTAzH1oNhGWJ2PKFjJp5_iEwPshnzp5LhDitIEN2VisHC2bP3C-09QXjj4du9sStNlZWDOqjso6i4tTavmO-R2wnmZv9fRM_8pSY6Zf1gjkC6sdq75l67iHo_qlrSu7Str4k03jkX6fyZwYL069wK3t7RHwU2G63mL32TzC-MQ0s5bMrI-XhXTk7t-lfZSbvlElOToZ8LB5qGLI8lA05tfPfglUsP37xOhp2PN9c7MWVoSzaPqm1-0fH3cTYzgg", "refresh_token": "eyJzdWIiOiJuSDhqYXIiLCJlbWFpbCI6Im5IOGphckBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJBZG1pbiIsImxhc3RfbmFtZSI6IlVzZXIifQ"}}}	2026-03-04 13:45:36
IjGYGa08prXgBlc4mM7ro7Ek2OO4qBAo	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T06:17:14.906Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772176634, "iat": 1772173034, "iss": "https://test-mock-oidc.replit.app/", "jti": "7d1fe3b5e0157b04d64573d7089d64c6", "sub": "test-user-42", "email": "maya@example.com", "auth_time": 1772173034, "last_name": "Johnson", "first_name": "Maya"}, "expires_at": 1772176634, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTczMDM0LCJleHAiOjE3NzIxNzY2MzQsInN1YiI6InRlc3QtdXNlci00MiIsImVtYWlsIjoibWF5YUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJNYXlhIiwibGFzdF9uYW1lIjoiSm9obnNvbiJ9.Q1QCZMHdpmhThsJ-rnUqhBf7mr6lInvM3KPN_mmOAyWC3FoTzj_ufEm2bl5qMiKrO8uwjM01jSsANI49-tU5aAkvT1MOgKwLKrrkF0Q3AiUZSlebnXfRI4rHL3_j-C0THjyWbjV1JiV2r8jlo-qe-bl861cnrr8bJOcV0r9mkRyR3xck10oKzutPyh9isLNOjDA5aW53fZQ2lX9A0N_MvHOTYH7wVRKB2GUnnfj5o3n6mgVtwNavMkbp815PgM6rqt7DGZay94cgsYPf2JmlJCAAmS7mm3KY_jKFWu42OmbyoZEcYJC2mOPBpDMJwHbIBLqGzkLNcL9nmt6z20Yyrw", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItNDIiLCJlbWFpbCI6Im1heWFAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiTWF5YSIsImxhc3RfbmFtZSI6IkpvaG5zb24ifQ"}}}	2026-03-06 06:18:11
BKlTYAwjEVdZfnPvRUhlZELI0IIq_VIv	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-05T05:07:39.910Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772086059, "iat": 1772082459, "iss": "https://test-mock-oidc.replit.app/", "jti": "9e90fd53cf6b600349fa77028ce26525", "sub": "35323958", "email": "35323958@example.com", "auth_time": 1772082459, "last_name": "User", "first_name": "Admin"}, "expires_at": 1772086059, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMDgyNDU5LCJleHAiOjE3NzIwODYwNTksInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiIzNTMyMzk1OEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJBZG1pbiIsImxhc3RfbmFtZSI6IlVzZXIifQ.IP9SAyB_wWLIdSgsHnueWn4aHOXPXCFZKKvgLC-ZVO5N8uAmEM56NDoLQKle8-FLQgmy7cUkdP52gTEWUJD3A--ZDdip3y3L5cczS61SxI5T1ICZxbcRKgw2Ey67H38dLwA3SnoM3mScOLcV1ekidMg1rZ1r3ZJi3cUILbowfOdWHvSVSjW8fuz2zfTar3rdr8lWKRpx1wAaH6eL7atbi2uZU-CyP9UNdRuXm1hj7NNdVubeSXO1ONnDWTZJS-M8OWjHp__hYxeN-zRmqa8jj5GCxjYqqvawksTwDf87FgAEQ8zzHKNblyMnus9EofYWmWORoMwFm0z42e2KhRXiMQ", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiMzUzMjM5NThAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiQWRtaW4iLCJsYXN0X25hbWUiOiJVc2VyIn0"}}}	2026-03-05 05:07:43
yETb3-xf6vJxFWTNn8PefquNppsNdQwI	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-05T05:04:26.025Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772085866, "iat": 1772082266, "iss": "https://test-mock-oidc.replit.app/", "jti": "9400ba89de123a4b8cc545105a9b0bf1", "sub": "35323958", "email": "35323958@example.com", "auth_time": 1772082265, "last_name": "User", "first_name": "Admin"}, "expires_at": 1772085866, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMDgyMjY2LCJleHAiOjE3NzIwODU4NjYsInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiIzNTMyMzk1OEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJBZG1pbiIsImxhc3RfbmFtZSI6IlVzZXIifQ.B7A2EHN5lT4rrW-qV0EruC7J7ReRWVwYeD_td201tjbIbsjTHvMsaa1IgLptue-rn-BQPmMR-x3ICBjZG8qP55fnSHpKeZ70kpCaRu7aVu2h_cv9NdfDhnjRQGmY1ELFnUmegl4aQCZQOmgGyDXcY_rtijeSAghI8uJ2hZtxPn748gQU2C7eU0KyjjkSKHeoHke6NzNTgmFzMjB-Pe-iayNnVamXn2M1W3pnUG-Yi8T6ACb3G2gc09rE9AIw8wNWKOR3WT9TcpmBf3xi_J8JUHg7hyGMXpnU3fWE7-IrR_pN_bK7x_5iFIl9d4VsQWreWX6I0u_Tsqy3UCrWzwhxiw", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiMzUzMjM5NThAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiQWRtaW4iLCJsYXN0X25hbWUiOiJVc2VyIn0"}}}	2026-03-05 05:04:43
SDzsFceeA6x5aHd6XLAfjTO_AAEnZMtI	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T08:11:49.352Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772183509, "iat": 1772179909, "iss": "https://test-mock-oidc.replit.app/", "jti": "9ee6d58735ef54c68b08963e416975b2", "sub": "tcBg5V", "email": "tcBg5V@example.com", "auth_time": 1772179909, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772183509, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTc5OTA5LCJleHAiOjE3NzIxODM1MDksInN1YiI6InRjQmc1ViIsImVtYWlsIjoidGNCZzVWQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.XSUroq2uBr-2YY37NGqOEKiJsLAibVXJ_3Ph6smWSR7wQYN1bv4zQ6J2e7vH1r7d3xRxC311a8ra0pe6VpLH3-BROelvQeFzXqImyrpVB1S2qMSXA7u95HdyznBrR9-nsjLlgLfH2PO6-RJj9p1POYOjHiQc3uBMsTMJFJPb5EKp6idIwW4MXIr7HVzBs9Od5yDIJTkqBIJq5tdtYLWLZfsRG3yXsBx94YeHu5iWF8QbeJ4bt0FnYmylVG7A8pcHPx9YVZ-JqKg-uLLPO89eXfXN_ZQST749PU1adlXSGqcOn9B8wCrA6tScmLJnNQM_7mxou9cY2JY21hLVGHT0QQ", "refresh_token": "eyJzdWIiOiJ0Y0JnNVYiLCJlbWFpbCI6InRjQmc1VkBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-06 08:13:11
jx1iKLr0fY2ZtnjlWIWd4_qnoWxlxfQO	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T07:13:15.473Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772266395, "iat": 1772262795, "iss": "https://test-mock-oidc.replit.app/", "jti": "695cba625eeff07304f0979cdac411fa", "sub": "z5Axnh", "email": "z5Axnh@example.com", "auth_time": 1772262795, "last_name": "User", "first_name": "Test"}, "expires_at": 1772266395, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMjYyNzk1LCJleHAiOjE3NzIyNjYzOTUsInN1YiI6Ino1QXhuaCIsImVtYWlsIjoiejVBeG5oQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IlRlc3QiLCJsYXN0X25hbWUiOiJVc2VyIn0.NQu63wxj_-IiqDXHs_s6_DprymgFW2eMtcylAF06_im18ArOLY7MSQPrxaebwEHWqR3yhgzT3bkdpNS9Tc5YknTfeAtQ_OlrSZat26U5l19PG_hqeiWBxJCqsewKxdtp0otSBTFvqGCcZ8Sm9QU2rl9I9vTiL2Ii3GnSqRG9K2owHGmKg_IZkmujQhx7VzawMGzLv9xfAHMAjnDTYgbb5RFUpbFvaEwLCP4cLJpBq0b5xA4suORocEhda8xPN-iFzcS5cIuubx7P9sFPDFD9QBbwLUgdJQDkSQzkkNKED5qW82iZj8S3rCmUORsLHzuKSQw8nc3MtRLTed88J-P8qw", "refresh_token": "eyJzdWIiOiJ6NUF4bmgiLCJlbWFpbCI6Ino1QXhuaEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJUZXN0IiwibGFzdF9uYW1lIjoiVXNlciJ9"}}}	2026-03-07 07:16:19
Geukl4yk-590D2xFVex5xyYf9U4bnFi-	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-05T05:23:30.812Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772087010, "iat": 1772083410, "iss": "https://test-mock-oidc.replit.app/", "jti": "330c6cadac1dff45d07045fa0fdd1b14", "sub": "35323958", "email": "35323958@example.com", "roles": "", "auth_time": 1772083410, "last_name": "AdminUser", "first_name": "AdminUser", "profile_image": ""}, "expires_at": 1772087010, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMDgzNDEwLCJleHAiOjE3NzIwODcwMTAsInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiIzNTMyMzk1OEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJBZG1pblVzZXIiLCJsYXN0X25hbWUiOiJBZG1pblVzZXIiLCJwcm9maWxlX2ltYWdlIjoiIiwicm9sZXMiOiIifQ.lCCBqE7a6pfkij-AjfZ6jSwxgKbNWhzWcG2ezKJUOPGtk2-VykQB8rZ3CwOYlBFxdNOOjVxVnujSKeGNBHqozNKPhCd5rB1AhP4usDXG8TawBfbgPZBoRVhfHk9Q4a-Z-bR_92UHWp_HeOeW5rq1s2-wnoVwqGvn2wWZeq8ikbkMbH8aj2VaiJcmDpEV6KQ30Df-IhekUSi7IolBDcXvGTQVLem1-KJb1SJnd-DoImdqdmNcHXnPickj6KE3v5Y8rDEKGgV4jL1CsjCwI64giXzIQZLAal9NzaedwX38lFu1CfqQ8OFZSEP9VaF3gT5D4R_kYZDMAScmKd2wzzHd1Q", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiMzUzMjM5NThAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiQWRtaW5Vc2VyIiwibGFzdF9uYW1lIjoiQWRtaW5Vc2VyIiwicHJvZmlsZV9pbWFnZSI6IiIsInJvbGVzIjoiIn0"}}}	2026-03-05 05:23:37
gy2xwS2xKJeofPHtVr-vwzwNJUhDo9kw	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T06:07:14.240Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772176034, "iat": 1772172434, "iss": "https://test-mock-oidc.replit.app/", "jti": "55d9a22eb355da3a264356680abca533", "sub": "test-user-42", "email": "maya@example.com", "auth_time": 1772172434, "last_name": "Johnson", "first_name": "Maya"}, "expires_at": 1772176034, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTcyNDM0LCJleHAiOjE3NzIxNzYwMzQsInN1YiI6InRlc3QtdXNlci00MiIsImVtYWlsIjoibWF5YUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJNYXlhIiwibGFzdF9uYW1lIjoiSm9obnNvbiJ9.Rn_42mOZtGNl6TA-kqlawGgeZuZMG9l7Wi0-D-aE8d5Xe3bWU6-RVKuyoN7BikYYYsfs72ExtbgkgnP_kdATy6Toxh-csSOz3hqG5kcDRX8oddhI6jgRsp0ow7SQeIS963sWeo8LrP4sdMITsRlUsm8ZUStD1pKNfj178SPE_M32yvI7V399r2j84pU95ZoICSKMVlQxaz-nuaxjZYa52HoUF_1dsmhShd3dzRUG5JzH5Tav4ulXub6SwgaJJWn2Lr2jD9LyOuWEG_2mN_aeMlsrJvik5KOl4uePQ-u1ySIzDA5hXroqZvv-RtMGL-cyamYRAM2GE-Pg1a_GF6Gw_Q", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItNDIiLCJlbWFpbCI6Im1heWFAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiTWF5YSIsImxhc3RfbmFtZSI6IkpvaG5zb24ifQ"}}}	2026-03-06 06:07:31
jcrLFLytx97c_BI5upZ_3EyPaJvQWdJP	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-05T06:28:09.906Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772090889, "iat": 1772087289, "iss": "https://test-mock-oidc.replit.app/", "jti": "cb916f1c6549ca02a9da246764995d17", "sub": "35323958", "email": "35323958@example.com", "auth_time": 1772087289, "last_name": "Smith", "first_name": "Pete"}, "expires_at": 1772090889, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMDg3Mjg5LCJleHAiOjE3NzIwOTA4ODksInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiIzNTMyMzk1OEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJQZXRlIiwibGFzdF9uYW1lIjoiU21pdGgifQ.oiZ_1WLsxgGXwCdCT5PL5WFbrpLB0_A7OseCSF626htfm-YwoJZFcwX7CavwMKZ0jD1EUiXgs8kqs3mWvQe8_Rb0pHn55Z5XB4TBGnTK7XIDIXsoXw-wK8IRCBm47rVYxZoTrwmUne9uwFVN5K4lzVkrMIukPlFq1jSLunIJFsskOt_hVvcjuqbyX4pFUvMEdZofpwUN1dLlKun8IsKCxqqcQ7ebHtWM4iq8-L51t5glgM8_v1oKvuRGl-O4vxJUbA81lmpJOU3beX_Idh24LI9zfpOnlma6ydTZ3W3FEzOt4l013t4g8NRWWtPwao9LfOY3yGLJS4KuezTYZ4qy6w", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiMzUzMjM5NThAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiUGV0ZSIsImxhc3RfbmFtZSI6IlNtaXRoIn0"}}}	2026-03-05 06:28:11
BcNgk_1DoVicEunkEW990-VhBSZbOsSr	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T01:22:52.861Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772158972, "iat": 1772155372, "iss": "https://test-mock-oidc.replit.app/", "jti": "f592510f712ca609d9796c559fc59287", "sub": "35323958", "name": "Pete", "role": "", "picture": "", "auth_time": 1772155372}, "expires_at": 1772158972, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTU1MzcyLCJleHAiOjE3NzIxNTg5NzIsInN1YiI6IjM1MzIzOTU4IiwibmFtZSI6IlBldGUiLCJwaWN0dXJlIjoiIiwicm9sZSI6IiJ9.qt8LPYiOGsHQ9o16f_oj-h5vCiJvEnrpwAqyuovQT4spdS5v3B5g_9vkEPDs-p6cp3YeoVJfDl6PQ6pJFreu_nXh93wUSiTF36BsmDGb83Cyc9tTUUwawH2b5uu2B-9lUuIZp51pbUU-gZFsbByjrgqH3Idur7Q-3b9qfwxUDnxxVXGmdbKT2EpqSIXMEBmD2KDGUzoQHuIl33t0iuRwRtYPIB3sxwWyg5Se_f9hU7SOIgPruv0NlI_wqKXgYwBFM8uFh4JgsRdJdhObIdOzPLmk3EDp_1WzLs7xXg4h171SyoNj1FXzAhJX7M1jVH6tHWvWbrdo1tIfYeSoYk4OFw", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsIm5hbWUiOiJQZXRlIiwicGljdHVyZSI6IiIsInJvbGUiOiIifQ"}}}	2026-03-06 01:24:15
W_NbJ4DHbrvsxjlwt8SxY1819yG4Sd2u	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T02:23:38.176Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772162618, "iat": 1772159018, "iss": "https://test-mock-oidc.replit.app/", "jti": "af4ddce72ef35fe6e73a69d5888ec8d5", "sub": "test-user-123", "email": "test@example.com", "auth_time": 1772159018, "last_name": "User", "first_name": "Test"}, "expires_at": 1772162618, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTU5MDE4LCJleHAiOjE3NzIxNjI2MTgsInN1YiI6InRlc3QtdXNlci0xMjMiLCJlbWFpbCI6InRlc3RAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiVGVzdCIsImxhc3RfbmFtZSI6IlVzZXIifQ.jmKifC2gt4qn9ZONA_sVdxQn1ElUE27tvulSHYR9plk-dHRkf3CMprkHKD-ulMtBdYyF9E_GlN6RHAlTXgNHCA3F1hurgivXjenrP8juFA9MCGjSJNJXJVf167Co6uFhx0sJ5SjsBwDjCoMVE75J6-7uQwJgaVu8jPnX8w7XnLYJ9qcpz9NuvW-MErBMVn-rR3pcMMC9lLrqS014WbEB4ZZlBs_67KGhcbVHSMZWG3L_XKrQ8tbIHu93lzHT2iuixpOMwtQmNKrsHA8k1WHh9I_xM8cemuRuniiRv8HoafTwLDOJhLaxMEXcdgT8kp9Czye3lJRwjst3T9nayzwYqQ", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItMTIzIiwiZW1haWwiOiJ0ZXN0QGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IlRlc3QiLCJsYXN0X25hbWUiOiJVc2VyIn0"}}}	2026-03-06 02:24:03
u68Sm2dHdjbmo_vWl_jKd3AVEu7WqHhy	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T03:30:13.720Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772166613, "iat": 1772163013, "iss": "https://test-mock-oidc.replit.app/", "jti": "92a9f88171be2d72575eb80ecfecbdf2", "sub": "test-user-123", "email": "test@example.com", "auth_time": 1772163013, "last_name": "User", "first_name": "Test"}, "expires_at": 1772166613, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTYzMDEzLCJleHAiOjE3NzIxNjY2MTMsInN1YiI6InRlc3QtdXNlci0xMjMiLCJlbWFpbCI6InRlc3RAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiVGVzdCIsImxhc3RfbmFtZSI6IlVzZXIifQ.aLChDFeC_ojLFwGnlFMXFcrRbxW4yTj-EAPB7L06vtC44pbqo-Tq9yV7GZ-Xb-Qzuas0lX69e0MxKpx0Ir0hTJV9guVCrJOQ4Pg3YU5QBjb-S8iLHGNWNl23zuvqGqNkE5AlPmCD9AWARIMDzDEGmvadH4h_i86i8uIUPC7kzOVRFqk3km0HD3YBYab6CWdAE5jx_e0K853IXa1Ax1TuPWA0HqVcvTIzDVWcFFro5a0L1RUsFsVRb4FDD7cpd7EMm7pFRl6vhEtpXr_d3dZJ3eqaO2IBjQiu5wnJWy740Z486j9UU_veCcrxrMzHKAhitrYKLdG1vFCKUMSsqnf5Nw", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItMTIzIiwiZW1haWwiOiJ0ZXN0QGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IlRlc3QiLCJsYXN0X25hbWUiOiJVc2VyIn0"}}}	2026-03-06 03:30:15
ZaC0H2fVBlHYbWCvPrIFJ0hmjp2PN748	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T06:14:50.749Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772176490, "iat": 1772172890, "iss": "https://test-mock-oidc.replit.app/", "jti": "eee69ce18b657bc696d38322e476c1c7", "sub": "39646895", "email": "admin@mindprism.com", "auth_time": 1772172890, "last_name": "Boss", "first_name": "Admin"}, "expires_at": 1772176490, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTcyODkwLCJleHAiOjE3NzIxNzY0OTAsInN1YiI6IjM5NjQ2ODk1IiwiZW1haWwiOiJhZG1pbkBtaW5kcHJpc20uY29tIiwiZmlyc3RfbmFtZSI6IkFkbWluIiwibGFzdF9uYW1lIjoiQm9zcyJ9.GmfbCbfQu7lmSkhhFLcb_HQ6l1j7wpy9SDSfm3uqHqpUzYJz5ZQ1650ExcWNp_vs5O_-RF1rNdN1crVPUe_JpjkbGed3GEY4GSkZ9zg_LR7Ke2ie0p4It-fx1LXOUaETOTgRe3j6SIbRzCwfAQIqMH6hO1LYBdnSbEK40-VIvdJDg4PNmaoTTGUYLG4p4mit3XemOG1c_CytxeC_uMgfJwJIjpb6RACbLMuE17fWsEId3pcqQQFmjz1HCZ0MK0TxXxRuRWcw3YoswQdOSLk7EQeRQz7ptA0W6zFqOIzYk4G3rBMUWGd2NaPJbrIlmPdyRJvSWxXTXsYj4eij7DcxHw", "refresh_token": "eyJzdWIiOiIzOTY0Njg5NSIsImVtYWlsIjoiYWRtaW5AbWluZHByaXNtLmNvbSIsImZpcnN0X25hbWUiOiJBZG1pbiIsImxhc3RfbmFtZSI6IkJvc3MifQ"}}}	2026-03-06 06:15:51
WiiFxa61lHoMDgbQOfb7T3nIgx35APy6	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T06:12:17.763Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772176337, "iat": 1772172737, "iss": "https://test-mock-oidc.replit.app/", "jti": "d49f8e132d051d84465b5bcce1eeadf0", "sub": "test-user-42", "email": "maya@example.com", "auth_time": 1772172737, "last_name": "Johnson", "first_name": "Maya"}, "expires_at": 1772176337, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTcyNzM3LCJleHAiOjE3NzIxNzYzMzcsInN1YiI6InRlc3QtdXNlci00MiIsImVtYWlsIjoibWF5YUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJNYXlhIiwibGFzdF9uYW1lIjoiSm9obnNvbiJ9.yDoIyopY5ULWsxVpTobeHUgvTfY6XDIUFw8CCTiTW4-ENBb9tpevkFHa6sjjbLv2-YcZxKQhKY0OG7V02VfcXGKmyRzyBrN8GlPI8VAcZePPaVCjn_aMYcqjIrCsvMcS8Ua4mlnfb8cU5UIAZusVTd84nJP3wwi2kiVK4t2GurGyQvpx6CDC9TAfhEMIA7CMaiQEG4Q6W-Tu63-BctTwvlSPUQcgKKCsaw_m44vKH0aC9Bv3A_5A3tFOUIyUfuIJYPsB-lRDHY3b2Fhope7ejrum98vYOkt794s-FX2iSR3bto1lupdW-6N7t9Y8zrVBzyg-b0OLg6oxhKuMkr70vg", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItNDIiLCJlbWFpbCI6Im1heWFAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiTWF5YSIsImxhc3RfbmFtZSI6IkpvaG5zb24ifQ"}}}	2026-03-06 06:12:26
_dNL7T0LLugFGISJx5Yry5zObiurFwRj	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T08:26:00.636Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772184360, "iat": 1772180760, "iss": "https://test-mock-oidc.replit.app/", "jti": "b8e95c00ab9622cbc3b88e1038657956", "sub": "b5yZvL", "email": "b5yZvL@example.com", "auth_time": 1772180760, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772184360, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTgwNzYwLCJleHAiOjE3NzIxODQzNjAsInN1YiI6ImI1eVp2TCIsImVtYWlsIjoiYjV5WnZMQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.q2FUk-VX7pD5cMkvCOTnCfj7Gm03Yns0_TOwOdMuUZXPS_zwu6y2CMQCjVYQhWHJuIs4ZLvGSccNt9OCdpgpTUXXE9MlCwiD_c1HFcDvw5Wuq7WLfpXYWYH8MTUDZBWTk0WjtWTzaV3zVIe7jobPemNTHZxSF8kN7hrpQLjKWr2_Ck31yHb0f80tHkAShq5x4BXF1LqcS-eTa_MrjG09aB285mBfTdlph-o6dQRGO903cRR3ouF1yl25KTaakAn7q_oW2SPCAkoaGmWGbjXzRk0eSolRJS-fG7RXKnFQlfdyo4rgVN0ehEeQ9otENpUPfbGwILwcysG2mdFcFGcHAw", "refresh_token": "eyJzdWIiOiJiNXladkwiLCJlbWFpbCI6ImI1eVp2TEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-06 08:28:15
Y2v1TAVIlem1hbsdDh0WPA0kkTHGwwcB	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T08:39:08.969Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772185148, "iat": 1772181548, "iss": "https://test-mock-oidc.replit.app/", "jti": "098afd85dc5440bdbf6145cf54a34f67", "sub": "yuVB4U", "email": "yuVB4U@example.com", "auth_time": 1772181548, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772185148, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTgxNTQ4LCJleHAiOjE3NzIxODUxNDgsInN1YiI6Inl1VkI0VSIsImVtYWlsIjoieXVWQjRVQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.iTrjzN7Kq2dudhHq77PuoPNK_PgBoU8GYvmw4QFtjUOai1n3xk2IizrL80kcInlXzxbrIkz6KGhMZ1m_Ta_DLYqa2cpMkIn7-hQvHjZKBPH_pFsVfFtO-_DxzL_1ksuYCYYKQz_O0aF68Oo-GvfCS-GB0p_jNtPo413GESEwhnNHmmOlQsqCsj5X_fAU2yvfDaVu1vkZis-GH1pi_J5qzb7WpZ5uI5VfnK5YJV5XqPcK2us_fNQS8pa_lyCgzkrq2xT0zW93zj77zRBZjiCyD0Ywr9i3sFBuk6gYCnC1vRZ-0c00j7HcUXf3_M7mZSU9Te9hZDuHIdLb4QCdbrWlyw", "refresh_token": "eyJzdWIiOiJ5dVZCNFUiLCJlbWFpbCI6Inl1VkI0VUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-06 08:41:04
M1CThwMrTcH25dyvMOAl9uYC5h8lB57L	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-05T06:19:27.865Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772090367, "iat": 1772086767, "iss": "https://test-mock-oidc.replit.app/", "jti": "374f30b56e3b3cdc8a1da21d91cc3021", "sub": "35323958", "email": "35323958@example.com", "roles": "", "auth_time": 1772086767, "first_name": "Pete", "profile_image": ""}, "expires_at": 1772090367, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMDg2NzY3LCJleHAiOjE3NzIwOTAzNjcsInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiIzNTMyMzk1OEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJQZXRlIiwicHJvZmlsZV9pbWFnZSI6IiIsInJvbGVzIjoiIn0.vz_A8pq65RZUpOqdoQlq4MO6Bo7TkxyHGpStujFs--BsRx-OjxtKrhTjkA-GM2SUrVs1JMLXNYqHmD1TYLmR0jYfY3k6kzx09i2W3-xqiRuOASB9cc-ckvo9EG9jxT3H8REBmVj_mwbimoMMcDrAElAqNTmXw5PMFnDp_smafAbAnyADHg1XFknkZIiZOCVYTp-sYnHsfXRd3kS4dmRWzB2QAiSMNAI0k-SzlaR9k-2T4DhMiDRZH36M3-DhdT7PTJiot-rJqFD7fMGMvHww9YkeHfkYFnaHa66IeldxcXibFfxXZqZ-Bf3w793fOLwM8GtTAckcCUiTmLOGkQTygA", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiMzUzMjM5NThAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiUGV0ZSIsInByb2ZpbGVfaW1hZ2UiOiIiLCJyb2xlcyI6IiJ9"}}}	2026-03-05 06:19:36
gyKiahSQjJU73ZVAI3-MAs_JoHQA4gFt	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T20:47:37.668Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772315257, "iat": 1772311657, "iss": "https://test-mock-oidc.replit.app/", "jti": "f4aa25f2ca7df02173e7e90a2f0315b4", "sub": "BQ7kP2", "email": "BQ7kP2@example.com", "auth_time": 1772311657, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772315257, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzExNjU3LCJleHAiOjE3NzIzMTUyNTcsInN1YiI6IkJRN2tQMiIsImVtYWlsIjoiQlE3a1AyQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.bakLwq_1uqPHjAleHJVqHZOh09JnbgEyzxf1b1VNVfw0KfaQeMsBGBfpQJ7JPfSklP1xE1cqKErbHN7JlJEMZ--TB0CP2sqz98p2pil77lI05d8NbwdWRBI8uvo8qnR7woEpqkJoH5fy9oGPi1P82W783aWl9CLZsIkaYU47k3xOu8jWgAJRUtH0NRMoTDGvZO5ikWmbFaFGcD1h0kkg4Q71QJFRNSfVnUWpeYKp_Qb9ybe5LcQwZPIzBn0daqtp6VguVAvchnVkCoQIAQzssr3Ynnzbnz_tqbrzZU5vwOJ3Qf8-WDMNjZfDRIltXOUGVWrv-xpcaPmhmmkfqEWh3Q", "refresh_token": "eyJzdWIiOiJCUTdrUDIiLCJlbWFpbCI6IkJRN2tQMkBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-07 20:49:06
RhRz7dmuHksEbePQZiWKmJ1MStKhb9ET	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T05:46:11.639Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772174771, "iat": 1772171171, "iss": "https://test-mock-oidc.replit.app/", "jti": "47ee67dd56486e1e03fda1c71827ed32", "sub": "test-user-123", "name": "Test User", "email": "test@example.com", "teams": "", "auth_time": 1772171171, "last_name": "User", "first_name": "Test", "profile_image_url": ""}, "expires_at": 1772174771, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTcxMTcxLCJleHAiOjE3NzIxNzQ3NzEsInN1YiI6InRlc3QtdXNlci0xMjMiLCJuYW1lIjoiVGVzdCBVc2VyIiwiZmlyc3RfbmFtZSI6IlRlc3QiLCJsYXN0X25hbWUiOiJVc2VyIiwicHJvZmlsZV9pbWFnZV91cmwiOiIiLCJlbWFpbCI6InRlc3RAZXhhbXBsZS5jb20iLCJ0ZWFtcyI6IiJ9.Vf0EYqNSTrW3QNM2KpuBxGkSwEByw69bVOXpYwZ0FwNtzA_UjFF6hLEhU0TV94_xFGWOq9kd4T7NFhB31tieQIR7eeFT_qdIMdT33jWrRqePd7xx9prHGo58ZNemAk0GtRHi9Nxljp_F9AEF1iCLaLAlw1XuEur1xRXUtBimF-CeG49HzJEwXZR_CU-xH1kl4ThlTi-DFkwWcY10w0EaAJ0qM1RXtyuTVYFaKD56BOQVLN1t9uLjoPbRVjWybKCDDFNSrEtds8MNAP_XE7eaPENnJXrVy2tYh56N3g9HobnNebUHEdC0SxuhbPu-FnYes2ls9kLDrMUSzH8gwhqxDQ", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItMTIzIiwibmFtZSI6IlRlc3QgVXNlciIsImZpcnN0X25hbWUiOiJUZXN0IiwibGFzdF9uYW1lIjoiVXNlciIsInByb2ZpbGVfaW1hZ2VfdXJsIjoiIiwiZW1haWwiOiJ0ZXN0QGV4YW1wbGUuY29tIiwidGVhbXMiOiIifQ"}}}	2026-03-06 05:46:13
J6P3zj07okwhGXaQMrYboPNDuHGWLl4t	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T07:09:39.956Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772179779, "iat": 1772176179, "iss": "https://test-mock-oidc.replit.app/", "jti": "a0d0791863faffe9d3796c59f74ae0f9", "sub": "test-user-42", "name": "Maya Johnson", "email": "maya@example.com", "auth_time": 1772176179, "last_name": "Johnson", "first_name": "Maya"}, "expires_at": 1772179779, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTc2MTc5LCJleHAiOjE3NzIxNzk3NzksInN1YiI6InRlc3QtdXNlci00MiIsIm5hbWUiOiJNYXlhIEpvaG5zb24iLCJmaXJzdF9uYW1lIjoiTWF5YSIsImxhc3RfbmFtZSI6IkpvaG5zb24iLCJlbWFpbCI6Im1heWFAZXhhbXBsZS5jb20ifQ.kpravlMe_v7k7mSxdqYVfTDqvHaloy2EzpZkAbSMIe0L7EJk3_VdUY-jgUGC2jS2_oyvx81R5wRZtrOrPgJkhWal9MD6G1CV3mEJQWTLsN8o_ToZBWAzumH1qbU1BCDwLXf0FPQDaf-warr-KFZr3wyhqa2ljPfgSLFd5K67epqgzUxTLRF39_W3ZW8SIfJcM7PEpMdMjWo85-UpswBWJa0ocmumgXF73hQ_GJC_Kl0PlHua5zCe7XSIQdna1ZhH7XhPnfKr47bB8t2HIVylHAlhXYk6w3Z6cjQdffsl8nLJn3erCS1eW_-DERTVpS3M6NxqwVPp1k0K4ANcYtQGiw", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItNDIiLCJuYW1lIjoiTWF5YSBKb2huc29uIiwiZmlyc3RfbmFtZSI6Ik1heWEiLCJsYXN0X25hbWUiOiJKb2huc29uIiwiZW1haWwiOiJtYXlhQGV4YW1wbGUuY29tIn0"}}}	2026-03-06 07:10:25
q0QceraOuPKS9iwav1vdJtF2YECVcmSR	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T18:41:54.578Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772307714, "iat": 1772304114, "iss": "https://test-mock-oidc.replit.app/", "jti": "e642392ee777aaca4b93c589b9e12924", "sub": "eiM0S2", "email": "eiM0S2@example.com", "auth_time": 1772304114, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772307714, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzA0MTE0LCJleHAiOjE3NzIzMDc3MTQsInN1YiI6ImVpTTBTMiIsImVtYWlsIjoiZWlNMFMyQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.jMGYI496nQIHwfZuLWYjRWyclZt6HGz00j9G0vayq3Nt8LftIZjJheVE0E-bzu9ziMzK7OPVa4Yw5ykyt5ITUVtrPiIpDtG0o6FrdNHJkH1-uO9n-Xb9J9PMzvIrL7VrTMhJUbbSl3rdVvGYNfyu7XOLmpq08SsXDIbm29FcJy-REY-z5cEbKKRdtRPGQXNkrL0msVN4ODqwspZCPRQunay67ZnLuOupyqkmNStwifE2KNV6MD9fbCjHA-iF650gsm6IWwkvw5omg8ld3zhWL5izN2yt6HHUx1kyL3ncXYp-bSZJfm41eUE7Gd9wbwCkAZ4uOsyIqgkzRxjsxUrPMg", "refresh_token": "eyJzdWIiOiJlaU0wUzIiLCJlbWFpbCI6ImVpTTBTMkBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-07 18:41:58
ig1vh9t0dDnt3MKRj0a5Qt54X-Di2T3S	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T05:52:26.178Z", "httpOnly": true, "originalMaxAge": 604799999}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772261546, "iat": 1772257946, "iss": "https://test-mock-oidc.replit.app/", "jti": "304fec77af68b2f18d7b5fbf2d157677", "sub": "8wB_v6", "email": "8wB_v6@example.com", "auth_time": 1772257946, "last_name": "User", "first_name": "Replit"}, "expires_at": 1772261546, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMjU3OTQ2LCJleHAiOjE3NzIyNjE1NDYsInN1YiI6Ijh3Ql92NiIsImVtYWlsIjoiOHdCX3Y2QGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IlJlcGxpdCIsImxhc3RfbmFtZSI6IlVzZXIifQ.s9-_63teG2EgKtsxOu25zZHYlxusXup7se1w3XmFkPyh-Zi1vTToBjn1mkDXg2pF2goYslUaRVYxc2RVn2U9Jo44WBtDAn3JfX4Q2WG4BTL7J-MDWghLGOicpZGHfBAsiURWzfLl9VtQiUo_2TxOopu98tJ0fWdkkWcnpjOh8xicG6XLKuGKeYDIIggRr-OJTqHwsV7SRdreBTzOIld8PtZj1d772ynpeisguhuGmNeFOMH9QsZAby1krVwn7WzfLFyz1Ai5XsCCXt0AAaTf4roTvmn_ATDzq1im9NhrZ4hMCjzp1et7R1YZMsPP6iQ9FeQputE1S9O2Ihl-YUqM9Q", "refresh_token": "eyJzdWIiOiI4d0JfdjYiLCJlbWFpbCI6Ijh3Ql92NkBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJSZXBsaXQiLCJsYXN0X25hbWUiOiJVc2VyIn0"}}}	2026-03-07 05:55:19
M-B8VxIpjYj38-1wLyp2qvUjml_lbQGX	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T06:57:55.727Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772179075, "iat": 1772175475, "iss": "https://test-mock-oidc.replit.app/", "jti": "42c3211c968dc1423872f44d2de7e36d", "sub": "test-user-42", "name": "Maya Johnson", "email": "maya@example.com", "auth_time": 1772175475, "last_name": "Johnson", "first_name": "Maya"}, "expires_at": 1772179075, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTc1NDc1LCJleHAiOjE3NzIxNzkwNzUsInN1YiI6InRlc3QtdXNlci00MiIsIm5hbWUiOiJNYXlhIEpvaG5zb24iLCJmaXJzdF9uYW1lIjoiTWF5YSIsImxhc3RfbmFtZSI6IkpvaG5zb24iLCJlbWFpbCI6Im1heWFAZXhhbXBsZS5jb20ifQ.ktiEak9lmgiwyMSmrndu8ugl3RJSUIOrPvFufc9eC2SFAiB7Txj7di3F2M0Wt9Gqy4qcQxFvDlgzQ7lFb_4YXLoJDo2OwC4AlED-KzlhsnhO2aFWpXS9gIkrY2HLlPkq8AYKN-seoPUD6cWxvmmJrzXGpIu5BqKx5I-HI7xn2I6Xa4zhbrr-uXsx7MjrA8h85libatE2J-5uvQFt0HIGcv-xfSCGuvt9guU2_OV7bWkCytuvNz4taQaG7-8IqQSu6Rz6Vlef9_f6aDXum0l8yI1RsLh35Uj6oPjspf86zoc-J_3BstQmecFt0wPcv8V-8xbVRnc7q4BUptgBPXtBAw", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItNDIiLCJuYW1lIjoiTWF5YSBKb2huc29uIiwiZmlyc3RfbmFtZSI6Ik1heWEiLCJsYXN0X25hbWUiOiJKb2huc29uIiwiZW1haWwiOiJtYXlhQGV4YW1wbGUuY29tIn0"}}}	2026-03-06 06:58:11
D5jpEYYvQjI0RvU2wML9KqGjXMJU79Ep	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T10:13:20.623Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772190800, "iat": 1772187200, "iss": "https://test-mock-oidc.replit.app/", "jti": "81a68cdb22f42e792c86fa24f8b12146", "sub": "W46Jai", "email": "W46Jai@example.com", "auth_time": 1772187200, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772190800, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTg3MjAwLCJleHAiOjE3NzIxOTA4MDAsInN1YiI6Ilc0NkphaSIsImVtYWlsIjoiVzQ2SmFpQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.tgDxZ6bq60Ts6lo_qS_AFjb5nRHnfCFoaWOmNiBU5iJN_Tu6I_Cox-9j79HK4oOelnKY-m4CN4lqaU1y4Tx9l1YSQnxSiplW7qSKR--EI8CZW_BT9Eo2NmtwWeZDXKwHjpHVZm75mBv6C7Qdao9CSDPjG-VjrRheY0Lxcvs60smHDI1uSn8EuzqFQNoay8t9152rRniGU2nt-uP_54P6_ZB8FR9dexRLEBb7MQ9nzV_dvXjxN9z_ArRe_LoFr-GkWy6-fBXn6to_W_Bum-HLfEUi9KnDkwEk-wQzJIlS8PEv3y4TcmMDMvq11OVCZGYlaHzPXS9SlxazBZIcxL05nw", "refresh_token": "eyJzdWIiOiJXNDZKYWkiLCJlbWFpbCI6Ilc0NkphaUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-06 10:15:25
VuIQfsCinE5OxqSoKm-ZF7FMGzdCBhcw	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T07:23:25.303Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772180605, "iat": 1772177005, "iss": "https://test-mock-oidc.replit.app/", "jti": "152070ddc5be1db27be25abe9dda5043", "sub": "test-user-42", "name": "Maya Johnson", "email": "maya@example.com", "auth_time": 1772177005, "last_name": "Johnson", "first_name": "Maya"}, "expires_at": 1772180605, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTc3MDA1LCJleHAiOjE3NzIxODA2MDUsInN1YiI6InRlc3QtdXNlci00MiIsIm5hbWUiOiJNYXlhIEpvaG5zb24iLCJmaXJzdF9uYW1lIjoiTWF5YSIsImxhc3RfbmFtZSI6IkpvaG5zb24iLCJlbWFpbCI6Im1heWFAZXhhbXBsZS5jb20ifQ.k-jpDBIEhoQox7V0s-rjEgEpq6Nt06QNubOo_hiKd3LavubTsFkAuEnZUAu9L6Ym3VgTCer8aHk89YN6_n4VBBfzCBaN-tNYQM-uRjIAZfjv3m9B7jN51djbcN7s-4Dj51uCCKbC_QjVgMhVysMY437VPtVFeMyJID5PSNjSccG398K1CgO4g7IaOOZ9D-hqGRxENmUjtJiT-qyEDbSsP79cDc5EJcRpOzDkeQjKAoU3xMyQOcGfn26up2yAJut4wK9SDgnOuE4O8wdngC3F1mnxUAEm7cIiBXHdHkhm5kuCKppp8JC7EsPJj-Jp9QgaET3t-MRrBKDHMCyz_Gsmdw", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVzZXItNDIiLCJuYW1lIjoiTWF5YSBKb2huc29uIiwiZmlyc3RfbmFtZSI6Ik1heWEiLCJsYXN0X25hbWUiOiJKb2huc29uIiwiZW1haWwiOiJtYXlhQGV4YW1wbGUuY29tIn0"}}}	2026-03-06 07:23:43
RsGpcsLJL11sNE7NPw6daMF-xHJoqDv_	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T22:07:56.350Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772320076, "iat": 1772316476, "iss": "https://test-mock-oidc.replit.app/", "jti": "d5f91850ce64342e8541230692afe254", "sub": "test-fix-007", "email": "test-fix-007@example.com", "auth_time": 1772316476, "last_name": "Runner", "first_name": "FixTest", "profile_image": ""}, "expires_at": 1772320076, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzE2NDc2LCJleHAiOjE3NzIzMjAwNzYsInN1YiI6InRlc3QtZml4LTAwNyIsImVtYWlsIjoidGVzdC1maXgtMDA3QGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkZpeFRlc3QiLCJsYXN0X25hbWUiOiJSdW5uZXIiLCJwcm9maWxlX2ltYWdlIjoiIn0.nCBq-45HKLSpUGFZtjZW66k0yyJh9dBO5QqTE6394egy8z3Kc9HsRyi03dceANGHB5_O6v-CGtz4d3CkgVlflJ9DG-ShBzKrTPpqKVEPkvcFlGBT1P3haJhxZ9GsYhQx-q7wDx9yWPZq1gxsxWZ-hDg2KxKgQznIZ5FY3A0_FgdamovoMrZbeHwQSGlrLi7EhQlXscLA6RxcS3iXlY8TIaB5uPvO9HmkeT5Z5l4okuVylrqx2Qlp9erJjwyytRFN7kPohEGEJy7rW1_xNptRy6Fu6UJop_fnX8rxPbHsWFlZXRxq6VR_52IBpQa4zUBAvwKhREL8dQtAtK9dYlQF7A", "refresh_token": "eyJzdWIiOiJ0ZXN0LWZpeC0wMDciLCJlbWFpbCI6InRlc3QtZml4LTAwN0BleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJGaXhUZXN0IiwibGFzdF9uYW1lIjoiUnVubmVyIiwicHJvZmlsZV9pbWFnZSI6IiJ9"}}}	2026-03-07 22:08:58
qyL6YoGjmHp3qHlAq-wf6TEGFHiORc0W	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T21:32:07.096Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772317927, "iat": 1772314327, "iss": "https://test-mock-oidc.replit.app/", "jti": "e2442979916f23d7fde6da828aefdc77", "sub": "z5AXX1", "email": "z5AXX1@example.com", "auth_time": 1772314327, "last_name": "Doe", "first_name": "John"}, "expires_at": 1772317927, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzE0MzI3LCJleHAiOjE3NzIzMTc5MjcsInN1YiI6Ino1QVhYMSIsImVtYWlsIjoiejVBWFgxQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.csRiXGrPmckL09ccexznT7viDkCoaJRZENyj2S2ln3m-7uwvP4QL0oV-HwBQ5N3UCO-Rlb6RCHziNr1xbWTXPhhLMeBWzxxMxX0Qceo2tFQXHN4htD7MnFj0q9mzK2zWmmmYQvCHuqkWnEY9xNl3uMMjtaBSPPDA_-eMgwyU-GasNmDpIbs91hzTH_hKkdbvYExb6e_tKAdk6NwIbehVRtnwmavG-olwqfYi6tuO-MgYM4r4RbV0CHt2qfwVG_7X_NT_wm5dOXB5ymiTTUbddywHYfmQJqBAv-YUBzadorfp790lwmjmV7zvFgF_dgAiZqAsdwj621WIcReUPHJ5ag", "refresh_token": "eyJzdWIiOiJ6NUFYWDEiLCJlbWFpbCI6Ino1QVhYMUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2026-03-07 21:32:23
v3LuYbjWeI-tzkqFTTERXvGrwtc19q8N	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T07:20:48.628Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772180448, "iat": 1772176848, "iss": "https://test-mock-oidc.replit.app/", "jti": "5ac9a8b27ea31d1b4f2d79b9e44cf5c0", "sub": "39646895", "name": "Admin Boss", "email": "admin@mindprism.com", "auth_time": 1772176848, "last_name": "Boss", "first_name": "Admin"}, "expires_at": 1772180448, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTc2ODQ4LCJleHAiOjE3NzIxODA0NDgsInN1YiI6IjM5NjQ2ODk1IiwiZW1haWwiOiJhZG1pbkBtaW5kcHJpc20uY29tIiwiZmlyc3RfbmFtZSI6IkFkbWluIiwibGFzdF9uYW1lIjoiQm9zcyIsIm5hbWUiOiJBZG1pbiBCb3NzIn0.FKcEm7FbrZJlosRIfT9exBBDqmx4cMhERbVSEgcg85CtuDc_ftuH1xdTdUnACHVo7uMabcP1a1oBA8CTZ34iHn_5gQKvMEKN6huL810nolvdwuAfVs5EE9UAZ_uaEdexWWtFKmNRrtjnHRXrhXvyzzwd3_iORfk9b5n99PzWs65a7IIGTRNuF8LFeLTcoY5_xI-gh46Zo3c614UbGKY-BB7p3X-I1NAHRXQGtEju9CjjVEdLi84rFF6tDxCvPgVxglI_5o7bXgNJjYTWYUkVRP-XaNoYS1YjS_hEBsC6Lfb18G_EZzFjyUYXzzsbsxoy7lUQcHUlxlKwW8sHlTKNeA", "refresh_token": "eyJzdWIiOiIzOTY0Njg5NSIsImVtYWlsIjoiYWRtaW5AbWluZHByaXNtLmNvbSIsImZpcnN0X25hbWUiOiJBZG1pbiIsImxhc3RfbmFtZSI6IkJvc3MiLCJuYW1lIjoiQWRtaW4gQm9zcyJ9"}}}	2026-03-06 07:20:50
jQeXFSfTF-bQw_qT-pCncD-c9Spvm4nS	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T22:31:06.008Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772321465, "iat": 1772317865, "iss": "https://test-mock-oidc.replit.app/", "jti": "407bd351caac06ca5fe5f2684e07d019", "sub": "test-buttons-001", "email": "test-buttons-001@example.com", "auth_time": 1772317865, "last_name": "User", "first_name": "ButtonTest"}, "expires_at": 1772321465, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzE3ODY1LCJleHAiOjE3NzIzMjE0NjUsInN1YiI6InRlc3QtYnV0dG9ucy0wMDEiLCJlbWFpbCI6InRlc3QtYnV0dG9ucy0wMDFAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiQnV0dG9uVGVzdCIsImxhc3RfbmFtZSI6IlVzZXIifQ.V-69G9xEHYzVuyRJ227-m_AkQg3KTvjwkB0yZjhq-Wdtt0gfGuwqcHwgIdCE8oyTO8VrNsuA5Axa3fwK98xqAHq5Rj0tI5aQfIbNs5H9vSiq3BzJGSIChn8HC9KAlf29tGAtqBKeMqFDpMzFcb2UL8hGjoZwWx8kwLuMyjQ7X6YodM0DcYGspowVsYXrV0Udzcur3rDQw1cFyI6K5n-ZFa8rsOg9ZuQnzS79mcmbY4RICUJphJEWpbqHu55TMpHdWzYvVJLP4679lc9g2BBMpSMNDzfVjhaOZO3jKAXsB83QrIgjuhkb6sBSOAsqWZT6fzekitMUzDrGLsZktGzTmg", "refresh_token": "eyJzdWIiOiJ0ZXN0LWJ1dHRvbnMtMDAxIiwiZW1haWwiOiJ0ZXN0LWJ1dHRvbnMtMDAxQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkJ1dHRvblRlc3QiLCJsYXN0X25hbWUiOiJVc2VyIn0"}}}	2026-03-07 22:32:29
WySCtYShkGqUONfaVQ5Ez0aHLN72hZC9	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-06T06:55:59.486Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772178959, "iat": 1772175359, "iss": "https://test-mock-oidc.replit.app/", "jti": "b1549549cd41559f92d0c0969096e08d", "sub": "39646895", "email": "admin@mindprism.com", "auth_time": 1772175359, "last_name": "Boss", "first_name": "Admin"}, "expires_at": 1772178959, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMTc1MzU5LCJleHAiOjE3NzIxNzg5NTksInN1YiI6IjM5NjQ2ODk1IiwiZW1haWwiOiJhZG1pbkBtaW5kcHJpc20uY29tIiwiZmlyc3RfbmFtZSI6IkFkbWluIiwibGFzdF9uYW1lIjoiQm9zcyJ9.pwp2NMKhjlW3997kk3flSZFGr5w4iLrhPDK9hlJGmYNPkeqi42Le1IDqGOt-7J7F9XJLLfj9fLchwuAw6rU2sW5_EEEJo4FzczDXtaftGZjCahbOYxlEpSuQpitr9_5dJ8zjB321E8O2d55nwR2yOjtbyKOqRnW0zWFxbyCVeuMqq0ZGA-ieKjAnINYyeRgOD4Ec5ypT3Xqtwtnn85JGseiZU_dEaztVc-ILN-_nN-OLzrcG7K5oAFAJ0xF10riHrHmAQOlcLfs9qrYWBHju8CKbpkyKnJ5-gvRdUM7IgT8Zc6Kv2dc2VF_KXP9vMqUcBhZDhqVDcIjyzd0i1B965Q", "refresh_token": "eyJzdWIiOiIzOTY0Njg5NSIsImVtYWlsIjoiYWRtaW5AbWluZHByaXNtLmNvbSIsImZpcnN0X25hbWUiOiJBZG1pbiIsImxhc3RfbmFtZSI6IkJvc3MifQ"}}}	2026-03-06 06:56:00
WLj7TE-TycEteFbkJkLZ4wXgDKZTFdf7	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-08T02:29:48.068Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772335788, "iat": 1772332188, "iss": "https://replit.com/oidc", "sub": "35323958", "email": "4980005@gmail.com", "at_hash": "fVToswi8cwiviF1Yf2v6hA", "username": "4980005", "auth_time": 1772195234, "last_name": "Rej", "first_name": "Pete", "email_verified": true}, "expires_at": 1772335788, "access_token": "pugtCsC69XmpiND72Kd9K1CSpYY5j42GjjJLqAyHM1x", "refresh_token": "6ZgT1OZsrfuxgl84qIjQXYJVfti8FZmdbivQglJlNEr"}}}	2026-03-08 02:37:26
0D0-lv4QD6HNsY9E5lbbBL5j30kLHw-L	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T23:23:35.911Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772324615, "iat": 1772321015, "iss": "https://test-mock-oidc.replit.app/", "jti": "1724af18c4f5742ee173420572b4b790", "sub": "35323958", "email": "35323958@example.com", "auth_time": 1772321015, "last_name": "Rej", "first_name": "Pete", "profile_image": ""}, "expires_at": 1772324615, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzIxMDE1LCJleHAiOjE3NzIzMjQ2MTUsInN1YiI6IjM1MzIzOTU4IiwiZW1haWwiOiIzNTMyMzk1OEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJQZXRlIiwibGFzdF9uYW1lIjoiUmVqIiwicHJvZmlsZV9pbWFnZSI6IiJ9.dbZy8ik0JvUxGBwT-gm6izrkPkOk3RZlqMEVnECzqGbBVjKxmUCBzKljK-6t_6oEoAN00XTmnx9Y1eD2vY2PwO3wdHMCa0PXVqWibP_QJZwbQeTExxi64EC96rJQw9RnQsNfceSDsLC8iPjdcLozNMTbYOyGKRbIT19Bwrp6PO-j0qkPKo2b3VRnfQyTEoar4fLvrryWG9R78QYcz5FvUYqgBOGFjfXPholNFmmPGbew6sW72yuWRJsClKr8w9c2_g88hqaXtkGIAi7Px1jNCxwltaS9ogbvo8pA8AYfUdXHZg8WFGEhZb768Ck55iICPYKwa8DkGhkh8ua4JRs6sw", "refresh_token": "eyJzdWIiOiIzNTMyMzk1OCIsImVtYWlsIjoiMzUzMjM5NThAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiUGV0ZSIsImxhc3RfbmFtZSI6IlJlaiIsInByb2ZpbGVfaW1hZ2UiOiIifQ"}}}	2026-03-07 23:24:24
abogvyRHkSfph4eIOsckmqizdXwCFnpH	{"cookie": {"path": "/", "secure": true, "expires": "2026-03-07T23:20:12.257Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "0b64e456-1468-4715-b790-1960aecba773", "exp": 1772324412, "iat": 1772320812, "iss": "https://test-mock-oidc.replit.app/", "jti": "c9ffadfca3721c5bd56323791d638993", "sub": "test-blend-001", "auth_time": 1772320812, "last_name": "User", "first_name": "BlendTest", "profile_image": ""}, "expires_at": 1772324412, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzcyMzIwODEyLCJleHAiOjE3NzIzMjQ0MTIsInN1YiI6InRlc3QtYmxlbmQtMDAxIiwiZmlyc3RfbmFtZSI6IkJsZW5kVGVzdCIsImxhc3RfbmFtZSI6IlVzZXIiLCJwcm9maWxlX2ltYWdlIjoiIn0.PLD5F6PKVMskK_A6Saqb-mOYqDDAl73PLihQXDWVSTEpwGBDp_-IBcFwaWj1BA2F_CxQGiVUwy_wNG23g5G6PISNtbYGaRxOwylHfxJpmUdzwwvJSGfkbSoBSO9ZZ3w2I8oqfJ-5A6ttL8iPivskSwnJH3nbUm_KwXvEVql_2faQVU9ELUGBbyC4MVgPh7dZJDK_a3AeIfZ1H9iJz5BKAGN5fwqwTTGT5JMOtPLNniPw-fPm7KleXCMeq5z82kaQV2im1siZ-Z2eKe1m0Dj0-Ci5yw04vc2KL9Jspwco4QG_QTUqeFe40u8ZNSyh6-oB125FnndByjYl987KOU1pRA", "refresh_token": "eyJzdWIiOiJ0ZXN0LWJsZW5kLTAwMSIsImZpcnN0X25hbWUiOiJCbGVuZFRlc3QiLCJsYXN0X25hbWUiOiJVc2VyIiwicHJvZmlsZV9pbWFnZSI6IiJ9"}}}	2026-03-07 23:20:20
\.


--
-- Data for Name: short_views; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.short_views (id, short_id, user_id, viewed_at) FROM stdin;
\.


--
-- Data for Name: shorts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shorts (id, book_id, title, content, media_type, media_url, thumbnail_url, background_gradient, duration, order_index, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stories (id, book_id, title, content, moral, order_index, principle_id) FROM stdin;
412704d0-460f-414b-b630-30bba0be1dd1	2ea408e9-dc96-444c-a0dc-93901f9029b5	The British Cycling Revolution	In 2003, Dave Brailsford became the coach of the British Cycling team. They had nearly 100 years of mediocrity. Instead of pursuing massive improvement, Brailsford searched for tiny 1% improvements in everything: redesigned bike seats, tested different fabrics for racing suits, painted the inside of the team truck white to spot dust. Within 5 years, British cyclists dominated the road and track cycling events at the 2008 Olympic Games.	Aggregating marginal gains — searching for tiny improvements in every area — can lead to remarkable results over time.	1	ebfb77ff-1dee-419b-bb14-18d7648cd42b
0ebdd79a-8b67-4a38-b984-00d6f42766ac	2ea408e9-dc96-444c-a0dc-93901f9029b5	The Paper Clip Strategy	A young stockbroker named Trent Dyrsmid began each morning with two jars on his desk. One was filled with 120 paper clips. The other was empty. As soon as he settled in each day, he would make a sales call. After each call, he would move one paper clip from the full jar to the empty jar and repeat. Within 18 months, Dyrsmid was bringing in $5 million to the firm.	Visual cues and tracking systems make habits obvious and satisfying. The paper clip strategy is a visual trigger that makes your progress concrete.	2	a01a7109-6e1f-4b0d-8372-f60b0cf43303
cf5a2a04-3f23-4695-ba9c-d8b080435604	7ba8d165-4195-43a3-9079-518dd4332439	The Invisible Gorilla	In a famous experiment by Christopher Chabris and Daniel Simons, participants were asked to watch a video of people passing basketballs and count the number of passes made by the team wearing white. While focused on counting, about half the participants completely failed to notice a person in a gorilla suit walking through the scene, stopping to beat their chest, and walking off.	Our System 1 creates a coherent story from limited information. When we focus intensely on one thing, we can be blind to what is literally right in front of us.	1	ae54bb94-fb76-45e9-9c9d-ac123229cf94
ecc297e3-91a9-4702-a906-3440277873f0	7ba8d165-4195-43a3-9079-518dd4332439	The Halo Effect in Action	Kahneman describes grading student essays. When he graded them sequentially, his impression of the first essay influenced his judgment of later essays. A brilliant first answer created a 'halo' that made subsequent mediocre answers seem better than they were.	First impressions create a halo that colors all subsequent judgments. To make better decisions, evaluate each piece of evidence independently.	2	406e77bb-c567-4427-a6ff-d47ea1e5c761
9b4a88e2-176a-4639-bed1-e776b5b93e6c	83a8013d-9483-4495-a6f8-9bbdbdf6ecd2	The Beggar on the Box	Tolle tells the story of a beggar who sat on a box at the side of the road for years. One day a passerby asked what was in the box. 'Nothing,' said the beggar. The passerby insisted he look. The beggar pried open the lid and discovered the box was filled with gold.	Stop looking outside yourself for fulfillment. Everything you need is already within you, accessible through present-moment awareness.	1	821e3382-8c8b-4342-a315-45a3759e0bf8
7401ea6d-a4bf-4e37-b69d-51c9f44979ba	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	The Road Rage Incident	Goleman describes a man who cut off another driver in traffic. The offended driver chased him for miles, eventually forcing both cars to stop. In the confrontation, one man was shot. A trivial driving incident escalated to tragedy because the amygdala hijacked all rational thought — the emotional brain took the wheel.	An amygdala hijack can turn a minor irritation into a life-altering disaster. The pause between stimulus and response is where your power lives.	1	154b9ce1-0226-4af1-a070-76f3c327cebf
4905a643-61e0-48ff-8c1e-92bb5a811fb4	23f2345b-6336-4573-a63f-8ee2cd34f56b	The Imagined Lecture	During his time in the concentration camps, Frankl kept himself going by imagining himself giving a lecture after the war about the psychology of the concentration camp. This mental exercise gave him a sense of purpose — transforming his suffering into a subject for future teaching.	When you find a 'why' to live for, you can endure almost any 'how.' Projecting purpose into the future can sustain you through present suffering.	1	6af8c02a-9a53-4ab6-a14c-4d4daef118f6
\.


--
-- Data for Name: user_activity_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_activity_log (id, user_id, event_type, event_data, book_id, session_duration, created_at) FROM stdin;
\.


--
-- Data for Name: user_interests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_interests (id, user_id, interests, onboarding_completed, created_at) FROM stdin;
bb1ecc9c-9824-4f4e-a8b7-13070c8124b8	35323958	{emotional-iq}	t	2026-02-23 05:26:51.849636
38ce5c5e-f6e8-41b0-a3fe-04b8c4dbf316	U1mC5u	{habits,productivity,mindfulness}	t	2026-02-25 13:37:54.238686
7d80f338-7e42-466e-ae64-8996273db83d	test-user-123	{mindfulness,habits}	t	2026-02-27 02:24:02.127362
28ce8c5e-cf34-4237-b5e5-963067b71501	test-user-42	{emotional-iq}	t	2026-02-27 06:07:30.278044
4c074693-ea1b-4e91-88fe-0884c74861dc	tcBg5V	{anxiety}	t	2026-02-27 08:12:46.038503
eb478ac3-b9c5-4795-8df2-fb22fd9bb5fd	X5bqd-	{anxiety}	t	2026-02-27 08:21:33.307886
bce4b2ef-a3a4-4574-8743-e84b45bf1d51	b5yZvL	{productivity}	t	2026-02-27 08:27:29.483258
9e0bc196-8137-4a6a-9deb-b8a4020f3b70	yuVB4U	{anxiety,productivity}	t	2026-02-27 08:39:19.659355
6c352b80-5f76-45f8-b667-3dd90e37548d	a8S2dP	{anxiety}	t	2026-02-27 09:03:06.494449
d676c4fd-66e2-413f-a878-017650a94731	j69UEF	{anxiety}	t	2026-02-27 09:08:43.286694
2733cc0d-5cf8-45cf-b608-7ea61a340144	pIDdI2	{habits,mindfulness,productivity}	t	2026-02-27 09:12:33.714156
83fea42f-1e7f-4e06-81c9-97a90a365023	Jkp87u	{habits}	t	2026-02-27 09:19:40.01199
1dcc7694-3ff7-497b-be1e-db83e720feda	tImpmS	{habits}	t	2026-02-27 09:30:25.016579
5a52d725-9681-411b-8e8e-bc8689e8c8fe	9BmmO0	{habits}	t	2026-02-27 09:48:27.140761
5e52d733-284a-4800-8ed7-f9adf7eb62b3	W46Jai	{habits}	t	2026-02-27 10:13:38.390925
1bfe4dfa-7f7b-406d-8c19-80ae9cdbb70b	oU-UWK	{habits,mindfulness,productivity}	t	2026-02-27 14:59:41.189419
1b035a70-a262-4bf8-bc27-96d14b74be13	a_rJjy	{habits}	t	2026-02-27 15:05:16.244066
c62ef76b-c5f3-4903-8972-d40ba4426f21	Wc93iB	{habits}	t	2026-02-28 05:35:23.702294
8aa2315f-ea9b-4388-a4bd-7988cd3d8f4d	8wB_v6	{habits}	t	2026-02-28 05:53:05.888245
13d47837-7db8-4213-80bc-5086c3ab3202	z5Axnh	{habits}	t	2026-02-28 07:13:30.369264
fcbdf699-f4f1-4751-87a4-e8a56f81cf7e	aZw-6w	{anxiety}	t	2026-02-28 18:58:33.334972
2b7bbd58-79f5-4e93-b20f-89be18591129	1udX-Q	{anxiety}	t	2026-02-28 19:19:03.433448
406f9f91-a7d1-410c-a025-4449233db541	BQ7kP2	{anxiety,productivity}	t	2026-02-28 20:48:02.932274
138d2c82-a75e-4acf-8405-994ee334aede	test-user-999	{productivity,mindfulness}	t	2026-02-28 21:33:56.820943
03920d6c-0e15-41f0-9d2d-3deac50dc7c9	test-sweep-001	{anxiety}	t	2026-02-28 21:42:26.641403
4e1a114e-b227-4bea-99ea-d8d220a164af	test-fix-007	{anxiety}	t	2026-02-28 22:08:14.791338
be301104-f588-4ee2-a04c-8d622f730619	admin-check-001	{habits}	t	2026-02-28 22:29:29.053358
a0165440-8d04-463a-9a7f-a2564edb5076	test-buttons-001	{anxiety}	t	2026-02-28 22:31:24.800609
\.


--
-- Data for Name: user_progress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_progress (id, user_id, book_id, completed_principles, completed_exercises, bookmarked, last_accessed_at, current_card_index, total_cards, current_section) FROM stdin;
d5f6d78e-e0bc-417c-afaa-0c29209ac61d	pIDdI2	7ba8d165-4195-43a3-9079-518dd4332439	{}	{}	f	2026-02-27 09:14:35.462888	1	9	chapter-summaries
fb931232-37e7-482e-8002-4f4f7e507fe3	35323958	69a9d68d-cba5-4bf2-9a58-a5d8a2875cf0	{}	{}	f	2026-02-27 12:28:12.27	4	6	infographics
644677c8-4837-4fed-877d-0e4d320961cc	8wB_v6	2ea408e9-dc96-444c-a0dc-93901f9029b5	{}	{}	f	2026-02-28 05:54:47.178398	1	17	chapter-summaries
63dd6f1a-ff3f-4f89-8a90-dd792da42843	35323958	2ea408e9-dc96-444c-a0dc-93901f9029b5	{}	{}	t	2026-02-28 06:53:30.128	2	17	chapter-summaries
55ed264b-d004-4d78-b9bd-520b69d9d2be	35323958	23f2345b-6336-4573-a63f-8ee2cd34f56b	{}	{}	f	2026-02-27 01:45:59.999	1	9	chapter-summaries
4e29b531-a9b1-470c-a6d0-c94b35f1cd8a	35323958	7ba8d165-4195-43a3-9079-518dd4332439	{}	{}	f	2026-03-01 01:19:04.737	4	5	mental-models
c54091dd-691e-45c9-aa54-921f52c258f2	test-user-42	23f2345b-6336-4573-a63f-8ee2cd34f56b	{}	{}	t	2026-02-27 06:17:53.503	1	9	chapter-summaries
\.


--
-- Data for Name: user_streaks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_streaks (id, user_id, current_streak, longest_streak, last_active_date, total_minutes_listened, total_exercises_completed, total_books_started, streak_freeze_available, last_freeze_used_at) FROM stdin;
4b16239a-e9f5-4070-870d-88b068127147	test-user-42	1	1	2026-02-27	0	0	0	t	\N
47bb5af8-9d0f-4115-a392-9c7e57eedd4d	pIDdI2	1	1	2026-02-27	0	0	0	t	\N
c89ffaf3-443e-4a74-919a-174c5dcff75a	8wB_v6	1	1	2026-02-28	0	0	0	t	\N
6d5cbc3f-8cae-4c59-9616-986bcf660f95	35323958	7	7	2026-03-01	0	0	0	t	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, first_name, last_name, profile_image_url, created_at, updated_at, role, is_premium, stripe_customer_id, stripe_subscription_id, current_period_end) FROM stdin;
a8S2dP	a8S2dP@example.com	John	Doe	\N	2026-02-27 09:02:45.768094	2026-02-27 09:02:45.768094	super_admin	f	\N	\N	\N
j69UEF	j69UEF@example.com	Admin	User	\N	2026-02-27 09:08:18.549195	2026-02-27 09:08:18.549195	user	f	\N	\N	\N
pIDdI2	pIDdI2@example.com	John	Doe	\N	2026-02-27 09:12:21.504085	2026-02-27 09:12:21.504085	user	f	\N	\N	\N
Jkp87u	Jkp87u@example.com	Customer	User	\N	2026-02-27 09:19:27.22225	2026-02-27 09:19:27.22225	user	f	\N	\N	\N
U1mC5u	U1mC5u@example.com	John	Doe	\N	2026-02-25 13:37:43.02982	2026-02-25 13:37:43.02982	user	f	\N	\N	\N
tImpmS	tImpmS@example.com	Replit	User	\N	2026-02-27 09:30:08.881955	2026-02-27 09:30:08.881955	user	f	\N	\N	\N
nH8jar	nH8jar@example.com	Admin	User	\N	2026-02-25 13:44:46.523579	2026-02-25 13:44:46.523579	admin	f	\N	\N	\N
9BmmO0	9BmmO0@example.com	Replit	User	\N	2026-02-27 09:47:49.212253	2026-02-27 09:47:49.212253	user	f	\N	\N	\N
VaoZ0a	VaoZ0a@example.com	Admin	User	\N	2026-02-25 13:57:07.727847	2026-02-25 13:57:07.727847	admin	f	\N	\N	\N
W46Jai	W46Jai@example.com	John	Doe	\N	2026-02-27 10:13:20.597795	2026-02-27 10:13:20.597795	user	f	\N	\N	\N
oU-UWK	oU-UWK@example.com	Test	User	\N	2026-02-27 14:59:28.545386	2026-02-27 14:59:28.545386	user	f	\N	\N	\N
a_rJjy	a_rJjy@example.com	John	Doe	\N	2026-02-27 15:04:53.479382	2026-02-27 15:04:53.479382	user	f	\N	\N	\N
Wc93iB	Wc93iB@example.com	John	Doe	\N	2026-02-28 05:35:03.644812	2026-02-28 05:35:03.644812	user	f	\N	\N	\N
8wB_v6	8wB_v6@example.com	Replit	User	\N	2026-02-28 05:52:26.166151	2026-02-28 05:52:26.166151	user	f	\N	\N	\N
6WfO6B	6WfO6B@example.com	Test	User	\N	2026-02-28 06:35:39.174971	2026-02-28 06:35:39.174971	user	f	\N	\N	\N
admin_SyQ1	admin_SyQ1@example.com	Admin	User	\N	2026-02-28 06:36:05.737368	2026-02-28 06:37:22.571	admin	f	\N	\N	\N
z5Axnh	z5Axnh@example.com	Test	User	\N	2026-02-28 07:13:15.459444	2026-02-28 07:13:15.459444	admin	f	\N	\N	\N
eiM0S2	eiM0S2@example.com	John	Doe	\N	2026-02-28 18:41:54.547348	2026-02-28 18:41:54.547348	user	f	\N	\N	\N
xVhSzI	xVhSzI@example.com	John	Doe	\N	2026-02-28 18:48:20.789927	2026-02-28 18:48:20.789927	user	f	\N	\N	\N
aZw-6w	aZw-6w@example.com	John	Doe	\N	2026-02-28 18:58:17.670579	2026-02-28 18:58:17.670579	user	f	\N	\N	\N
1udX-Q	1udX-Q@example.com	John	Doe	\N	2026-02-28 19:18:50.483388	2026-02-28 19:18:50.483388	user	f	\N	\N	\N
BQ7kP2	BQ7kP2@example.com	John	Doe	\N	2026-02-28 20:47:37.65636	2026-02-28 20:47:37.65636	user	f	\N	\N	\N
z5AXX1	z5AXX1@example.com	John	Doe	\N	2026-02-28 21:32:07.074582	2026-02-28 21:32:07.074582	user	f	\N	\N	\N
test-user-999	test-user-999@example.com	TestUser	Runner	\N	2026-02-28 21:33:25.136694	2026-02-28 21:33:25.136694	user	f	\N	\N	\N
test-sweep-001	test-sweep-001@example.com	Sweep	Tester	\N	2026-02-28 21:42:14.943181	2026-02-28 21:42:14.943181	user	f	\N	\N	\N
test-fix-007	test-fix-007@example.com	FixTest	Runner	\N	2026-02-28 22:07:56.339705	2026-02-28 22:07:56.339705	user	f	\N	\N	\N
test-user-123	test@example.com	Test	User		2026-02-23 04:00:45.562398	2026-02-27 05:49:28.722	user	f	\N	\N	\N
admin-check-001	admin-check-001@example.com	AdminCheck	User	\N	2026-02-28 22:28:27.902416	2026-02-28 22:28:27.902416	admin	f	\N	\N	\N
test-buttons-001	test-buttons-001@example.com	ButtonTest	User	\N	2026-02-28 22:31:05.997579	2026-02-28 22:31:05.997579	user	f	\N	\N	\N
test-blend-001	\N	BlendTest	User	\N	2026-02-28 23:20:12.246513	2026-02-28 23:20:12.246513	user	f	\N	\N	\N
brand-new-user-999	newuser@example.com	New	User	\N	2026-02-27 06:18:24.867126	2026-02-27 06:18:24.867126	user	f	\N	\N	\N
35323958	35323958@example.com	Pete	Rej	\N	2026-02-23 04:10:00.491791	2026-02-28 23:25:40.901	super_admin	f	\N	\N	\N
39646895	admin@mindprism.com	Admin	Boss	\N	2026-02-27 06:14:50.736943	2026-02-27 07:20:48.605	admin	f	\N	\N	\N
test-user-42	maya@example.com	Maya	Johnson		2026-02-27 06:07:14.226526	2026-02-27 07:23:25.281	user	f	\N	\N	\N
Z1JoTp	Z1JoTp@example.com	John	Doe	\N	2026-02-27 08:09:15.483826	2026-02-27 08:09:15.483826	user	f	\N	\N	\N
tcBg5V	tcBg5V@example.com	John	Doe	\N	2026-02-27 08:11:49.341845	2026-02-27 08:11:49.341845	user	f	\N	\N	\N
X5bqd-	X5bqd-@example.com	John	Doe	\N	2026-02-27 08:20:00.100527	2026-02-27 08:20:00.100527	user	f	\N	\N	\N
b5yZvL	b5yZvL@example.com	John	Doe	\N	2026-02-27 08:26:00.624376	2026-02-27 08:26:00.624376	user	f	\N	\N	\N
yuVB4U	yuVB4U@example.com	John	Doe	\N	2026-02-27 08:39:08.956641	2026-02-27 08:39:08.956641	user	f	\N	\N	\N
\.


--
-- Name: action_items action_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.action_items
    ADD CONSTRAINT action_items_pkey PRIMARY KEY (id);


--
-- Name: analytics_events analytics_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_events
    ADD CONSTRAINT analytics_events_pkey PRIMARY KEY (id);


--
-- Name: book_versions book_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_versions
    ADD CONSTRAINT book_versions_pkey PRIMARY KEY (id);


--
-- Name: books books_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT books_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: categories categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_slug_unique UNIQUE (slug);


--
-- Name: chakra_progress chakra_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chakra_progress
    ADD CONSTRAINT chakra_progress_pkey PRIMARY KEY (id);


--
-- Name: chapter_summaries chapter_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chapter_summaries
    ADD CONSTRAINT chapter_summaries_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: common_mistakes common_mistakes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.common_mistakes
    ADD CONSTRAINT common_mistakes_pkey PRIMARY KEY (id);


--
-- Name: daily_sparks daily_sparks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_sparks
    ADD CONSTRAINT daily_sparks_pkey PRIMARY KEY (id);


--
-- Name: exercises exercises_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercises
    ADD CONSTRAINT exercises_pkey PRIMARY KEY (id);


--
-- Name: flashcard_progress flashcard_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flashcard_progress
    ADD CONSTRAINT flashcard_progress_pkey PRIMARY KEY (id);


--
-- Name: infographics infographics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.infographics
    ADD CONSTRAINT infographics_pkey PRIMARY KEY (id);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: mental_models mental_models_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mental_models
    ADD CONSTRAINT mental_models_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_key UNIQUE (user_id);


--
-- Name: principles principles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.principles
    ADD CONSTRAINT principles_pkey PRIMARY KEY (id);


--
-- Name: quiz_results quiz_results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_results
    ADD CONSTRAINT quiz_results_pkey PRIMARY KEY (id);


--
-- Name: saved_highlights saved_highlights_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saved_highlights
    ADD CONSTRAINT saved_highlights_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (sid);


--
-- Name: short_views short_views_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.short_views
    ADD CONSTRAINT short_views_pkey PRIMARY KEY (id);


--
-- Name: shorts shorts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shorts
    ADD CONSTRAINT shorts_pkey PRIMARY KEY (id);


--
-- Name: stories stories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT stories_pkey PRIMARY KEY (id);


--
-- Name: user_activity_log user_activity_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity_log
    ADD CONSTRAINT user_activity_log_pkey PRIMARY KEY (id);


--
-- Name: user_interests user_interests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_interests
    ADD CONSTRAINT user_interests_pkey PRIMARY KEY (id);


--
-- Name: user_progress user_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_progress
    ADD CONSTRAINT user_progress_pkey PRIMARY KEY (id);


--
-- Name: user_streaks user_streaks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_streaks
    ADD CONSTRAINT user_streaks_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_stripe_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_stripe_customer_id_key UNIQUE (stripe_customer_id);


--
-- Name: users users_stripe_subscription_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_stripe_subscription_id_key UNIQUE (stripe_subscription_id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_session_expire" ON public.sessions USING btree (expire);


--
-- Name: analytics_events_type_created_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_events_type_created_idx ON public.analytics_events USING btree (event_type, created_at);


--
-- Name: books_status_category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX books_status_category_idx ON public.books USING btree (status, category_id);


--
-- Name: idx_activity_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_activity_created_at ON public.user_activity_log USING btree (created_at);


--
-- Name: idx_activity_event_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_activity_event_type ON public.user_activity_log USING btree (event_type);


--
-- Name: idx_activity_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_activity_user_id ON public.user_activity_log USING btree (user_id);


--
-- Name: idx_analytics_events_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_events_created ON public.analytics_events USING btree (created_at);


--
-- Name: idx_analytics_events_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_events_type ON public.analytics_events USING btree (event_type);


--
-- Name: idx_analytics_events_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_events_user ON public.analytics_events USING btree (user_id);


--
-- Name: idx_flashcard_review; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_flashcard_review ON public.flashcard_progress USING btree (user_id, next_review_date);


--
-- Name: idx_flashcard_user_book; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_flashcard_user_book ON public.flashcard_progress USING btree (user_id, book_id);


--
-- Name: idx_quiz_user_book; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quiz_user_book ON public.quiz_results USING btree (user_id, book_id);


--
-- Name: journal_entries_user_created_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX journal_entries_user_created_idx ON public.journal_entries USING btree (user_id, created_at);


--
-- Name: user_activity_log_user_created_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_activity_log_user_created_idx ON public.user_activity_log USING btree (user_id, created_at);


--
-- Name: user_progress_user_book_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_progress_user_book_idx ON public.user_progress USING btree (user_id, book_id);


--
-- Name: action_items action_items_book_id_books_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.action_items
    ADD CONSTRAINT action_items_book_id_books_id_fk FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: analytics_events analytics_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_events
    ADD CONSTRAINT analytics_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: book_versions book_versions_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_versions
    ADD CONSTRAINT book_versions_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.books(id) ON DELETE CASCADE;


--
-- Name: books books_category_id_categories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT books_category_id_categories_id_fk FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: chakra_progress chakra_progress_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chakra_progress
    ADD CONSTRAINT chakra_progress_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: chapter_summaries chapter_summaries_book_id_books_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chapter_summaries
    ADD CONSTRAINT chapter_summaries_book_id_books_id_fk FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: comments comments_book_id_books_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_book_id_books_id_fk FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: comments comments_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: common_mistakes common_mistakes_book_id_books_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.common_mistakes
    ADD CONSTRAINT common_mistakes_book_id_books_id_fk FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: daily_sparks daily_sparks_book_id_books_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_sparks
    ADD CONSTRAINT daily_sparks_book_id_books_id_fk FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: exercises exercises_book_id_books_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercises
    ADD CONSTRAINT exercises_book_id_books_id_fk FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: flashcard_progress flashcard_progress_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flashcard_progress
    ADD CONSTRAINT flashcard_progress_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.books(id) ON DELETE CASCADE;


--
-- Name: flashcard_progress flashcard_progress_principle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flashcard_progress
    ADD CONSTRAINT flashcard_progress_principle_id_fkey FOREIGN KEY (principle_id) REFERENCES public.principles(id) ON DELETE CASCADE;


--
-- Name: infographics infographics_book_id_books_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.infographics
    ADD CONSTRAINT infographics_book_id_books_id_fk FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: journal_entries journal_entries_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: mental_models mental_models_book_id_books_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mental_models
    ADD CONSTRAINT mental_models_book_id_books_id_fk FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: notification_preferences notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: principles principles_book_id_books_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.principles
    ADD CONSTRAINT principles_book_id_books_id_fk FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: quiz_results quiz_results_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_results
    ADD CONSTRAINT quiz_results_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.books(id) ON DELETE CASCADE;


--
-- Name: quiz_results quiz_results_chapter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_results
    ADD CONSTRAINT quiz_results_chapter_id_fkey FOREIGN KEY (chapter_id) REFERENCES public.chapter_summaries(id) ON DELETE CASCADE;


--
-- Name: saved_highlights saved_highlights_book_id_books_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saved_highlights
    ADD CONSTRAINT saved_highlights_book_id_books_id_fk FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: saved_highlights saved_highlights_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saved_highlights
    ADD CONSTRAINT saved_highlights_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: short_views short_views_short_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.short_views
    ADD CONSTRAINT short_views_short_id_fkey FOREIGN KEY (short_id) REFERENCES public.shorts(id);


--
-- Name: shorts shorts_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shorts
    ADD CONSTRAINT shorts_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: stories stories_book_id_books_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT stories_book_id_books_id_fk FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: user_activity_log user_activity_log_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity_log
    ADD CONSTRAINT user_activity_log_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: user_activity_log user_activity_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity_log
    ADD CONSTRAINT user_activity_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_interests user_interests_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_interests
    ADD CONSTRAINT user_interests_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_progress user_progress_book_id_books_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_progress
    ADD CONSTRAINT user_progress_book_id_books_id_fk FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: user_progress user_progress_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_progress
    ADD CONSTRAINT user_progress_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_streaks user_streaks_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_streaks
    ADD CONSTRAINT user_streaks_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: journal_entries journal_admin_access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY journal_admin_access ON public.journal_entries USING ((current_setting('app.current_user_role'::text, true) = ANY (ARRAY['admin'::text, 'super_admin'::text])));


--
-- Name: journal_entries; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.journal_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: journal_entries journal_owner_access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY journal_owner_access ON public.journal_entries USING (((user_id)::text = current_setting('app.current_user_id'::text, true))) WITH CHECK (((user_id)::text = current_setting('app.current_user_id'::text, true)));


--
-- PostgreSQL database dump complete
--

\unrestrict 2q32IbP2XdQfQwqBzV6PdMu2wXGVHVjVc5BOFLqdNRdaIf2pUXPEP4dE85vcikJ

